---
name: arbitrary-write-to-rce
description: "Arbitrary write to RCE playbook. Use when a file write, upload, archive extraction, config edit, log write, template write, package write, or path traversal primitive may become code execution."
role: specialist
domain: file-upload-access
---

# Arbitrary Write to RCE

Use this skill after you have a confirmed write primitive and need to decide whether it can safely become code execution in scope.

## Core Model

A file write becomes execution only if four conditions align:

1. Location: you can write to a path that is read or executed by a trusted component.
2. Content: you control enough bytes and format for that component.
3. Trigger: the component loads, includes, runs, parses, or restarts against the file.
4. Privilege: execution occurs in a meaningful security context.

Do not claim RCE from arbitrary write without a trigger.

## Recon Questions

- Is the write path absolute, relative, normalized, or constrained by extension/content checks?
- Can you overwrite existing files or only create new files?
- Are permissions, owner, symlinks, temp files, or atomic writes relevant?
- Which components consume writable files: web server, template engine, plugin loader, config, cron, service, package manager, logs?
- Is a restart, cache clear, user action, import, or scheduled job needed?
- Can you prove execution with a harmless marker first?

## Test Families

### Web-Served Write

Write static content first and confirm retrieval. Code execution requires the server to execute that type, not just serve it.

### Include or Template Write

Target templates, includes, themes, translations, or report definitions that the application renders.

### Config or Plugin Write

Configuration, plugin manifests, package files, or startup scripts may execute after reload. Use reversible changes and backups.

### Log or Session Poisoning

If logs or session files are later included or parsed, prove the include/parse path separately.

### Archive and Path Traversal Chains

Uploads, ZIP slip, and traversal writes need extraction path proof plus a trigger path.

## Validation Ladder

1. Prove write location and exact bytes with a harmless marker.
2. Determine who reads the file and when.
3. Prove a non-executing trigger first, such as template rendering or config read.
4. Escalate to code execution only if scope permits and with minimal harmless effect.
5. Restore overwritten files or remove created artifacts.

## Evidence Standard

Capture write request, resulting path, file content proof, consuming component, trigger request/event, execution or behavior proof, and cleanup.

## Pivots

- Upload path: [upload-insecure-files](../upload-insecure-files/SKILL.md)
- Path traversal: [path-traversal-lfi](../path-traversal-lfi/SKILL.md)
- Template execution: [ssti-server-side-template-injection](../ssti-server-side-template-injection/SKILL.md)
- Command execution sink: [cmdi-command-injection](../cmdi-command-injection/SKILL.md)
