---
name: api-sec
description: >-
role: router
domain: auth-api
  Entry P1 category router for API security. Use when choosing between API
  recon, authorization, token abuse, GraphQL, hidden-parameter, BOLA/BOPLA,
  and business API workflows before any deeper API topic skill.
---

# API Security Router

Use this router before diving into a specific API topic. The priority is to turn API traffic, docs, schemas, JS-discovered endpoints, and mobile/miniapp calls into object/property/function authorization hypotheses.

## When to Use

- REST, mobile backend, miniapp backend, GraphQL, RPC-like JSON, or gateway APIs are in scope.
- Swagger/OpenAPI/schema/docs appear.
- Traffic contains IDs, tenants, roles, status, amount, quotas, tokens, callbacks, export/share/file keys.
- The user wants Web/SRC black-box API hunting rather than generic endpoint scanning.

## Core Split

Do not collapse all API issues into IDOR:

- **BOLA**: object-level authorization. Can this identity access or mutate this object?
- **BOPLA / mass assignment**: property-level authorization. Can this identity read or set protected fields?
- **BFLA**: function-level authorization. Can this identity call a function its role should not have?
- **Token/session abuse**: does a token/header/signature grant too much scope or live too long?
- **GraphQL/hidden params**: do schema, introspection, batching, or hidden fields expose extra capabilities?

## Skill Map

- [API Recon and Docs](../api-recon-and-docs/SKILL.md): OpenAPI, Swagger, base paths, versions, hidden docs, schemas.
- [API Authorization and BOLA](../api-authorization-and-bola/SKILL.md): BOLA, BOPLA, BFLA, method/content-type variants, object/property tests.
- [API Auth and JWT Abuse](../api-auth-and-jwt-abuse/SKILL.md): bearer tokens, headers, JWT claims, refresh, token scope, rate-limit boundaries.
- [GraphQL and Hidden Parameters](../graphql-and-hidden-parameters/SKILL.md): introspection, batching, hidden fields, mass assignment, nested relations.
- [Single Variable Replay Harness](../single-variable-replay-harness/SKILL.md): exact one-variable mutation proof.

## Quick Triage

| Observation | Route |
|---|---|
| Swagger/OpenAPI/schema/docs | `api-recon-and-docs` -> `api-authorization-and-bola` |
| IDs in URL/JSON/header/GraphQL args | `api-authorization-and-bola` for BOLA |
| response fields not in create/update docs | `api-authorization-and-bola` for BOPLA/mass assignment |
| role/admin/approve/export/delete/refund action appears | `api-authorization-and-bola` for BFLA |
| JWT/bearer/session/device headers | `api-auth-and-jwt-abuse` |
| `/graphql`, batched JSON arrays, query/mutation names | `graphql-and-hidden-parameters` |
| hidden endpoint from JS/miniapp | `request-chain-tracer` -> `api-authorization-and-bola` |
| payment/coupon/callback/quota API | `payment-promo-rewards-abuse` plus `workflow-state-diff-lab` |

## Recommended Flow

1. Build API inventory from traffic, docs, JS, and app/miniapp wrappers.
2. Group by business action: list, detail, create, update, delete, export, share, approve, bind, invite, pay, refund, admin.
3. Extract object, tenant, property, role, status, token, amount, and order variables.
4. For each high-value endpoint, run BOLA first, then BOPLA, then BFLA.
5. Test method and content-type variants only when the endpoint is high-value.
6. Re-read server-side state after any write-like mutation.
7. Package baseline, single mutation, response diff, and backend impact.

## Candidate Protected Fields

Prioritize these for BOPLA/mass-assignment tests when they appear in responses, schemas, JS, or errors:

`role`, `roles`, `isAdmin`, `admin`, `ownerId`, `userId`, `uid`, `tenantId`, `orgId`, `deptId`, `status`, `state`, `auditStatus`, `price`, `amount`, `quota`, `plan`, `balance`, `discount`, `points`, `verified`, `mfa`, `permission`, `scope`.

## Related Categories

- [auth-sec](../auth-sec/SKILL.md)
- [business-logic-vuln](../business-logic-vuln/SKILL.md)
- [recon-for-sec](../recon-for-sec/SKILL.md)
