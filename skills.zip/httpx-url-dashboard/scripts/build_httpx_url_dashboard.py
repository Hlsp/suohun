#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import sys
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import SplitResult, urlsplit, urlunsplit


DEFAULT_HTTPX_CANDIDATES = [
    r"Z:\BaiduNetdiskDownload\Tools\信息收集\子域名爆破\HTTPX\httpx.exe",
]

READ_ENCODINGS = ("utf-8-sig", "utf-8", "gb18030", "utf-16")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Probe URLs with httpx and build a grouped HTML dashboard."
    )
    parser.add_argument("--input", required=True, help="Path to the URL txt file.")
    parser.add_argument(
        "--httpx",
        help="Path to httpx.exe or its containing directory. Falls back to known local paths and PATH.",
    )
    parser.add_argument(
        "--output-dir",
        required=True,
        help="Directory for generated JSON, HTML, and debug files.",
    )
    parser.add_argument(
        "--title",
        default="URL 存活探测面板",
        help="Dashboard title written into JSON metadata.",
    )
    parser.add_argument("--threads", type=int, default=50, help="httpx threads.")
    parser.add_argument("--rate-limit", type=int, default=150, help="httpx rate limit per second.")
    parser.add_argument("--timeout", type=int, default=5, help="httpx timeout in seconds.")
    parser.add_argument("--retries", type=int, default=1, help="httpx retries.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    input_path = Path(args.input).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    debug_dir = output_dir / "debug"
    template_path = Path(__file__).resolve().parent.parent / "assets" / "dashboard_template.html"

    if not input_path.is_file():
        raise SystemExit(f"输入文件不存在: {input_path}")
    if not template_path.is_file():
        raise SystemExit(f"HTML 模板不存在: {template_path}")

    httpx_path = resolve_httpx(args.httpx)

    output_dir.mkdir(parents=True, exist_ok=True)
    debug_dir.mkdir(parents=True, exist_ok=True)

    cleaned_urls, skipped = clean_input_urls(input_path)
    if not cleaned_urls:
        raise SystemExit("没有读取到可探测的有效 URL。")

    clean_file = debug_dir / "clean_urls_valid.txt"
    write_text(clean_file, "\n".join(cleaned_urls) + "\n")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    plain_output_file = debug_dir / f"httpx_scan_{timestamp}_plain.txt"
    stderr_output_file = debug_dir / f"httpx_scan_{timestamp}_stderr.txt"

    stdout_text, stderr_text, returncode = run_httpx(
        httpx_path=httpx_path,
        input_file=clean_file,
        threads=args.threads,
        rate_limit=args.rate_limit,
        timeout=args.timeout,
        retries=args.retries,
    )
    write_text(plain_output_file, stdout_text)
    if stderr_text.strip():
        write_text(stderr_output_file, stderr_text)

    parsed_hits = parse_httpx_output(stdout_text)
    report = build_report(
        input_urls=cleaned_urls,
        parsed_hits=parsed_hits,
        source_file=input_path,
        title=args.title,
        skipped=skipped,
        httpx_path=httpx_path,
        returncode=returncode,
    )

    json_path = output_dir / "url_probe_data.json"
    html_path = output_dir / "url_probe_dashboard.html"
    write_text(json_path, json.dumps(report, ensure_ascii=False, indent=2))
    write_dashboard(template_path=template_path, report=report, output_path=html_path)

    print(f"httpx: {httpx_path}")
    print(f"输入: {input_path}")
    print(f"有效 URL: {report['total']}")
    print(f"存活: {report['live']}  正常: {report['ok']}  拦截: {report['blocked']}  异常: {report['warn']}  无响应: {report['down']}")
    print(f"JSON: {json_path}")
    print(f"HTML: {html_path}")
    print(f"原始输出: {plain_output_file}")
    if skipped:
        print(f"跳过: {len(skipped)} 条无效/非 HTTP(S) 输入")
    if returncode != 0:
        print(f"警告: httpx 退出码为 {returncode}，已尽量根据已采集输出生成结果。", file=sys.stderr)
    return 0


def resolve_httpx(httpx_arg: str | None) -> Path:
    candidates: list[Path] = []

    if httpx_arg:
        raw_path = Path(httpx_arg).expanduser()
        candidates.append(raw_path)
        if raw_path.is_dir():
            candidates.append(raw_path / "httpx.exe")

    which_hit = shutil.which("httpx.exe") or shutil.which("httpx")
    if which_hit:
        candidates.append(Path(which_hit))

    candidates.extend(Path(item) for item in DEFAULT_HTTPX_CANDIDATES)

    checked: set[str] = set()
    for candidate in candidates:
        resolved = str(candidate)
        if resolved in checked:
            continue
        checked.add(resolved)
        if candidate.is_file():
            return candidate.resolve()

    raise SystemExit(
        "找不到 httpx 可执行文件。请通过 --httpx 传入 httpx.exe 或其所在目录。"
    )


def clean_input_urls(input_path: Path) -> tuple[list[str], list[str]]:
    raw_text = read_text(input_path)
    cleaned: list[str] = []
    skipped: list[str] = []
    seen: set[str] = set()

    for raw_line in raw_text.splitlines():
        line = raw_line.strip().strip("\"'")
        if not line:
            continue

        normalized = normalize_http_url(line)
        if not normalized:
            skipped.append(raw_line)
            continue

        if normalized in seen:
            continue
        seen.add(normalized)
        cleaned.append(normalized)

    return cleaned, skipped


def normalize_http_url(value: str) -> str | None:
    if not re.match(r"^https?://", value, flags=re.IGNORECASE):
        return None

    try:
        parsed = urlsplit(value)
    except ValueError:
        return None

    if not parsed.netloc:
        return None

    scheme = parsed.scheme.lower()
    netloc = parsed.netloc
    path = parsed.path or ""
    query = parsed.query or ""
    sanitized = SplitResult(scheme, netloc, path, query, "")
    return urlunsplit(sanitized)


def read_text(path: Path) -> str:
    last_error: Exception | None = None
    for encoding in READ_ENCODINGS:
        try:
            return path.read_text(encoding=encoding)
        except Exception as exc:  # pragma: no cover - fallback path
            last_error = exc
    raise RuntimeError(f"无法读取文件: {path} ({last_error})")


def write_text(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8", newline="\n")


def run_httpx(
    *,
    httpx_path: Path,
    input_file: Path,
    threads: int,
    rate_limit: int,
    timeout: int,
    retries: int,
) -> tuple[str, str, int]:
    command = [
        str(httpx_path),
        "-l",
        str(input_file),
        "-sc",
        "-location",
        "-title",
        "-server",
        "-rt",
        "-fr",
        "-threads",
        str(threads),
        "-rl",
        str(rate_limit),
        "-timeout",
        str(timeout),
        "-retries",
        str(retries),
        "-random-agent",
        "-silent",
        "-no-color",
    ]
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    return completed.stdout, completed.stderr, completed.returncode


def parse_httpx_output(stdout_text: str) -> list[dict[str, Any]]:
    hits: list[dict[str, Any]] = []
    for line in stdout_text.splitlines():
        parsed = parse_httpx_line(line.strip())
        if parsed:
            hits.append(parsed)
    return hits


def parse_httpx_line(line: str) -> dict[str, Any] | None:
    if not line or "[" not in line:
        return None

    url_part, sep, rest = line.partition(" [")
    if not sep:
        return None

    groups = re.findall(r"\[([^\]]*)\]", f"[{rest}")
    if len(groups) >= 8:
        probe_status, status, location, method, length, title, server, response_time = groups[:8]
        reachable = probe_status.upper() == "SUCCESS"
    elif len(groups) >= 5:
        status, location, title, server, response_time = groups[:5]
        method = ""
        length = ""
        reachable = True
    else:
        return None

    status = status.strip()

    return {
        "url": url_part.strip(),
        "reachable": reachable,
        "status": status,
        "location": location.strip(),
        "method": method.strip(),
        "contentLength": length.strip(),
        "title": title.strip(),
        "server": server.strip(),
        "responseTime": response_time.strip(),
        "category": categorize(status=status, reachable=reachable),
    }


def categorize(*, status: str, reachable: bool) -> str:
    if not reachable:
        return "down"
    if status in {"401", "403"}:
        return "blocked"
    try:
        status_code = int(status)
    except ValueError:
        return "warn"
    if 200 <= status_code < 300:
        return "ok"
    return "warn"


def build_report(
    *,
    input_urls: list[str],
    parsed_hits: list[dict[str, Any]],
    source_file: Path,
    title: str,
    skipped: list[str],
    httpx_path: Path,
    returncode: int,
) -> dict[str, Any]:
    pending_by_key: dict[str, deque[str]] = defaultdict(deque)
    pending_by_host: dict[str, deque[str]] = defaultdict(deque)

    for raw_url in input_urls:
        pending_by_key[relaxed_key(raw_url)].append(raw_url)
        pending_by_host[host_key(raw_url)].append(raw_url)

    matched: dict[str, dict[str, Any]] = {}
    unmatched_hits: list[dict[str, Any]] = []

    for hit in parsed_hits:
        raw_url = match_raw_url(hit["url"], pending_by_key, pending_by_host)
        if raw_url is None:
            unmatched_hits.append(hit)
            continue

        matched[raw_url] = {
            "url": hit["url"],
            "raw": raw_url,
            "reachable": hit["reachable"],
            "status": hit["status"],
            "title": hit["title"],
            "server": hit["server"],
            "category": hit["category"],
            "location": hit["location"],
            "responseTime": hit["responseTime"],
            "contentLength": hit["contentLength"],
            "method": hit["method"],
        }

    items: list[dict[str, Any]] = []
    stats = {"live": 0, "ok": 0, "blocked": 0, "warn": 0, "down": 0}

    for raw_url in input_urls:
        item = matched.get(
            raw_url,
            {
                "url": raw_url,
                "raw": raw_url,
                "reachable": False,
                "status": "",
                "title": "",
                "server": "",
                "category": "down",
                "location": "",
                "responseTime": "",
                "contentLength": "",
                "method": "",
            },
        )
        items.append(item)
        if item["reachable"]:
            stats["live"] += 1
        stats[item["category"]] += 1

    return {
        "title": title,
        "generatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "sourceFile": str(source_file),
        "httpxPath": str(httpx_path),
        "httpxReturnCode": returncode,
        "total": len(items),
        "live": stats["live"],
        "ok": stats["ok"],
        "blocked": stats["blocked"],
        "warn": stats["warn"],
        "down": stats["down"],
        "items": items,
        "skippedInputs": skipped,
        "unmatchedHits": unmatched_hits,
    }


def relaxed_key(value: str) -> str:
    try:
        parsed = urlsplit(value)
    except ValueError:
        return value.lower()

    host = (parsed.hostname or parsed.netloc or "").lower()
    port = parsed.port
    default_port = 443 if parsed.scheme.lower() == "https" else 80 if parsed.scheme.lower() == "http" else None
    port_part = "" if port in (None, default_port) else f":{port}"
    path = parsed.path or "/"
    query = f"?{parsed.query}" if parsed.query else ""
    return f"{host}{port_part}{path}{query}"


def host_key(value: str) -> str:
    try:
        parsed = urlsplit(value)
    except ValueError:
        return value.lower()
    return (parsed.hostname or parsed.netloc or value).lower()


def match_raw_url(
    probed_url: str,
    pending_by_key: dict[str, deque[str]],
    pending_by_host: dict[str, deque[str]],
) -> str | None:
    key = relaxed_key(probed_url)
    if pending_by_key[key]:
        return pending_by_key[key].popleft()

    host = host_key(probed_url)
    if pending_by_host[host]:
        return pending_by_host[host].popleft()

    return None


def write_dashboard(*, template_path: Path, report: dict[str, Any], output_path: Path) -> None:
    template = read_text(template_path)
    safe_json = json.dumps(report, ensure_ascii=False, indent=2).replace("</", "<\\/")
    rendered = template.replace("__URL_PROBE_DATA__", safe_json)
    write_text(output_path, rendered)


if __name__ == "__main__":
    raise SystemExit(main())
