---
name: httpx-url-dashboard
description: Probe large URL lists with a local httpx binary, normalize the results, and generate a grouped browser-openable HTML dashboard plus JSON/debug artifacts. Use when Codex is given a txt file of http/https URLs and needs to rerun the prior "httpx 探测 URL 存活并生成 HTML 页面" workflow, especially on Windows with a user-provided httpx.exe path or the common local path under Z:\BaiduNetdiskDownload\Tools\信息收集\子域名爆破\HTTPX.
role: bridge
domain: recon-traffic-mcp
---

# HTTPX URL Dashboard

Use this skill to turn a URL txt file into:

- `url_probe_data.json`
- `url_probe_dashboard.html`
- `debug/clean_urls_valid.txt`
- `debug/httpx_scan_*.txt`

The generated HTML already supports:

- same-domain folding
- keyword search
- category filters
- sorting
- visited-state tracking in `localStorage`
- quick-open for the first visible results

## Workflow

1. Confirm the input txt path.
2. Resolve the `httpx` executable.
3. Choose a stable output directory.
4. Run the bundled script instead of calling `httpx -o` directly.
5. Verify that JSON and HTML were generated and report the key counts back to the user.

## Resolve Paths

- Prefer the user-provided `httpx.exe` path.
- Accept either the binary path or the containing directory.
- If the user does not provide it, first try:
  - `Z:\BaiduNetdiskDownload\Tools\信息收集\子域名爆破\HTTPX\httpx.exe`
- If the input file already lives in an `artifacts\url_probe` directory, reuse that directory as output.
- Otherwise prefer `<workspace>\artifacts\url_probe`.

## Run

Use:

```powershell
python "C:\Users\zhang\.codex\skills\httpx-url-dashboard\scripts\build_httpx_url_dashboard.py" `
  --input "Z:\path\to\url.txt" `
  --httpx "Z:\BaiduNetdiskDownload\Tools\信息收集\子域名爆破\HTTPX" `
  --output-dir "Z:\path\to\artifacts\url_probe"
```

Optional flags:

- `--title` to override dashboard metadata title
- `--threads`
- `--rate-limit`
- `--timeout`
- `--retries`

## Important Behavior

- Strip URL fragments before probing.
- Deduplicate cleaned HTTP(S) inputs.
- Capture `httpx` stdout directly and write the raw scan log into `debug/`.
- Write JSON and HTML as UTF-8 to avoid Chinese garbling.
- Keep the original input URL in `raw` when the probed URL changes because of redirect or scheme fallback.
- Classify results as:
  - `ok`: `2xx`
  - `blocked`: `401` or `403`
  - `warn`: reachable but not `2xx/401/403`
  - `down`: no matched success result

## Resources

- `scripts/build_httpx_url_dashboard.py`
  - Cleans the URL list, runs `httpx`, parses the plain output, and writes JSON/HTML/debug artifacts.
- `assets/dashboard_template.html`
  - The reusable grouped dashboard template without embedded data.

## Response Pattern

After running the script, report:

- input file path
- resolved `httpx` path
- output HTML path
- output JSON path
- total/live/ok/blocked/warn/down counts

If `httpx` returns a non-zero exit code but still produces usable output, say that explicitly and keep the generated artifacts.
