---
name: object-identity-extractor
description: "Extract object identifiers and identity boundaries from traffic, responses, frontend JS, workflow maps, or logs. Use when black-box testing needs user IDs, tenant IDs, org IDs, file keys, order IDs, workflow IDs, invite/share tokens, JWTs, or other object handles to build IDOR, BOLA, cross-tenant, and role-boundary hypotheses."
role: specialist
domain: auth-api
---

# Object Identity Extractor

Use this skill after traffic or JS inventory exists. The goal is to produce candidate object and identity handles for controlled authorization testing.

## Workflow

1. Collect inputs from Burp, workflow maps, responses, JS hidden logic output, exported JSON, or page source.
2. Run the extractor:

   ```bash
   python scripts/extract_objects.py --input runs/T --out runs/T/objects
   ```

3. Review inventories before testing. Promote only values with a clear owner, tenant, route, or response context.
4. Hand off to [ab-object-pair-builder](../ab-object-pair-builder/SKILL.md) when at least two accounts, roles, tenants, or object owners exist.
5. During validation, mutate one identifier class at a time and compare baseline vs mutated response.
6. Copy promoted identifiers into the active run directory's `03_object_identity_map.md` with owner, tenant, route, and confidence.

## Identifier Classes

- object handles: document, file, order, task, workflow, project, report, invoice, share, invite
- identity handles: user, account, member, role, permission, department
- tenant boundaries: tenant, org, company, workspace, school, app id, corp id
- token-like values: JWTs, bearer tokens, share codes, invite codes, reset codes, signed URLs
- storage and frontend state keys that carry identity or tenant context

## Review Rules

- Do not treat a number as an object ID unless nearby key/path context supports it.
- Keep raw token material out of reports unless explicitly needed; the script masks tokens by default.
- Prefer values observed in responses or request parameters over values found only in static comments.
- For miniapps and SPAs, connect the identifier to the route/page/component that introduced it.
- Do not send a replay for an identifier unless it has a baseline route and an expected owner/boundary.

## Outputs

The bundled script writes:

- `object_inventory.json`
- `identity_inventory.json`
- `tenant_inventory.json`
- `token_inventory.json`
- `object_identity_summary.md`
