﻿#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import urlparse, parse_qsl

TEXT_SUFFIXES={'.txt','.json','.har','.js','.html','.md','.log','.xml','.yml','.yaml'}
SKIP_DIRS={'node_modules','.git','__pycache__'}
KEY_TERMS=r'user|uid|account|member|tenant|org|company|corp|workspace|school|role|perm|file|object|order|task|workflow|project|report|invoice|share|invite|token|jwt|code|key|id'
QUOTED_KV=re.compile(rf"(?i)[\"']?(?P<key>[a-z0-9_.-]*(?:{KEY_TERMS})[a-z0-9_.-]*)[\"']?\s*[:=]\s*[\"'](?P<value>[^\"'\s]{{2,512}})[\"']")
NUMERIC_KV=re.compile(rf"(?i)\b(?P<key>[a-z0-9_.-]*(?:{KEY_TERMS})[a-z0-9_.-]*)\b\s*[:=]\s*(?P<value>\d{{2,20}})\b")
QUERY=re.compile(rf"(?i)(?P<key>[a-z0-9_.-]*(?:{KEY_TERMS})[a-z0-9_.-]*)=(?P<value>[A-Za-z0-9_.:~/%+\-=]{{2,512}})")
UUID=re.compile(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}\b")
JWT=re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{8,}\b")
BEARER=re.compile(r"(?i)\bBearer\s+([A-Za-z0-9._~+/=-]{16,})")
URL=re.compile(r"https?://[^\s'\"`<>{}\\]+",re.I)

def iter_files(inp,max_bytes,exclude_root=None):
    p=Path(inp)
    ex=Path(exclude_root).resolve() if exclude_root else None
    if p.exists() and p.is_dir():
        for d,dirs,files in os.walk(p):
            dirs[:]=[x for x in dirs if x not in SKIP_DIRS]
            for f in files:
                fp=Path(d)/f
                
                if ex:
                    try:
                        fp.resolve().relative_to(ex); continue
                    except ValueError:
                        pass
                if fp.suffix.lower() in TEXT_SUFFIXES and fp.stat().st_size<=max_bytes: yield fp
    elif p.exists() and p.is_file() and p.stat().st_size<=max_bytes:
        if ex:
            try:
                p.resolve().relative_to(ex); return
            except ValueError:
                pass
        yield p

def read_text(p): return Path(p).read_text(encoding='utf-8-sig',errors='ignore')
def ctx(text,i,r=120): return re.sub(r'\s+',' ',text[max(0,i-r):min(len(text),i+r)]).strip()
def line_no(text,i): return text.count('\n',0,i)+1
def sha(v): return hashlib.sha256(v.encode('utf-8',errors='ignore')).hexdigest()
def mask(v): return (v[:4]+'…') if len(v)<=16 else (v[:8]+'…'+v[-6:])

def classify(key,value,context):
    k=(key or '').lower(); c=(context or '').lower()
    if any(x in k for x in ['tenant','org','company','corp','workspace','school','appid']): return 'tenant'
    if any(x in k for x in ['user','uid','account','member','role','perm','dept','department']): return 'identity'
    if any(x in k for x in ['token','jwt','bearer','access','refresh','secret','session']): return 'token'
    if any(x in k for x in ['share','invite','reset','code']): return 'token'
    if 'tenant' in c or 'org' in c: return 'tenant' if k.endswith('id') else 'object'
    return 'object'

def add(buckets,seen,category,key,value,source,line,context,raw_tokens):
    value=str(value).strip().strip("'\"`,;)")
    if len(value)<2: return
    row={'category':category,'key':key,'value':value,'source':str(source),'line':line,'context':context[:260]}
    if category=='token' and not raw_tokens:
        row['value']=mask(value); row['sha256']=sha(value); row['masked']=True
    d=(category,(key or '').lower(),row.get('sha256') or row['value'],str(source),line)
    if d in seen: return
    seen.add(d); buckets[category].append(row)

def scan(path,text,raw_tokens):
    buckets=defaultdict(list); seen=set()
    for rx in [QUOTED_KV,NUMERIC_KV,QUERY]:
        for m in rx.finditer(text):
            key=m.group('key'); value=m.group('value'); c=ctx(text,m.start())
            add(buckets,seen,classify(key,value,c),key,value,path,line_no(text,m.start()),c,raw_tokens)
    for m in UUID.finditer(text):
        c=ctx(text,m.start()); add(buckets,seen,classify('uuid',m.group(0),c),'uuid',m.group(0),path,line_no(text,m.start()),c,raw_tokens)
    for m in JWT.finditer(text):
        c=ctx(text,m.start()); add(buckets,seen,'token','jwt',m.group(0),path,line_no(text,m.start()),c,raw_tokens)
    for m in BEARER.finditer(text):
        c=ctx(text,m.start()); add(buckets,seen,'token','bearer',m.group(1),path,line_no(text,m.start()),c,raw_tokens)
    for m in URL.finditer(text):
        u=m.group(0).strip('),;]'); p=urlparse(u)
        for key,value in parse_qsl(p.query,keep_blank_values=True):
            if re.search(KEY_TERMS,key,re.I):
                c=ctx(text,m.start()); add(buckets,seen,classify(key,value,c),key,value,path,line_no(text,m.start()),c,raw_tokens)
    return buckets

def write_json(p,data): p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description='Extract object/identity/tenant/token handles from artifacts.')
    ap.add_argument('--input',required=True); ap.add_argument('--out',required=True); ap.add_argument('--max-file-mb',type=float,default=10.0); ap.add_argument('--raw-tokens',action='store_true')
    a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); max_bytes=int(a.max_file_mb*1024*1024)
    buckets={'object':[],'identity':[],'tenant':[],'token':[]}; files=0
    for path in iter_files(a.input,max_bytes,out):
        files+=1; found=scan(path,read_text(path),a.raw_tokens)
        for k in buckets: buckets[k].extend(found.get(k,[]))
    for cat,rows in list(buckets.items()):
        seen=set(); ded=[]
        for r in rows:
            d=((r.get('key') or '').lower(),r.get('sha256') or r.get('value'))
            if d in seen: continue
            seen.add(d); ded.append(r)
        buckets[cat]=ded
    write_json(out/'object_inventory.json',{'items':buckets['object'],'count':len(buckets['object'])})
    write_json(out/'identity_inventory.json',{'items':buckets['identity'],'count':len(buckets['identity'])})
    write_json(out/'tenant_inventory.json',{'items':buckets['tenant'],'count':len(buckets['tenant'])})
    write_json(out/'token_inventory.json',{'items':buckets['token'],'count':len(buckets['token']),'raw_tokens':a.raw_tokens})
    keys=Counter(r.get('key') for rows in buckets.values() for r in rows)
    md=['# Object Identity Summary','',f'- scanned files: {files}',f"- objects: {len(buckets['object'])}",f"- identities: {len(buckets['identity'])}",f"- tenants: {len(buckets['tenant'])}",f"- tokens: {len(buckets['token'])} ({'raw' if a.raw_tokens else 'masked'})",'','## Top keys']+[f'- {c} `{k}`' for k,c in keys.most_common(30)]
    (out/'object_identity_summary.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'out':str(out),'files':files,'counts':{k:len(v) for k,v in buckets.items()}},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
