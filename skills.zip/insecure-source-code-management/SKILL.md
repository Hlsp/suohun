---
name: insecure-source-code-management
description: "Insecure source code management exposure playbook. Use when .git, .svn, .hg, backup refs, repository metadata, build artifacts, or leaked source bundles may disclose code, secrets, routes, or internal package names."
role: specialist
domain: general-security
---

# Insecure Source Code Management

Check `.git`, `.svn`, `.hg`, backups, source archives, CI artifacts, sourcemaps, and build manifests. Recover routes, configs, secret names, internal package names, and deployment clues, then feed API/auth/business/dependency skills.
