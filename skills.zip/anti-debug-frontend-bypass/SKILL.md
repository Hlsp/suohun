---
name: anti-debug-frontend-bypass
description: Identify and neutralize common browser-side anti-debug and anti-instrumentation patterns with the smallest reversible patch. Use when debugger traps, console detection, timing checks, hook tampering, or self-defending wrappers block frontend reverse engineering.
role: specialist
domain: browser-frontend-reverse
---

# Anti Debug Frontend Bypass

Use this skill when runtime observability is the blocker. The goal is not broad tampering; it is to restore enough visibility to continue authorized analysis.

## Typical Symptoms

- instant pauses from repeated `debugger`
- console opening changes page behavior
- wrapper functions detect hooks or patched natives
- timing checks fail after breakpoints
- code self-reloads, clears logs, or enters loops during inspection

## Workflow

1. Classify the symptom before patching.
2. Locate the narrowest anti-debug mechanism in source or runtime.
3. Prefer preload or wrapper-level patches over editing large bundles.
4. Keep patches reversible and minimal.
5. Re-test the target action immediately after each patch.

## Preferred Moves

- neutralize repeated `debugger` traps
- patch detection helpers instead of broad global APIs
- override one timing or integrity check at a time
- keep original function behavior where possible

## Avoid

- blanket disabling half the runtime without understanding the check
- mixing anti-debug patching with protocol conclusions
- claiming a server-side restriction is bypassed when only local observability improved

## Useful Tool Patterns

- `search_in_sources`
- `set_breakpoint_on_text`
- `inject_preload_script`
- `evaluate_script`
- `hook_function`

## Handoff Rules

- Once visibility is restored, return to `complex-js-reverse` or `request-chain-tracer`
- If the app still fails only in a specific platform runtime, consider `wechat-miniapp-cdp-debug` or a platform-specific workflow instead of deeper browser patching

## Output

Return:

- anti-debug mechanism identified
- patch point chosen
- minimal patch applied or proposed
- remaining risks or unresolved protections
