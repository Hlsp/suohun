# Target Start Mandatory Order 2026-05-02

When the user gives a URL and asks to test the target:

1. browser MCP open
2. live request capture
3. page / script / console / storage inspection
4. business-shape judgment
5. one baseline request
6. one-variable mutation
7. only after 80 percent certainty, public search if still needed
