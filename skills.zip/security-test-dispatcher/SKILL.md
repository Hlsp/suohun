---
name: security-test-dispatcher
description: "Second-stage dispatcher under zhang-web-src-default-runner for already-authorized Web/SRC work. Use when explicitly named or when the P0 runner has chosen generic dispatch; selects no-login, logged-in A/B, JS hidden logic, API authorization, business logic, miniapp, Burp/Yak traffic, replay, evidence, and reporting lanes. Do not use as the default P0 entry."
role: router
domain: entry-routing
---

# Security Test Dispatcher

Use this as a second-stage dispatcher under `zhang-web-src-default-runner`, not as the default P0 entry. Its job is to select the smallest useful skill chain after the P0 runner has established that the task is generic authorized Web/SRC testing.

## Default Assumptions

- Only URL or login page -> no-login black-box first, and open it with MCP browser before shell-side probing.
- Credentials, cookies, roles, tenants, or tokens -> logged-in A/B matrix.
- Burp/Yak/HAR/browser traffic exists -> traffic is the source of truth.
- WeChat miniapp, wxapkg, CDP, remote debug, or decompiled source -> miniapp dynamic + static.
- Java clues such as `JSESSIONID`, `.do`, `.action`, Tomcat/Spring/Struts/Shiro/JSP, stack traces -> enable Java/Ghost Bits as a bounded bypass lane.
- Request signing/encryption -> recover request wrapper before replay.
- If endpoint probing is weak -> switch to JS hidden logic instead of repeating broad probes.

## Dispatch Matrix

| Evidence / user prompt | Load these skills first | Purpose |
|---|---|---|
| only target URL / login page | `blackbox-pentest-runner` -> `preauth-blackbox-runner` -> `browser-pentest-orchestrator` | public routes, docs, anonymous APIs, login-page 0-to-1 baseline |
| login page stuck | `preauth-js-hidden-logic-hunter` -> `authbypass-authentication-flaws` -> `account-binding-invite-delegation-abuse` -> `api-recon-and-docs` | JS/API, reset/register/invite, docs/schema, edge-asset pivot |
| JS, hidden logic, SPA, Umi, webpack | `preauth-js-hidden-logic-hunter` -> `webpack-runtime-extractor` -> `request-chain-tracer` | hidden routes, wrappers, feature flags, disabled actions |
| credentials / roles / tenants | `auth-role-matrix-runner` -> `object-identity-extractor` -> `ab-object-pair-builder` -> `single-variable-replay-harness` | A/B BOLA, BOPLA, BFLA, cross-tenant, role boundary |
| API / Swagger / OpenAPI / GraphQL | `api-sec` -> `api-recon-and-docs` -> `api-authorization-and-bola` | base paths, model fields, object/property/function authorization |
| business logic / payment / membership / approval | `blackbox-business-logic-hunter` -> matching domain skill -> `workflow-state-diff-lab` | workflow state, money/quota/reward, approval/task abuse |
| file / export / preview / share | `file-access-vuln` -> `export-preview-sharing-logic-abuse` -> `single-variable-replay-harness` | file/object access, link/token reuse, share/export boundaries |
| upload / import / report / async job | `upload-insecure-files` -> `arbitrary-write-to-rce` -> `race-condition` | accept-store-process-retrieve pipeline and job effects |
| miniapp / wxapkg / CDP | `miniapp-dynamic-static-runner` -> `wechat-miniapp-cdp-debug` -> `request-chain-tracer` | runtime/static correlation, wrapper/signature/token lineage |
| Burp/Yak/HTTP history | `capture-bootstrap-check` -> `burp-scope-traffic-dumper` / `yak-mcp-playbook` -> `traffic-dedupe-prioritizer` | deduped workflow map and high-value replay queue |
| need final report | `logic-evidence-pack` -> `results-storage` -> `pentest-report` | concise reproducible evidence and severity |

## High-Value Dispatch Bias

Prefer paths in this order:

1. Anonymous data/object/file exposure.
2. Authenticated BOLA/cross-tenant read or write.
3. BOPLA/mass-assignment/property mutation.
4. Workflow/payment/account-recovery state abuse.
5. File/export/share/token bridge exposure.
6. Upload/import/report job to read/write/RCE/SSRF.
7. Frontend/miniapp crypto reconstruction that enables replay.
8. Cache/parser/framework discrepancy with proven impact.
9. Classic injection only when a realistic sink and impact path exists.

## Start-Test Procedure

1. Infer the scene and announce one short skill chain.
2. If the run will continue beyond one turn, create a run directory with `zhang-web-src-default-runner/scripts/init_src_run.py`.
3. Establish capture quality with MCP browser first: page open, selected page, network capture, script/console/state. Use Burp/Yak and shell only after this baseline exists.
4. Build one baseline flow before mutation.
5. Extract identity, object, state, amount/quota, token, and request-order variables.
6. Mutate exactly one variable.
7. Compare backend data/state/session/token/file impact, not only HTTP status.
8. If blocked, pivot by evidence:
   - no public APIs -> JS hidden logic
   - missing object handles -> object identity extraction
   - credentials appear -> A/B role matrix
   - signing/encryption -> request-chain/crypto recovery
   - Java/parser clues -> Ghost Bits/parser-diff lane
9. Package evidence paths and next action.

## Anti-Theory Gate

After a target or traffic source is available, the next response must contain at least one concrete artifact or action:

- `RUN_DIR`
- `BASELINE_TO_CAPTURE`
- raw request path
- Burp/Yak traffic slice
- object/identity map
- one queued mutation
- replay diff or abandon reason

Do not continue with only categories, article-derived advice, or generic methodology.

## Response Style

When starting, return:

1. inferred scene
2. selected skills
3. first concrete actions
4. what evidence will decide the next pivot

Do not dump a generic vulnerability checklist at startup. Route first, then execute.
