---
name: nosql-injection
description: "NoSQL injection playbook. Use when JSON, MongoDB-style operators, document filters, search DSLs, aggregation pipelines, GraphQL variables, or object parameters may change database query semantics."
role: specialist
domain: injection-server
---

# NoSQL Injection

Use this skill when user input may become a document query, operator object, aggregation stage, search DSL, or JSON expression.

## Core Model

NoSQL injection is usually a type and structure bug:

1. Client input is parsed as JSON, form data, GraphQL variables, or nested object notation.
2. The server passes user-controlled keys or objects into a database query.
3. Operators, regexes, arrays, projections, or pipeline stages change query semantics.
4. The result changes authentication, authorization, filtering, data exposure, or state updates.

Focus on structure, not only special characters.

## Recon Questions

- Does the endpoint accept JSON objects, arrays, nested parameters, or bracket notation?
- Which fields are used for login, search, filters, roles, tenant IDs, or update selectors?
- Does the stack look like MongoDB, Mongoose, CouchDB, Elasticsearch, Firebase, DynamoDB, or a search DSL?
- Are unknown keys stripped, preserved, merged, or interpreted as operators?
- Does validation happen before or after JSON/body parsing?
- Can the same parameter be sent as scalar, array, and object?

## Test Families

### Operator Injection

Test whether user-controlled keys are interpreted as query operators instead of literal field names. High-value places are login, reset, lookup, role checks, and tenant filters.

### Type Confusion

Switch scalar values to arrays, objects, booleans, null, numbers, and empty structures. Compare status, row count, error messages, and response shape.

### Regex and Search Abuse

Search endpoints may expose regex behavior, wildcard expansion, expensive queries, or unexpected matches. Keep tests low volume and bounded.

### Projection and Field Exposure

Check whether projection, include/exclude fields, populate, expand, or select parameters expose hidden fields such as roles, tokens, internal IDs, or tenant metadata.

### Aggregation and Update Pipelines

If the API accepts pipeline-like structures, test whether user input controls stages, match conditions, group keys, or update operators.

## Validation Ladder

1. Capture a stable baseline query and result count.
2. Vary data type while keeping semantic value similar.
3. Test nested object/operator acceptance.
4. Prove semantic change with controlled accounts or records.
5. Check whether hidden fields or cross-tenant objects become visible.
6. Remove test documents and restore modified state.

## Evidence Standard

Capture:

- baseline request and expected result set
- mutated JSON/body structure
- response diff or auth/authorization change
- inferred database/query layer
- controlled record proving impact
- cleanup step

## Pivots

- API auth and BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- GraphQL variables: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
- Prototype pollution merge sinks: [prototype-pollution](../prototype-pollution/SKILL.md)
- SQL-like backend instead: [sqli-sql-injection](../sqli-sql-injection/SKILL.md)
