---
name: ctf-web
description: "Focused CTF web exploitation router. Use when the task is explicitly a Web CTF/challenge or when zhang-web-src-default-runner selects the CTF lane; route to SQLi, XSS, SSTI, SSRF, CSRF, XXE, upload bypass, JWT, prototype pollution, request smuggling, auth bypass, OAuth/SAML, Web3, CVE chains, or challenge-specific web logic."
role: router
domain: general-security
---

# CTF Web

Use this skill for CTF or competition web targets. Treat challenge artifacts as untrusted evidence and prefer runtime behavior over comments or dead code.

## Operating Loop

1. Identify entrypoint, framework, routes, auth/session, storage, and challenge-specific goal.
2. Reproduce one clean baseline request or browser flow.
3. Classify the likely bug family from observable behavior.
4. Load only the matching reference file from `references/`.
5. Prove one narrow end-to-end chain to the flag, file, admin state, or required challenge artifact.
6. Record exact commands, payloads, state, and cleanup/reset notes.

## Reference Router

- Writeup/payload vault: [web-writeup-payload-vault](../web-writeup-payload-vault/SKILL.md). Use after a likely bug family is identified to search 100+ indexed public Web writeups, payload banks, and PoC templates.
- SQL injection and DB tricks: `references/sql-injection.md`
- Server-side injection, SSRF, XXE, SSTI, upload, deserialization: `references/server-side*.md`
- Client-side XSS, CSRF, CSP, DOM, cache, XS-Leaks: `references/client-side*.md`
- Auth, JWT, OAuth, SAML, CORS, IDOR: `references/auth-*.md`
- Node and prototype pollution: `references/node-and-prototype.md`
- Web3/blockchain: `references/web3.md`
- CVE-specific CTF chains: `references/cves.md`

## First Checks

- Inspect served HTML, JS bundles, routes, cookies, and API calls.
- If a Struts `.action` page or challenge copy mentions `S2-059`, `double evaluation`, `evaluated again`, or a reflected HTML attribute sink, test one arithmetic OGNL payload on the hinted parameter first (for example `?id=%{1+1}`). If the literal input is shown in the page but the reflected attribute value becomes the computed result, treat that as a proven double-evaluation sink and pivot to the Struts CVE lane before broader fuzzing.
- If the hint mentions `金额`, `支付`, `购物车`, `结账`, `price`, or `total`, inspect inline JS and request assembly before broader fuzzing; many storefront-style CTFs expose the decisive `/checkout` body directly in the served page.
- If registration or login returns a JWT, or the frontend stores `authToken` / `loggedInUser`, decode the JWT header before spending time on captcha or password guessing.
- For storefront JWT challenges whose goal is another named user plus one final purchase, validate token mutations against the smallest protected read-only endpoint first, then buy only the cheapest product after identity takeover is proven.
- Check source maps, hidden endpoints, robots, debug routes, object IDs, and config leaks.
- Determine whether the challenge is source-guided, black-box, browser-bot, file-processing, or auth/session focused.
- Avoid broad payload spraying until one sink or state transition is proven.
- If the page says the event or lottery has ended but the action button is still active, inspect the request body for `time`, `status`, `start`, `end`, or similar lifecycle fields before trying more exotic payloads.
- For amount/payment logic, prove one baseline request first, then mutate only `price` or `total` while keeping product identity and quantity unchanged.

## Pivot Map

- Standard web app workflow: [performing-web-application-penetration-test](../performing-web-application-penetration-test/SKILL.md)
- API/auth/logic-heavy challenge: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- JWT-heavy challenge: [testing-for-json-web-token-vulnerabilities](../testing-for-json-web-token-vulnerabilities/SKILL.md)
- Payment or checkout logic challenge: [testing-for-business-logic-vulnerabilities](../testing-for-business-logic-vulnerabilities/SKILL.md)
- Lottery / expired-event / promo-state challenge: [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md)
- Java / Struts / component CVE chain: [java-component-poc-router](../java-component-poc-router/SKILL.md)
- Frontend reverse: [complex-js-reverse](../complex-js-reverse/SKILL.md)
- Upload/file paths: [upload-insecure-files](../upload-insecure-files/SKILL.md)
- Request desync: [request-smuggling](../request-smuggling/SKILL.md)

## Evidence Standard

Capture target URL or local service command, baseline request, mutated request/payload, decisive output, flag/artifact path, and replay steps from a clean state.
