---
name: portal-workflow-task-abuse
description: "Portal, OA, eHall, workflow, task-center, approval, form, and bridge-token abuse playbook. Use when list-detail-write chains, task APIs, iframe jump links, or cross-system bridge tokens may expose sensitive workflow data or enable cross-user actions."
role: specialist
domain: business-logic
---

# Portal Workflow Task Abuse

Recover list -> detail -> process/data -> write/approve/export/bridge. Test object ID swaps, malformed-ID token leaks, browserless token replay, hidden approval/admin endpoints, and low-risk cross-user state writes.
