---
name: burp-scope-traffic-dumper
description: "Dump, filter, and normalize Burp Suite MCP Proxy history for scoped black-box testing. Use when Codex needs to pull or process Burp traffic, keep only in-scope requests, deduplicate endpoints, and create clean inputs for preauth, authenticated role testing, JS hidden logic mining, or evidence packaging."
role: bridge
domain: recon-traffic-mcp
---

# Burp Scope Traffic Dumper

Use this skill to turn Burp history into stable workspace artifacts before analysis. It is intentionally thin: capture with Burp MCP, then normalize locally.

## Workflow

1. Confirm capture is working with [capture-bootstrap-check](../capture-bootstrap-check/SKILL.md) when traffic is empty or suspicious.
2. Pull scoped history through Burp MCP, preferring regex-scoped history when possible:
   - `get_proxy_http_history_regex` for host/path filters
   - `get_proxy_http_history` when the scope is small
3. Save the raw MCP response under the run directory, for example:

   ```text
   runs/T/burp/burp_history_raw.json
   ```

4. Normalize and filter it:

   ```bash
   python scripts/filter_burp_history.py --input runs/T/burp/burp_history_raw.json --scope 'example\\.com|api\\.example\\.com' --out runs/T/burp
   ```

5. Feed `burp_urls.txt` or `burp_filtered.json` into:
   - [traffic-dedupe-prioritizer](../traffic-dedupe-prioritizer/SKILL.md)
   - [traffic-to-workflow-mapper](../traffic-to-workflow-mapper/SKILL.md)
   - [preauth-blackbox-runner](../preauth-blackbox-runner/SKILL.md)
   - [preauth-js-hidden-logic-hunter](../preauth-js-hidden-logic-hunter/SKILL.md)

## Filtering Rules

- Keep raw and filtered artifacts separate.
- Filter by positive scope first, then exclude analytics, fonts, images, and CDN noise.
- Preserve method, URL, status, content type, request, response, and source index when available.
- Deduplicate by method + scheme/host/path + parameter-name shape, not by full URL value only.
- If Burp history is empty, do not continue analysis until the browser/proxy/certificate path is verified.

## Outputs

The bundled script writes:

- `burp_filtered.json` - filtered records with best-effort normalized fields
- `burp_urls.txt` - method and URL list for triage scripts
- `burp_endpoint_summary.json` - endpoint groups and parameter shapes
- `burp_scope_summary.md` - human summary of kept, dropped, methods, statuses, and top paths
