﻿#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import urlparse, parse_qsl

STATIC_SUFFIXES=('.js','.mjs','.css','.png','.jpg','.jpeg','.gif','.svg','.ico','.woff','.woff2','.ttf','.eot','.map','.mp4','.webp')

def load_any(path):
    text=Path(path).read_text(encoding='utf-8-sig',errors='ignore')
    try: return json.loads(text)
    except json.JSONDecodeError:
        rows=[]
        for line in text.splitlines():
            line=line.strip()
            if not line: continue
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: rows.append(line)
        return rows if rows else text

def flatten(obj):
    if isinstance(obj,list):
        for x in obj: yield from flatten(x)
    elif isinstance(obj,dict):
        if {'url','request','response','method','status','status_code','host','path'} & set(obj): yield obj
        for k in ('items','history','results','messages','data','entries','log'):
            if isinstance(obj.get(k),(list,dict)): yield from flatten(obj[k])
    elif isinstance(obj,str): yield obj

def header(raw,name):
    m=re.search(rf'(?im)^\s*{re.escape(name)}\s*:\s*(.+?)\s*$',raw or '')
    return m.group(1).strip() if m else None

def first(*vals):
    for v in vals:
        if v not in (None,''): return v
    return None

def parse_req(raw):
    if not raw: return None,None
    first_line=raw.splitlines()[0] if raw.splitlines() else ''
    m=re.match(r'^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|TRACE)\s+(\S+)\s+HTTP/',first_line,re.I)
    if not m: return None,None
    method=m.group(1).upper(); target=m.group(2)
    if target.startswith(('http://','https://')): return method,target
    host=header(raw,'Host')
    return method,('https://'+host+target if host else None)

def norm_record(rec,idx):
    if isinstance(rec,str):
        m,u=parse_req(rec); return {'index':idx,'method':m,'url':u,'status':None,'request':rec,'response':None}
    req=rec.get('request'); resp=rec.get('response'); rd=req if isinstance(req,dict) else {}; rs=resp if isinstance(resp,dict) else {}
    req_raw=req if isinstance(req,str) else first(rd.get('raw'),rd.get('text'),rd.get('message'),rec.get('request_raw'))
    resp_raw=resp if isinstance(resp,str) else first(rs.get('raw'),rs.get('text'),rs.get('message'),rec.get('response_raw'))
    method=first(rec.get('method'),rd.get('method')); url=first(rec.get('url'),rec.get('request_url'),rec.get('requestUrl'),rd.get('url'),rd.get('uri'))
    if (not method or not url) and req_raw:
        rm,ru=parse_req(req_raw); method=method or rm; url=url or ru
    if not url and rec.get('host') and rec.get('path'): url='https://'+str(rec.get('host')).strip('/')+str(rec.get('path'))
    status=first(rec.get('status'),rec.get('status_code'),rec.get('statusCode'),rs.get('status'),rs.get('status_code'),rs.get('statusCode'))
    ctype=first(rec.get('content_type'),rec.get('contentType'),rs.get('content_type'),rs.get('mime_type')) or header(resp_raw,'Content-Type')
    return {'index':idx,'method':str(method).upper() if method else None,'url':url,'status':status,'content_type':ctype,'request':req_raw,'response':resp_raw,'source_record':rec}

def endpoint_key(i):
    p=urlparse(i.get('url') or ''); names=sorted({k for k,_ in parse_qsl(p.query,keep_blank_values=True)})
    return ' '.join([i.get('method') or 'GET',p.scheme,p.netloc.lower(),p.path.rstrip('/') or '/','&'.join(names)])

def is_static(url): return urlparse(url or '').path.lower().endswith(STATIC_SUFFIXES)

def main():
    ap=argparse.ArgumentParser(description='Filter saved Burp MCP history output.')
    ap.add_argument('--input',required=True); ap.add_argument('--scope'); ap.add_argument('--include'); ap.add_argument('--exclude'); ap.add_argument('--include-static',action='store_true'); ap.add_argument('--out',required=True)
    a=ap.parse_args(); records=list(flatten(load_any(a.input)))
    scope=re.compile(a.scope,re.I) if a.scope else None; inc=re.compile(a.include,re.I) if a.include else None; exc=re.compile(a.exclude,re.I) if a.exclude else None
    kept=[]; dropped=Counter()
    for idx,rec in enumerate(records):
        item=norm_record(rec,idx); url=item.get('url') or ''
        if not url: dropped['no_url']+=1; continue
        if scope and not scope.search(url): dropped['out_of_scope']+=1; continue
        if inc and not inc.search(url): dropped['include_miss']+=1; continue
        if exc and exc.search(url): dropped['exclude_hit']+=1; continue
        if not a.include_static and is_static(url): dropped['static_asset']+=1; continue
        kept.append(item)
    groups=defaultdict(lambda:{'count':0,'statuses':Counter(),'examples':[]}); dedup={}
    for item in kept:
        k=endpoint_key(item); dedup.setdefault(k,item); g=groups[k]; g['count']+=1; g['statuses'][str(item.get('status'))]+=1
        if len(g['examples'])<3: g['examples'].append({'method':item.get('method'),'url':item.get('url'),'status':item.get('status')})
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    (out/'burp_filtered.json').write_text(json.dumps(kept,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'burp_urls.txt').write_text('\n'.join(f"{i.get('method') or 'GET'} {i.get('url')}" for i in kept)+('\n' if kept else ''),encoding='utf-8')
    summary={'input_count':len(records),'kept_count':len(kept),'deduped_endpoint_count':len(dedup),'dropped':dict(dropped),'methods':dict(Counter(i.get('method') or 'GET' for i in kept)),'statuses':dict(Counter(str(i.get('status')) for i in kept)),'endpoints':[{'key':k,'count':v['count'],'statuses':dict(v['statuses']),'examples':v['examples']} for k,v in sorted(groups.items(),key=lambda kv:kv[1]['count'],reverse=True)]}
    (out/'burp_endpoint_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    top=Counter(urlparse(i.get('url') or '').path for i in kept).most_common(20)
    md=['# Burp Scope Summary','',f'- input records: {len(records)}',f'- kept requests: {len(kept)}',f'- deduped endpoints: {len(dedup)}',f'- dropped: {dict(dropped)}','','## Top paths']+[f'- {c} `{p}`' for p,c in top]
    (out/'burp_scope_summary.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'out':str(out),'kept':len(kept),'deduped':len(dedup),'dropped':dict(dropped)},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
