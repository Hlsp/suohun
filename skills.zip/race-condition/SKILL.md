---
name: race-condition
description: "Race condition and TOCTOU testing playbook. Use when one-time operations, quota, payment, inventory, invite, reward, reset, approval, or state transitions may be abused through concurrent requests."
role: specialist
domain: business-logic
---

# Race Condition

Use this skill when a workflow has a check-then-update, one-time action, balance deduction, quota decrement, or state transition that might not be atomic.

## Core Model

A race condition exists when concurrent requests observe the same valid pre-state and more than one request commits a result that should be unique.

Typical pattern:

1. Check state: balance, coupon unused, invite pending, item available, token valid.
2. Perform side effect: issue reward, deduct stock, transfer funds, create order, approve task.
3. Update state: mark used, reduce quota, close task, consume token.
4. Concurrency gap lets multiple requests pass step 1 before step 3 is durable.

## High-Value Targets

Prioritize operations with measurable business impact:

- coupon, promo, trial, reward, referral, check-in, points, wallet
- purchase, refund, withdrawal, transfer, invoice, order cancellation
- stock reservation, ticket booking, quota purchase, rate-limit counters
- password reset, email verification, MFA recovery, invite acceptance
- workflow approval, task claim, role grant, tenant/admin changes
- export/share/download generation with one-time or expiring tokens

## Recon Questions

- What state changes from before to after the request?
- Which response fields indicate success, duplicate success, or partial success?
- Is there an idempotency key, nonce, lock, transaction ID, or unique constraint?
- Does the client generate request IDs or does the server assign them?
- Are side effects synchronous or queued: email, order, ledger, job, webhook?
- Can the same request be replayed across tabs, devices, sessions, or accounts?

## Test Families

### Duplicate Success

Send a small burst of identical requests and compare committed state. A single success with multiple 200 responses is weaker than multiple committed side effects.

### Split-Object Race

Race the same action while changing target object, coupon, recipient, tenant, device, or payment method to find locks scoped too narrowly.

### Cross-Step Race

Race state changes across endpoints: apply coupon while checking out, cancel while refunding, verify while changing email, claim while leaving tenant.

### Idempotency Failure

Reuse, omit, or swap idempotency keys. Test whether keys are scoped to user, action, amount, cart, tenant, and time window.

### Async Worker Race

When responses are queued, poll downstream state: ledger rows, emails, jobs, inventory, exports, and audit logs. The bug may appear after workers process duplicates.

## Validation Ladder

1. Establish a clean baseline and exact expected state delta.
2. Capture one minimal state-changing request.
3. Run a low-volume burst first, then increase only if needed and allowed.
4. Change one variable at a time: concurrency count, account, object, idempotency key, transport.
5. Verify committed state from the server, not just response counts.
6. Package repeatable evidence with before/after state and timestamps.
7. Revert purchases, rewards, roles, exports, or test data where possible.

## Evidence Standard

Capture:

- baseline state before the race
- request template and variables held constant
- concurrency count and timing method
- all response IDs/statuses
- final authoritative state: balance, ledger, role, object, inventory, quota
- duplicate side effect proof
- cleanup or rollback result

## Pivots

- Business logic workflow mapping: [business-logic-vulnerabilities](../business-logic-vulnerabilities/SKILL.md)
- State diffing: [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md)
- Race harness templates: [logic-race-harness](../logic-race-harness/SKILL.md)
- Payment/reward abuse: [payment-promo-rewards-abuse](../payment-promo-rewards-abuse/SKILL.md)
- Evidence pack: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
