---
name: expression-language-injection
description: "Expression Language injection playbook for SpEL, OGNL, EL, MVEL, JEXL, and related evaluators. Use when user input may be evaluated inside templates, validation messages, rule engines, dynamic property access, or expression-backed workflows."
role: specialist
domain: injection-server
---

# Expression Language Injection

Look for `${...}`, `#{...}`, OGNL, SpEL, EL, formulas, rule engines, or workflow expressions. Validate harmless literals first, then property reads, then method/bean/class/file/network capability only if safe.
