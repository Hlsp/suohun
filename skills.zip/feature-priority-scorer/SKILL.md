---
name: feature-priority-scorer
description: "High-value feature scoring skill for black-box security testing. Use when a target has many pages or APIs and you need to rank features by likely business-logic payoff before spending time on deep testing."
role: specialist
domain: business-logic
---

# Feature Priority Scorer

Use this to rank pages, APIs, or workflows before deep testing.

## Scoring Dimensions

Score each 0-3: Money, Write, Object Density, One-Time Constraint, Role Complexity, Bridge/Token, Replayability, Async/Race Potential, Hidden UI Signal.

## Interpretation

- `18+`: deep test first.
- `12-17`: second lane or targeted probe.
- `0-11`: deprioritize unless a strong signal appears.

## Output

For each feature return total score, why it is high, first three hypotheses, and recommended next skill.

## Script

- `scripts/score_features.py`: score JSON or CSV feature lists.
