#!/usr/bin/env python3
"""Score feature candidates for black-box business-logic testing.
Input JSON: [{"name":"checkout","money":3,"write":3,...}]
"""
import argparse, csv, json
from pathlib import Path
FIELDS = ["money","write","object_density","one_time","role_complexity","bridge_token","replayability","async_race","hidden_ui"]

def load(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    if path.lower().endswith(".csv"):
        return list(csv.DictReader(text.splitlines()))
    return json.loads(text)

def intval(v):
    try: return max(0, min(3, int(v)))
    except Exception: return 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    rows = []
    for item in load(args.input):
        score = sum(intval(item.get(f, 0)) for f in FIELDS)
        tier = "P0" if score >= 18 else "P1" if score >= 12 else "P2"
        rows.append({"name": item.get("name", item.get("feature", "unknown")), "score": score, "tier": tier, "first_skill": item.get("first_skill", "blackbox-business-logic-hunter")})
    rows.sort(key=lambda x: x["score"], reverse=True)
    if args.json:
        print(json.dumps(rows, ensure_ascii=False, indent=2))
    else:
        for r in rows:
            print(f"{r['tier']} {r['score']:02d} {r['name']} -> {r['first_skill']}")
if __name__ == "__main__": main()
