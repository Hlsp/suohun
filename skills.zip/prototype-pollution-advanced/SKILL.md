---
name: prototype-pollution-advanced
description: "Advanced prototype pollution playbook. Use after pollution is confirmed to find client-side gadgets, server-side option gadgets, template effects, sandbox escapes, and controlled escalation paths."
role: specialist
domain: injection-server
---

# Prototype Pollution Advanced

Use this skill only after a prototype pollution primitive is already proven. Start with [prototype-pollution](../prototype-pollution/SKILL.md) for discovery.

## Core Model

Escalation requires a gadget:

1. Polluted property is reachable in the relevant runtime.
2. A library or application reads that property as an option or security decision.
3. The read changes control flow, rendering, network request, command option, or authorization state.
4. Impact is reproducible and reversible.

## Gadget Classes

### Client-Side Rendering Gadgets

Look for polluted properties used by templates, sanitizers, router config, DOM builders, Markdown renderers, or framework options. Impact often becomes XSS.

### Server-Side Template Gadgets

Template engines may read options from shared objects. Prove option influence before testing stronger effects.

### Process and Network Option Gadgets

Node.js helpers, HTTP clients, child-process wrappers, and serializers may read inherited options. Keep proofs harmless and scoped.

### Authorization and Logic Gadgets

Polluted booleans such as role, enabled, verified, public, or debug may affect business logic if code uses loose object checks.

## Validation Ladder

1. Reproduce the pollution primitive from a clean state.
2. Determine scope: request-local, session-local, process-wide, client-only, tenant-wide.
3. Search for property reads in runtime behavior or source if available.
4. Test one candidate gadget with a harmless value.
5. Prove behavior change and then minimal impact.
6. Reset polluted state and document mitigation.

## Evidence Standard

Capture primitive, property name, scope, gadget consumer, behavior change, impact, and reset evidence.

## Pivots

- Gadget notes: [KNOWN_GADGETS.md](./KNOWN_GADGETS.md)
- XSS: [xss-cross-site-scripting](../xss-cross-site-scripting/SKILL.md)
- SSTI: [ssti-server-side-template-injection](../ssti-server-side-template-injection/SKILL.md)
- Command execution sink: [cmdi-command-injection](../cmdi-command-injection/SKILL.md)
