# Admin and middleware component quick lanes

Use this note for common Java third-party consoles, docs UIs, and middleware roots.

## Druid

Clues:

- `/druid/`
- `StatViewServlet`
- SQL monitor/static assets

Checks:

- auth defaults and exposure
- reset endpoints and datasource metadata exposure
- file/resource behavior around monitor assets

## Swagger / Knife4j

Clues:

- `/swagger-ui.html`, `/swagger-ui/`, `/doc.html`, `/knife4j/doc.html`, `/v2/api-docs`, `/v3/api-docs`

Checks:

- docs exposure
- hidden operations and schemas
- auth assumptions between UI and raw API

## H2 Console

Clues:

- `/h2-console`
- `login.jsp`

Checks:

- exposure, auth, JDBC URL manipulation, console availability

## Nacos

Clues:

- `/nacos/`
- `/nacos/v1/*`

Checks:

- auth bypass/default credential families
- config/discovery API exposure

## GeoServer

Clues:

- `/geoserver/`
- `/geoserver/web/`
- `/geoserver/rest/`

Checks:

- REST exposure
- known auth bypass / deserialization / expression lanes depending on version and module

## Solr

Clues:

- `/solr/`
- `/solr/admin/`
- `/solr/admin/info/system`

Checks:

- admin endpoints
- cores/config exposure
- configset and request handler abuse

## Jolokia

Clues:

- `/jolokia/`
- `/jolokia/list`

Checks:

- exposed JMX bridge
- read/exec restrictions

## Official-source reminder

For each confirmed family, pivot to vendor security pages or advisories before choosing CVE-specific payloads.
