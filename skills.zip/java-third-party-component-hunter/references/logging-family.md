# Logging / Log4j quick lanes

Use when attacker-controlled strings are logged or when config/admin surfaces suggest logging component exposure.

## High-signal clues

- stack traces or files naming Log4j / Logback
- upload/import/contact/search features that log raw input
- admin pages or config endpoints exposing logger settings

## Good first checks

- locate the input-to-log path first
- use non-destructive JNDI callback canaries only when justified
- inspect whether message lookups or risky appenders/features are reachable

## Vulnerability families to remember

- Log4Shell/JNDI-style message interpolation
- risky appender/plugin configuration
- config file exposure leading to secondary abuse

## Official source anchors

- Apache Log4j 2 security page
