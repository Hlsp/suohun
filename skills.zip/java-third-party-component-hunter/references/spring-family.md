# Spring family quick lanes

Use this note when runtime clues point to Spring Boot, Spring MVC, Spring Security, Spring Cloud Gateway, or adjacent starter modules.

## High-signal clues

- `Whitelabel Error Page`
- JSON error model with `timestamp`, `status`, `error`, `path`
- `/error` fallback controller behavior
- `/actuator`, `/v3/api-docs`, `/swagger-ui`
- stack traces under `org.springframework`

## Good first checks

- method/content-type matrix on likely JSON endpoints
- static resource and path normalization behavior
- actuator/doc exposure
- redirect and URL-building behavior
- auth flow and path matching assumptions

## Vulnerability families to keep in short memory

### Spring Framework path / resource handling

- Look for path normalization inconsistencies, encoded path segments, static resource mapping quirks, or container-specific parser differences.
- Example lane: Spring Framework on embedded Jetty path traversal style issues such as `CVE-2025-41242`.

### URL building / redirect trust

- `UriComponentsBuilder` and related URL parsing issues have produced open redirect, host validation, and SSRF-adjacent mistakes.
- Useful when app reflects, validates, or reuses attacker-controlled URLs.

### Spring Cloud Gateway / route predicates

- Check route matching, header trust, and management endpoints when gateway behavior appears present.

### Spring Security auth / authorization

- Focus on path matcher differences, static resource exclusions, method security assumptions, and remember-me/session behavior.

## Primary official source anchors to consult live

- Spring security advisories and CVE pages on `spring.io/security`
- GitHub advisories affecting Spring modules when vendor pages are sparse

## Triage tip

If you only have a Spring 404 shell, do **not** stop at “it is Spring”. Find the first non-404 endpoint or behavior discriminator, then route deeper.
