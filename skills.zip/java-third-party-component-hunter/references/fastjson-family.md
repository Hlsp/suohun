# Fastjson family quick lanes

Use this note when the target echoes JSON, reflects structured objects, returns `autoType is not support`, or stack traces mention `com.alibaba.fastjson`.

## High-signal clues

- `@type` affects output or errors
- responses include `autoType is not support`
- traces mention `DefaultJSONParser`, `JavaBeanDeserializer`, `TypeUtils`
- nested JSON strings plus `$ref` affect output

## Good first checks

1. POST a benign JSON object and confirm server-side parse/echo.
2. POST a minimal `@type` canary such as `java.lang.Exception`.
3. Map class allowlist/denylist boundaries.
4. Test whether string-embedded JSON can be traversed by `$ref`.

## Vulnerability families to remember

### Old-school AutoType gadget chains

- JNDI / JDBCRowSet style chains
- only relevant when dangerous classes are not blocked

### Restricted AutoType challenge paths

- challenge-style targets often allow a thin class set and require `$ref`, nested string JSON, or parser-cache tricks
- JDK version matters, especially around Java 8 vs Java 11 gadget availability

### SafeMode / denylist / cache quirks

- a target may block classic dangerous classes while still exposing useful parser-side behaviors

## Official-source reminders

- Prefer official Fastjson wiki/security guidance and GitHub advisories/releases when checking default mitigations and SafeMode expectations.
- Treat community gadget payloads as hypotheses until runtime proves them.

## Triage tip

If `@type` works for harmless classes but not dangerous ones, the target is still highly interesting. Do not prematurely conclude “patched”.
