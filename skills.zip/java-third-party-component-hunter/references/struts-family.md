# Apache Struts quick lanes

Use this when you see `.action`, `.do`, old JSP flows, multipart-heavy uploads, or OGNL-style stack traces.

## High-signal clues

- action namespace paths
- legacy upload endpoints
- parameter-to-view or expression behavior
- error output hinting at OGNL / value stack

## Good first checks

- OGNL injection canaries
- multipart parser edge cases
- namespace resolution and wildcard actions
- file upload temporary path handling

## Vulnerability families to remember

- OGNL injection series
- file upload parser flaws
- namespace / wildcard action confusion

## Official source anchors

- Apache Struts Security Bulletins (`struts.apache.org/security`)

## Triage tip

For Struts, one confirmed framework clue is usually enough to justify loading official S2 bulletins and checking the closest matching family.
