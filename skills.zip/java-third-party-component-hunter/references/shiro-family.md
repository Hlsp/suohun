# Apache Shiro quick lanes

Use this when cookies, routes, or stack traces suggest Shiro.

## High-signal clues

- `rememberMe` cookie
- `/login`, `/logout`, `/unauthorized`
- route behavior consistent with filter-chain enforcement
- stack traces or assets mentioning Shiro

## Good first checks

- rememberMe oracle
- cookie tamper behavior
- auth bypass through path or suffix differences
- route exclusions for static assets or unusual methods

## Vulnerability families to remember

- rememberMe crypto/key misuse
- auth bypass through path normalization or filter mismatch
- insecure deserialization historically chained through rememberMe ecosystems

## Official source anchors

- Apache Shiro security reports / project security pages
