---
name: java-third-party-component-hunter
description: Use when a Java target may expose or embed a vulnerable third-party framework or middleware component such as Fastjson, Struts, Shiro, Spring modules, Log4j, Druid, Nacos, GeoServer, Solr, Swagger/Knife4j, H2, Jolokia, or similar. Trigger when the user mentions java第三方组件, 中间件漏洞, framework CVE, 组件漏洞, 版本指纹, 依赖漏洞, or when runtime clues suggest a known Java component and Codex should fingerprint it, map the highest-signal official-advisory-backed checks, and prioritize a narrow proof path.
role: hunter
domain: java-jvm
---

# Java Third-Party Component Hunter

Use this skill to turn a vague “Java third-party component” hint into a focused component fingerprint and CVE hypothesis queue.

## Operating loop

1. **Fingerprint before exploit**
   - Collect runtime clues: headers, error pages, route naming, login paths, static asset names, stack traces, JSON field names, cookies, and HTML titles.
   - Prefer browser/runtime truth over broad path sprays when the app is SPA-like or heavily proxied.
2. **Classify likely component family**
   - Route the target into one or more families such as Spring, Fastjson, Shiro, Struts, Druid, Swagger/Knife4j, H2, Nacos, GeoServer, Solr, Jolokia, Log4j.
3. **Run minimal high-signal checks**
   - Verify one small set of component-specific entrypoints or canaries.
   - Avoid indiscriminate CVE spraying.
4. **Map official-advisory-backed hypotheses**
   - Use the references under `references/` to choose the shortest path from clue -> component -> likely vulnerable behavior -> narrow PoC.
5. **Prove one chain**
   - Do not stop at “looks like X”. Prove one route, parser, method, endpoint, or file effect.

## First-pass routing by clue

### Spring family

Use when you see:

- `Whitelabel Error Page`
- `/error` fallback behavior
- `application/json` 404 bodies with `timestamp/status/error/path`
- `/actuator`, `/v3/api-docs`, `/swagger-ui`
- route or exception names containing `org.springframework`

Primary checks:

- method/content-type matrices on JSON endpoints
- path normalization / static resource behavior
- actuator/swagger side doors
- known Spring module CVE lanes from `references/spring-family.md`

### Fastjson

Use when you see:

- JSON echo endpoints that reflect structured objects
- `@type` behavior, parse errors, `autoType is not support`
- stack traces containing `com.alibaba.fastjson`
- challenge hints such as 写文件, 反序列化, fastjson

Primary checks:

- minimal `@type` canaries
- string-embedded JSON plus `$ref` behavior
- class allowlist/denylist boundary mapping
- challenge-specific lanes from `references/fastjson-family.md`

### Apache Shiro

Use when you see:

- `rememberMe` cookies
- `JSESSIONID` plus Shiro login behavior
- `/login`, `/logout`, `/unauthorized.jsp`
- stack traces or assets naming `shiro`

Primary checks:

- rememberMe oracle and key-use behavior
- auth bypass / path control assumptions
- filters and route exclusions
- notes in `references/shiro-family.md`

### Apache Struts

Use when you see:

- `.action`, `.do`, `struts`, OGNL-like errors
- multipart upload flows
- taglib-era JSP patterns

Primary checks:

- OGNL injection surfaces
- file upload parser lanes
- namespace/action resolution
- notes in `references/struts-family.md`

### Apache Tomcat / JSP default webapps

Use when you see:

- default page titles such as `Apache Tomcat/9.x`
- Tomcat-branded error templates like `HTTP Status 404 – Not Found`
- JSP-specific messages such as `JSP file [/x.jsp] not found`
- local-only `403 Access Denied` pages for `/manager/html`, `/host-manager/html`, `/docs/`, or `/examples/`
- confirmed `PUT` support on ROOT or another default webapp

Primary checks:

- separate `DefaultServlet` behavior from `Jasper` behavior
  - `PUT /foo.txt` may succeed even when `PUT /foo.jsp` fails
  - mixed-case or suffixed `.Jsp`, `.jspx`, or `.jsp%20` paths may be stored as static text rather than executed
- test `partial PUT` explicitly with a correct `Content-Range`
- when testing traversal-based Tomcat lanes, use a client that preserves raw paths such as `curl --path-as-is`; do not trust client-side normalization
- treat manager/docs/examples `403` as a Tomcat-local-access clue first, not immediate proof of bad credentials or a finished bypass
- for `CVE-2025-24813`, confirm the chain in order:
  1. default page / version clue
  2. writable `DefaultServlet`
  3. working `partial PUT`
  4. raw-path preservation
  5. session-persistence trigger point

### Log4j / logging components

Use when you see:

- JNDI mention, log pattern configuration, custom appenders
- application features that log attacker-controlled strings

Primary checks:

- non-destructive callback-only JNDI canaries when appropriate
- logging path and message sink discovery
- notes in `references/logging-family.md`

### Admin consoles / middleware UIs

Use when you see or suspect:

- Druid
- Swagger UI / Knife4j
- H2 console
- Nacos
- GeoServer
- Solr
- Jolokia

Primary checks:

- default roots, static assets, API docs, JSON endpoints
- auth expectations vs actual response model
- version disclosure and known default paths
- notes in `references/admin-middleware-family.md`

## Minimal methodology for component hunts

### 1. Build a component matrix

Record:

- clue
- likely component
- confidence
- next 1-3 checks

Example:

- `Whitelabel Error Page` -> Spring Boot -> high -> `/json` method matrix, `/actuator`, path/static behavior
- `autoType is not support` -> Fastjson -> high -> `@type` canary, nested JSON + `$ref`, class-family boundary

### 2. Favor discriminators over enumeration

Good discriminators:

- one asset unique to a component
- one error string unique to a parser
- one response header or cookie pattern
- one method/content-type mismatch

Avoid:

- giant wordlists before the family is known
- fuzzing unrelated CVEs from multiple ecosystems

### 3. Use official sources first

When selecting CVE families, prefer:

- vendor advisories
- project security pages
- official docs for expected behavior

Use this skill’s references as the shortlist, then prove runtime behavior locally.

## Practical triggers and pivots

- User says **java第三方组件**, **组件漏洞**, **框架漏洞**, **版本洞** -> use this skill first.
- If Fastjson is confirmed -> pivot to `deserialization-insecure`.
- If Spring route/static/path behavior is confirmed -> pivot to `ghost-bits-java-truncation`, `path-traversal-lfi`, or `api-recon-and-docs`.
- If Shiro is confirmed -> pivot to `authbypass-authentication-flaws` or `jwt-oauth-token-attacks` as needed.
- If Struts is confirmed -> pivot to `expression-language-injection`, `upload-insecure-files`, or `cmdi-command-injection`.
- If Tomcat default webapps plus writable `DefaultServlet` are confirmed -> pivot to `java-component-poc-router` for narrow Tomcat CVE lanes before generic upload or manager guessing.
- If admin console is confirmed -> pivot to the matching specialist or `unauthorized-access-common-services`.

## References

- Spring and Spring-adjacent lanes: `references/spring-family.md`
- Fastjson lanes: `references/fastjson-family.md`
- Shiro lanes: `references/shiro-family.md`
- Struts lanes: `references/struts-family.md`
- Logging / Log4j lanes: `references/logging-family.md`
- Druid / Swagger / H2 / Nacos / GeoServer / Solr / Jolokia: `references/admin-middleware-family.md`

## Evidence standard

Capture:

- clue -> component inference
- the exact request or UI action used to verify it
- decisive response lines or stack trace snippet
- why the next CVE lane is justified
- one replayable PoC or negative result
