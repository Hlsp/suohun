---
name: csv-formula-injection
description: "CSV and spreadsheet formula injection playbook. Use when exported cells, reports, contact lists, invoices, audit logs, or spreadsheet imports include user-controlled values opened by analysts or admins."
role: specialist
domain: reporting-governance
---

# CSV Formula Injection

Use this skill when user-controlled data is exported into CSV, XLSX, or spreadsheet-like reports.

## Core Model

Formula injection is a cross-application output encoding bug:

1. User input is stored by the web app.
2. The app exports it into a spreadsheet cell.
3. Spreadsheet software interprets the cell as a formula or external reference.
4. Impact depends on who opens the file and which spreadsheet protections apply.

## Recon Questions

- Which fields are exported: name, email, comments, address, product, invoice, ticket, audit log?
- Which formats exist: CSV, XLSX, TSV, Google Sheets import, BI/reporting tools?
- Are dangerous leading characters escaped or prefixed safely?
- Who opens the export: self, admin, finance, support, tenant owner?
- Does the export preserve formulas, links, external references, or rich content?

## Test Families

### Safe Formula Marker

Use harmless formulas that visibly render a marker or calculation. Do not use destructive or external-execution formulas for routine validation.

### Cell Boundary and Encoding

Test leading characters, quotes, separators, newlines, tabs, Unicode normalization, and per-locale delimiters.

### Role and Workflow Impact

Stored values in support tickets, invoices, exports, or audit logs may be opened by privileged users. Prove the workflow with a controlled account or test export.

## Validation Ladder

1. Store a harmless marker in one exportable field.
2. Export the file and inspect raw cell content.
3. Open in the target spreadsheet environment if available.
4. Confirm formula interpretation versus safe text rendering.
5. Test escaping behavior across CSV/XLSX variants.
6. Remove stored marker data.

## Evidence Standard

Capture source field, export request, raw exported cell, spreadsheet interpretation, affected role/workflow, and cleanup.

## Pivots

- Export/share logic: [export-preview-sharing-logic-abuse](../export-preview-sharing-logic-abuse/SKILL.md)
- Stored XSS alternative: [xss-cross-site-scripting](../xss-cross-site-scripting/SKILL.md)
