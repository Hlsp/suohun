---
name: blackbox-business-shape-router
description: Use when the user gives only a URL, a thin login page, or a nearly featureless black-box site and Codex must first infer the site's business shape, trust boundaries, and likely high-impact workflows before choosing payloads or PoCs. Trigger when there is little or no hint text, when the first page is only a 404/login/splash shell, or when the main risk is that blind category guessing would waste time.
role: router
domain: business-logic
---

# Blackbox Business Shape Router

Use this skill to answer the question:

> “What kind of site is this, what are its real trust boundaries, and what is the **first narrow probe** worth spending time on?”

## Core rule

When only a URL is available, do **not** start with generic SQLi/XSS/RCE payloads.

First infer:

1. business shape
2. actor model
3. object model
4. likely trust boundaries
5. highest-signal first probe

## Business shapes to recognize

### Portal / OA / workflow / approval

Clues:

- dashboard/home/index shell
- notice / bulletin / task / approval words
- list/detail/action chains
- iframe / bridge / portal widgets

High-value lanes:

- anonymous widget leaks
- task/detail/approval object boundary
- workflow state abuse

### Admin / ops / component console

Clues:

- login page with minimal business text
- route roots resembling middleware
- monitoring/statistics/admin titles
- version/debug/docs/admin assets

High-value lanes:

- default creds / unauth
- component-specific CVEs
- hidden docs/config/admin APIs

### File platform / preview / export / share

Clues:

- preview/download/export/share/upload endpoints
- file IDs, object keys, signed URLs
- office/pdf/image render paths

High-value lanes:

- file read
- token reuse
- export/share boundary breaks
- upload/import pipeline

### Shop / payment / membership / quota

Clues:

- price, total, coupon, cart, points, member, package
- quote/order/pay/callback/redeem flows

High-value lanes:

- price manipulation
- replay/race
- reward/entitlement drift

### API shell / JSON parser / deserialization

Clues:

- only a few JSON endpoints
- strict method/content-type behavior
- parser-specific errors
- reflection of structured input

High-value lanes:

- parser abuse
- deserialization
- hidden object/property mutation

### Login shell / identity surface

Clues:

- only login/reset/register/invite pages
- SMS/email/OAuth/SSO routes
- few visible business features

High-value lanes:

- reset/register/invite abuse
- auth bypass
- hidden routes in JS

## First-pass evidence to collect

Use browser/runtime truth when possible:

- page snapshot
- network requests
- console messages
- route names
- JS bundles / script URLs
- storage/cookies
- same-origin fetch probes

## Mandatory first-turn output

For a bare URL, return at least:

```text
SITE_SHAPE:
ACTORS:
OBJECTS:
TRUST_BOUNDARIES:
LIKELY_COMPONENTS:
HIGH_VALUE_FEATURES:
FIRST_NARROW_PROBE:
```

## Routing rules

### If Java / component clues appear

Use:

- `java-third-party-component-hunter`
- then `java-component-poc-router`

### If endpoint probing is weak but JS exists

Use:

- `preauth-js-hidden-logic-hunter`
- `browser-pentest-orchestrator`

### If files / exports / uploads appear

Use:

- `file-access-vuln`
- `upload-insecure-files`
- `export-preview-sharing-logic-abuse`

### If workflow/state/action chains appear

Use:

- `blackbox-business-logic-hunter`
- `workflow-state-diff-lab`

## Anti-patterns

Do not:

- spray broad CVEs before component or feature clues exist
- stay at the homepage too long without mapping requests and routes
- treat a Spring/Flask/Django 404 shell as “no surface”
- guess object IDs before proving a list/detail/action chain

## References

- business-shape examples: `references/business-shape-examples.md`
- trust-boundary prompts: `references/trust-boundary-checklist.md`
- business shape -> vulnerability priority: `references/business-shape-to-vuln-map.md`
