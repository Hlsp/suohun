# Business shape examples

## Thin login page

Possible shapes:

- identity/auth surface
- hidden SPA with API backend
- third-party admin console

Best next clues:

- JS bundle names
- same-origin `/api/*`, `/json`, `/auth/*`, `/oauth/*`
- reset/register/invite routes

## Whitelabel / generic 404 shell

Possible shapes:

- Spring Boot app with hidden API routes
- component console under non-root path
- JSON parser or middleware endpoint off root

Best next clues:

- method/content-type matrix on likely parser endpoints
- Java component route shortlist
- browser MCP same-origin fetch probes

## Dashboard with lists, detail pages, and actions

Possible shapes:

- OA/task center
- asset/inventory/ticket/workflow

Best next clues:

- object IDs
- owner/tenant/role fields
- state transition endpoints
