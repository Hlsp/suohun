# Business shape -> vulnerability priority map

Use this file when only a URL or a very thin shell is available and you must decide **what to test first**.

The goal is to reduce generic guessing by mapping observed business shape to the highest-payoff vulnerability lanes.

## 1. Thin login shell / auth-first site

Clues:

- only login page
- reset/register/invite wording
- SMS/email/MFA/OAuth/SSO
- very few business routes visible before auth

Priority order:

1. reset/register/invite/account binding
2. hidden JS/API routes
3. auth state confusion / session issuance / device trust
4. component console clues behind the login shell
5. only then generic injection

Best first probes:

- same-origin fetch for `/api/login`, `/api/check_login`, `/register`, `/reset`, `/invite`
- JS bundle route/API extraction
- token/captcha/replay boundary checks

## 2. Portal / OA / approval / task center

Clues:

- notices, tasks, approvals, workflow, forms, profile center
- list/detail/action chains
- embedded iframes or bridge routes

Priority order:

1. anonymous or low-privileged widget/data exposure
2. task/detail object boundary
3. workflow action/state abuse
4. export/share/download/file attachment boundaries
5. cross-system token reuse

Best first probes:

- list -> detail -> action chain
- object ID / task ID swap
- task/action replay in wrong state
- bridge URL or iframe token reuse

## 3. File platform / preview / share / export

Clues:

- upload, preview, download, export, attachment, share
- office/pdf/image viewer
- file IDs, object keys, signed URLs

Priority order:

1. file read / preview boundary
2. share token / signed URL reuse
3. export object boundary
4. upload pipeline to read/write/XSS/RCE
5. async processing side effects

Best first probes:

- change file/object ID
- reuse share/export token across users
- path/key parameter mutation
- upload harmless baseline, then processing pivot

## 4. API shell / parser-like endpoint / JSON echo

Clues:

- very few routes, often JSON-only
- strict method/content-type behavior
- reflected structured input
- parser-specific error messages

Priority order:

1. format and parser fingerprint
2. object/property mutation
3. deserialization or expression abuse
4. file/write/read challenge lanes if the parser family fits
5. only then broader injection families

Best first probes:

- GET/POST/PUT matrix
- content-type matrix
- minimal type / parser canaries
- nested JSON / `$ref` / metadata behaviors

## 5. Admin / middleware / monitoring console

Clues:

- product-like login page
- stats/monitor/admin/config wording
- docs or API consoles
- known middleware roots

Priority order:

1. unauth/default auth/default token/default key
2. docs/config exposure
3. component-specific verify PoC
4. exploit PoC
5. only then generalized web classes

Best first probes:

- best starter PoC from component family
- route and method validation
- version disclosure / response model confirmation

## 6. Shop / order / price / promo / membership

Clues:

- price, total, cart, order, coupon, points, balance, package, member

Priority order:

1. price/amount manipulation
2. reward/quota drift
3. replay/race on orders/coupons
4. payment callback or fulfillment mismatch
5. entitlement downgrade/revoke gaps

Best first probes:

- baseline order then mutate one monetary field
- replay one-time coupon or benefit action
- race one order/claim endpoint

## 7. Search / report / filtering-heavy site

Clues:

- search, report, query, sort, export
- rich filter parameters

Priority order:

1. object exposure through weak filters
2. hidden parameters / mass assignment
3. SQLi / NoSQLi / sort-field abuse
4. export/report file effects

Best first probes:

- duplicate key / hidden parameter checks
- sort/filter field mutation
- report export with user-controlled inputs

## 8. Third-party docs / schema / API explorer present

Clues:

- Swagger, Knife4j, GraphQL, docs, schema

Priority order:

1. hidden operation and model extraction
2. raw endpoint replay without UI restrictions
3. auth/object/property boundary testing on discovered routes

Best first probes:

- fetch schema/docs
- list base paths
- replay discovered state-changing operations

## Anti-pattern

Do not pick the first PoC by familiarity.

Pick the first PoC by:

1. matching business shape
2. matching trust boundary
3. matching runtime/component clue
4. cheapest decisive signal
