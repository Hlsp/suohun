# Trust boundary checklist

For any black-box site, map these before choosing PoCs:

- **identity boundary**: who is the user, guest, admin, approver, operator
- **object boundary**: what IDs exist, who owns them
- **tenant boundary**: org, school, company, department, merchant, workspace
- **file boundary**: upload, preview, export, attachment, share token
- **workflow boundary**: create, submit, approve, revoke, cancel, replay
- **money/quota boundary**: price, count, score, balance, package, seat
- **component boundary**: is this custom business logic or a known third-party console/parser

Pick the first probe where one variable crosses one boundary.
