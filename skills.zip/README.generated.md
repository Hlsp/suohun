# Zhang Codex Skills Index

Generated: 2026-04-29 11:29:18 +0800

Current suite status: **157 skills**, no duplicate names, no broken relative references, no missing `agents/openai.yaml`, and no Python helper compile failures (`106` scripts checked).

Use this as the practical entry order:

1. `zhang-web-src-default-runner` ? default for Zhang Web/SRC/CTF/security runs.
2. `security-test-dispatcher` ? scene router.
3. `blackbox-pentest-runner` ? Web/API black-box orchestration.
4. `auth-role-matrix-runner` ? logged-in A/B/tenant/role tests.
5. `complex-js-reverse` ? frontend crypto/signature reverse.
6. `miniapp-dynamic-static-runner` ? WeChat miniapp static+dynamic.
7. `logic-evidence-pack` / `results-storage` / `pentest-report` ? evidence and reporting.

Detailed routing: `C:\Users\zhang\.codex\skills\skill-suite-governance\references\zhang-skill-suite-routing.generated.md`

Health reports:

- `C:\Users\zhang\.codex\skills\skill-suite-governance\references\scan-summary.json`
- `C:\Users\zhang\.codex\skills\skill-suite-governance\references\skill-map.generated.md`
- `C:\Users\zhang\.codex\skills\skill-suite-governance\references\content-quality.generated.md`
- `C:\Users\zhang\.codex\skills\skill-suite-governance\references\zhang-skill-suite-cleanup.generated.md`
