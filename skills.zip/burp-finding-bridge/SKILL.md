---
name: burp-finding-bridge
description: "Bridge Burp Scanner issues, Collaborator interactions, Repeater evidence, and Burp replay outputs into blackbox-pentest-runner findings. Use when Codex needs to normalize Burp evidence into findings.json, results-storage imports, or pentest report material."
role: bridge
domain: reporting-governance
---

# Burp Finding Bridge

Use this after Burp has produced candidate evidence. It packages Burp facts; it does not automatically confirm impact.

## Workflow

1. Pull read-only evidence:
   - `get_scanner_issues`
   - `get_collaborator_interactions`
   - relevant `get_proxy_http_history_regex` records
2. Save raw MCP outputs under `runs/T/burp/`.
3. Normalize into runner findings:

```bash
python scripts/burp_findings_bridge.py --run-dir runs/T --scanner runs/T/burp/scanner_issues.json --collab runs/T/burp/collaborator.json
```

4. Mark status:
   - `candidate` for scanner-only or unproven OOB hints
   - `confirmed` only after a minimal replay demonstrates impact
5. Continue with [runner-results-bridge](../runner-results-bridge/SKILL.md) and [pentest-report](../pentest-report/SKILL.md).

## Evidence Rules

- Keep raw Burp issue/interactions files unchanged.
- Include request/response references, not just Scanner issue names.
- Use severity from Burp as an initial hint, then adjust using business impact.
- For Collaborator, include payload id, interaction type, observed target, and injected request reference.

## Pivots

- Burp tools: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Runner results: [runner-results-bridge](../runner-results-bridge/SKILL.md)
- Evidence pack: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
