#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path

SEV_MAP = {'critical': 'Critical', 'high': 'High', 'medium': 'Medium', 'low': 'Low', 'info': 'Info', 'information': 'Info'}


def load_any(path):
    if not path:
        return None
    text = Path(path).read_text(encoding='utf-8-sig', errors='replace')
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r'\{.*\}|\[.*\]', text, re.S)
        return json.loads(m.group(0)) if m else text


def walk(obj):
    if isinstance(obj, list):
        for x in obj:
            yield from walk(x)
    elif isinstance(obj, dict):
        # MCP content block may wrap JSON in text.
        if set(obj.keys()) <= {'type', 'text'} and isinstance(obj.get('text'), str):
            try:
                yield from walk(json.loads(obj['text']))
            except Exception:
                yield obj
        else:
            yield obj
            for v in obj.values():
                if isinstance(v, (list, dict)):
                    yield from walk(v)


def norm_sev(v):
    return SEV_MAP.get(str(v or '').lower(), 'Medium')


def issue_to_finding(issue, evidence_path):
    title = issue.get('name') or issue.get('issueName') or issue.get('title') or issue.get('type') or 'Burp candidate issue'
    url = issue.get('url') or issue.get('origin') or issue.get('path') or issue.get('host') or ''
    desc = issue.get('description') or issue.get('detail') or issue.get('issueDetail') or issue.get('remediation') or ''
    return {
        'title': str(title),
        'severity': norm_sev(issue.get('severity') or issue.get('confidence')),
        'status': 'candidate',
        'confidence': issue.get('confidence', ''),
        'type': 'burp-scanner',
        'url': str(url),
        'affected_component': issue.get('path') or issue.get('host') or '',
        'description': str(desc),
        'impact': 'Imported from Burp; confirm exploitability and business impact with a minimal replay.',
        'reproduction': issue.get('request') or issue.get('evidence') or '',
        'evidence_path': evidence_path,
        'source_tool': 'burp',
        'burp_issue_type': issue.get('type') or issue.get('issue_type') or issue.get('issueType') or ''
    }


def collab_to_finding(item, evidence_path):
    payload = item.get('payloadId') or item.get('payload_id') or item.get('payload') or ''
    interaction = item.get('type') or item.get('interactionType') or item.get('protocol') or 'OOB interaction'
    return {
        'title': f'Burp Collaborator interaction: {interaction}',
        'severity': 'Medium',
        'status': 'candidate',
        'confidence': 'needs replay correlation',
        'type': 'oob-interaction',
        'url': item.get('url') or item.get('clientIp') or item.get('client_ip') or '',
        'affected_component': item.get('protocol') or '',
        'description': json.dumps(item, ensure_ascii=False)[:2000],
        'impact': 'OOB interaction observed. Correlate payload injection point before confirmation.',
        'reproduction': '',
        'evidence_path': evidence_path,
        'source_tool': 'burp-collaborator',
        'collaborator_payload_id': payload
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run-dir', required=True)
    ap.add_argument('--scanner')
    ap.add_argument('--collab')
    ap.add_argument('--out')
    ap.add_argument('--append', action='store_true', default=True)
    args = ap.parse_args()
    run = Path(args.run_dir); run.mkdir(parents=True, exist_ok=True)
    out = Path(args.out) if args.out else run / 'findings.json'
    findings = []
    if out.exists() and args.append:
        try:
            existing = json.loads(out.read_text(encoding='utf-8-sig'))
            findings = existing.get('findings', existing if isinstance(existing, list) else [])
        except Exception:
            findings = []
    added = []
    if args.scanner:
        data = load_any(args.scanner)
        for obj in walk(data):
            if isinstance(obj, dict) and any(k in obj for k in ('severity', 'issueName', 'name', 'issueDetail', 'confidence')):
                f = issue_to_finding(obj, args.scanner)
                added.append(f)
    if args.collab:
        data = load_any(args.collab)
        for obj in walk(data):
            if isinstance(obj, dict) and any(k in obj for k in ('payloadId', 'payload_id', 'protocol', 'interactionType', 'clientIp')):
                added.append(collab_to_finding(obj, args.collab))
    findings.extend(added)
    out.write_text(json.dumps({'findings': findings}, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'out': str(out), 'added': len(added), 'total': len(findings)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
