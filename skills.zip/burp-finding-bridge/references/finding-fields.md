# Finding Fields

Recommended normalized fields:

- `title`
- `severity`
- `status`
- `confidence`
- `type`
- `url`
- `http_method`
- `affected_component`
- `description`
- `impact`
- `reproduction`
- `evidence_path`
- `source_tool`
- `burp_issue_type`
- `collaborator_payload_id`
