---
name: request-chain-tracer
description: Trace request assembly through fetch, XHR, axios interceptors, serializer helpers, request models, and response unwrap paths. Use when the hard part is the wrapper chain, object construction, or interceptor layering rather than the crypto primitive itself.
role: bridge
domain: browser-frontend-reverse
---

# Request Chain Tracer

Use this skill when protected traffic exists but the real blocker is understanding how the request or response gets assembled through multiple wrappers.

## Scope

- axios interceptors
- fetch and XHR wrappers
- serializer and normalizer helpers
- request model methods such as `encrypt()`, `toJSON()`, `sign()`, or `normalize()`
- response unwrap, decode, and decrypt chains

## Workflow

1. Capture one target request and one matching response.
2. Use the initiator or stack trace to locate the outermost business wrapper.
3. Map the chain in order:
   - UI handler
   - business method
   - request model or serializer
   - interceptor
   - transport primitive
4. Hook the narrowest wrapper that still sees both plaintext structure and final transformed output.
5. Repeat for the response path separately.

## Questions This Skill Should Answer

- Where is plaintext still visible?
- Where do timestamps, nonces, and signatures get added?
- Which layer serializes or sorts params?
- Which layer encrypts, wraps, or encodes?
- Which layer unwraps or decrypts the response?

## Useful Tool Patterns

- `get_request_initiator`
- `trace_function`
- `hook_function`
- `get_hook_data`
- `search_in_sources`
- `inspect_object`

## Handoff Rules

- If the wrapper chain reveals real crypto work, continue with `complex-js-reverse`
- If the chain shows only diffable field changes and signature candidates, use `protocol-diff-lab`
- If the issue is mostly locating the right module inside a big bundle, start with `webpack-runtime-extractor`

## Output

Return a chain map with:

- request path stages
- response path stages
- first plaintext-visible layer
- first fully protected layer
- best next hook point
