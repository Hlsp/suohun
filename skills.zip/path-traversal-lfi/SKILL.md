---
name: path-traversal-lfi
description: "Path traversal and local file inclusion playbook. Use when file paths, download endpoints, include operations, archive extraction, preview handlers, or wrapper behavior may expose unauthorized file read or include behavior."
role: specialist
domain: file-upload-access
---

# Path Traversal / LFI

Use this skill when user-controlled input influences a filesystem path, storage key, include target, archive member, preview file, or download object.

## Fast Triage

Prioritize parameters and fields named:

- `file`, `filename`, `path`, `dir`, `folder`, `template`, `page`, `view`
- `download`, `preview`, `export`, `attachment`, `key`, `object`, `url`
- archive entries, ZIP paths, image/document preview paths, signed file URLs

Classify the sink first:

| Sink | What to prove |
|---|---|
| direct download | cross-file read outside intended object |
| include/render | server-side include or template selection |
| preview/conversion | processor reads the chosen file |
| archive extraction | path escapes extraction directory |
| object storage key | key traversal or cross-tenant object read |

## Validation Ladder

1. Capture one legitimate file access as baseline.
2. Change only the file identifier or path segment.
3. Compare existing-vs-nonexistent behavior.
4. Try parent traversal and encoding variants only after the baseline is stable.
5. Prove a sensitive but low-impact read or cross-object read.
6. If include execution is possible, pivot to the matching execution skill only after file read is confirmed.

## Payload Families

Use small, targeted sets instead of noisy payload spray:

```text
../target
../../target
..%2f..%2ftarget
..\\..\\target
....//....//target
%2e%2e%2f%2e%2e%2ftarget
```

OS-specific proof targets:

- Linux: `/etc/passwd`, `/proc/self/environ`, app config paths from errors
- Windows: `C:\Windows\win.ini`, application config files
- PHP wrappers when PHP is likely: `php://filter/convert.base64-encode/resource=<file>`

## Bypass Ideas

- Double encoding, mixed slash/backslash, UTF-8 dot variants
- Null byte only for legacy stacks where relevant
- Prefix/suffix tricks: `safe/../../target`, `target%00.ext`, `target/.` 
- Extension lock bypass: wrappers, symlinks, known allowed extension with path escape
- Archive slip: `../`, absolute paths, drive letters, symlinks inside archives

When the source is an archive extractor, distinguish these lanes early:

- **new-file write**: can you create a fresh file in a web-reachable or app-readable directory such as `static/`?
- **overwrite**: does extraction stop with a breaker/error when the destination already exists? treat that separately from traversal success
- **symlink read**: if the extractor preserves symlink entries, first prove a safe same-directory link, then an absolute-path link to a known readable file, and only then test the protected target such as `/tmp/flag.txt`
- **target-specific denial**: if `/tmp/probe.txt` is readable through the same symlink primitive but `/tmp/flag.txt` returns 404, record that as a target-specific restriction rather than abandoning the primitive

## Evidence Standard

Do not report based on `500` alone. Capture:

- baseline request and expected file
- mutated request with one changed path/key
- response indicator proving different file content or cross-object access
- whether auth/session was required
- exact root boundary escaped or object boundary crossed

## Pivots

- Download-specific workflow: `exploit-file-download`
- Upload-to-read/write chain: `upload-insecure-files`
- XML/SVG/OOXML parser file read: `xxe-xml-external-entity`
- Command execution through processors: `cmdi-command-injection`
- Business object/file sharing issue: `export-preview-sharing-logic-abuse`
