---
name: recon-for-sec
description: >-
role: router
domain: recon-traffic-mcp
  Entry P1 category router for reconnaissance and methodology. Use when mapping
  scope, discovering assets, fingerprinting technology, building endpoint
  inventory, and choosing the first high-value security testing path.
---

# Recon For Sec

Use for new/unknown targets. Confirm scope, map pages/APIs/services/JS/docs/exposed files, then route by evidence to API, auth, injection, file, frontend reverse, or business logic skills.
