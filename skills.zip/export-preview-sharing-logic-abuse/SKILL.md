---
name: export-preview-sharing-logic-abuse
description: "Export, preview, download, share, recycle-bin, favorite, recent-use, report, and generated-file logic abuse playbook. Use when the risk is unauthorized access, link reuse, cross-user state changes, or hidden write actions in object and file workflows rather than parser exploitation."
role: specialist
domain: file-upload-access
---

# Export Preview Sharing Logic Abuse

Use this skill when the feature generates, stores, previews, downloads, exports, shares, revokes, deletes, favorites, or remembers an object or file.

## Scope

- export jobs, report jobs, generated documents, invoices, contracts, tickets, forms
- preview tokens, download URLs, share links, signed URLs, recycle-bin references
- favorites, subscriptions, recent-use, history, mark-read/seen, lightweight hidden writes
- workflow/task attachments, order files, bill files, supplier/customer files

## High-Value Tests

- Can `jobId`, `exportId`, `fileId`, `previewId`, or `shareId` be guessed, swapped, or reused?
- Is the token bound to user, tenant, object, action, time window, and file type?
- Can a preview/share/export link be expanded from one object to more objects or stronger actions?
- Does deleted, revoked, expired, or recycled content remain accessible through another endpoint?
- Do favorites/recent/subscriptions/history create cross-user writes or data pollution?
- Does a generated report include objects outside the user's filter, tenant, or role?
- Can a low-privileged user call export/share/download for an object they cannot view in UI?

## Distinguish Three Classes

- **File parser issue**: pivot to `file-access-vuln`, `upload-insecure-files`, `xxe-xml-external-entity`, or `ssrf-server-side-request-forgery`.
- **File business logic issue**: stay here and test object, token, share, revoke, and generated-file boundaries.
- **BOLA/BOPLA issue**: pivot to `api-authorization-and-bola` when object/property authorization is the core failure.

## Validation Ladder

1. Generate or access a self-owned file/export/share baseline.
2. Capture the object owner, file key, token/link, expiry, and action.
3. Mutate one variable: object id, file id, token, tenant id, user id, state, path, or action.
4. Verify self-read before cross-user read.
5. Verify revoked/deleted/expired behavior separately.
6. Re-read from attacker and owner contexts.
7. Clean up shares, exports, favorites, and generated files when possible.

## Evidence

Capture:

- object ID / fileId / exportId / jobId / share token
- original owner and attacker identity
- baseline preview/download/export result
- mutated request and response
- actual file/content proof or state change
- expiry/revocation/deletion behavior
- cleanup steps
