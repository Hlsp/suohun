---
name: protocol-diff-lab
description: Compare protected request and response samples to isolate fixed fields, timestamps, nonces, signatures, wrapped keys, and candidate encrypted regions. Use when differential analysis is faster than reading code first or when you need to separate stable protocol structure from data-dependent transforms.
role: specialist
domain: browser-frontend-reverse
---

# Protocol Diff Lab

Use this skill when two or more captured samples can answer the question faster than broad source hunting.

## Good Inputs

- two or more requests for the same action with one changed business field
- repeated responses with changing session material
- one successful sample and one failed sample
- login, send-code, search, submit, or token refresh flows

## Workflow

1. Normalize samples into comparable structures.
2. Mark which user inputs changed intentionally.
3. Split fields into buckets:
   - invariant
   - monotonic or time-like
   - random or nonce-like
   - digest-like
   - large opaque ciphertext-like
4. Check whether ciphertext changes align with one field, many fields, or the whole envelope.
5. Identify candidate signing bases, key exchange fields, and response decrypt envelopes.

## Interpretation Rules

- Stable length plus hex alphabet often suggests digest or MAC, not reversible encryption.
- Large Base64 fields that change completely after small input changes often suggest block or stream encryption.
- A short changing `key` plus large `data` or `result` often suggests hybrid wrapping.
- If only timestamps and `sign` change while business fields remain plain, say so early.

## Useful Pairings

- Pair with `signature-vs-encryption-triage` for first-pass classification
- Pair with `request-chain-tracer` once a likely wrapper is identified
- Pair with `complex-js-reverse` when code-level confirmation is needed

## Output

Return a diff table or structured note with:

- invariant fields
- candidate nonce or timestamp fields
- candidate sign or MAC fields
- candidate encrypted payload fields
- most useful next reverse step
