﻿#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re
from pathlib import Path

def load_json(path):
    if not path: return None
    p=Path(path)
    return json.loads(p.read_text(encoding='utf-8-sig',errors='ignore')) if p.exists() else None

def collect_items(data):
    if data is None: return []
    if isinstance(data,list): return data
    if isinstance(data,dict):
        for k in ['items','objects','identities','tenants','tokens','records','data']:
            if isinstance(data.get(k),list): return data[k]
        rows=[]
        for v in data.values():
            if isinstance(v,list): rows+=v
        return rows
    return []

def first(row,keys):
    for k in keys:
        if k in row and row[k] not in (None,''): return str(row[k])
    return None

def collect_accounts(data):
    rows=collect_items(data)
    if not rows and isinstance(data,dict):
        for k in ['accounts','users','fixtures','matrix']:
            if isinstance(data.get(k),list): rows=data[k]; break
    out=[]
    for i,row in enumerate(rows):
        if not isinstance(row,dict): continue
        out.append({'label':row.get('label') or row.get('name') or row.get('username') or row.get('email') or f'account_{i}','user_id':first(row,['user_id','userId','uid','id','account_id','accountId']),'tenant_id':first(row,['tenant_id','tenantId','org_id','orgId','company_id','companyId','workspace_id','workspaceId']),'role':first(row,['role','role_name','roleName','permission','permissions']),'raw':row})
    return out

def val(item): return str(item.get('value') or item.get('id') or item.get('key') or '') if isinstance(item,dict) else str(item)
def context(item): return ' '.join(str(item.get(k,'')) for k in ['key','source','context','category']) if isinstance(item,dict) else ''

def find_owner(item,idents):
    c=context(item)
    for it in idents:
        v=val(it)
        if v and len(v)>=2 and v in c: return {'value':v,'key':it.get('key') if isinstance(it,dict) else None,'source':it.get('source') if isinstance(it,dict) else None}
    m=re.search(r'(?i)(?:user|uid|owner|member)[_-]?id[\"\'\s:=]+([A-Za-z0-9_.:-]{2,80})',c)
    return {'value':m.group(1),'key':'owner_hint','source':'object_context'} if m else None

def find_tenant(item,tenants):
    c=context(item)
    for it in tenants:
        v=val(it)
        if v and len(v)>=2 and v in c: return {'value':v,'key':it.get('key') if isinstance(it,dict) else None,'source':it.get('source') if isinstance(it,dict) else None}
    m=re.search(r'(?i)(?:tenant|org|company|corp|workspace)[_-]?id[\"\'\s:=]+([A-Za-z0-9_.:-]{2,80})',c)
    return {'value':m.group(1),'key':'tenant_hint','source':'object_context'} if m else None

def main():
    ap=argparse.ArgumentParser(description='Build A/B object authorization test pairs.')
    ap.add_argument('--objects',required=True); ap.add_argument('--identities'); ap.add_argument('--tenants'); ap.add_argument('--accounts'); ap.add_argument('--out',required=True); ap.add_argument('--limit',type=int,default=200)
    a=ap.parse_args(); objects=collect_items(load_json(a.objects))[:a.limit]; idents=collect_items(load_json(a.identities)) if a.identities else []; tenants=collect_items(load_json(a.tenants)) if a.tenants else []; accounts=collect_accounts(load_json(a.accounts)) if a.accounts else []
    owner_pairs=[]; tenant_pairs=[]; role_pairs=[]
    for obj in objects:
        if not val(obj): continue
        owner=find_owner(obj,idents); tenant=find_tenant(obj,tenants)
        if owner:
            actors=[x for x in accounts if x.get('user_id') and x.get('user_id')!=owner['value']]
            if actors:
                owner_pairs += [{'object':obj,'observed_owner':owner,'test_actor':x,'pair_type':'different_user_same_object'} for x in actors[:3]]
            else: owner_pairs.append({'object':obj,'observed_owner':owner,'test_actor':None,'pair_type':'needs_second_account'})
        else: owner_pairs.append({'object':obj,'observed_owner':None,'test_actor':None,'pair_type':'needs_manual_owner_confirmation'})
        if tenant:
            actors=[x for x in accounts if x.get('tenant_id') and x.get('tenant_id')!=tenant['value']]
            if actors: tenant_pairs += [{'object':obj,'observed_tenant':tenant,'test_actor':x,'pair_type':'different_tenant_same_object'} for x in actors[:3]]
            else:
                others=[t for t in tenants if val(t)!=tenant['value']]
                tenant_pairs += [{'object':obj,'observed_tenant':tenant,'target_tenant_candidate':t,'pair_type':'cross_tenant_candidate'} for t in others[:3]]
    for i,a1 in enumerate(accounts):
        for a2 in accounts[i+1:]:
            if a1.get('role')==a2.get('role'): continue
            if a1.get('tenant_id') and a2.get('tenant_id') and a1.get('tenant_id')!=a2.get('tenant_id'): continue
            role_pairs.append({'actor_a':a1,'actor_b':a2,'pair_type':'same_tenant_different_role'})
            if len(role_pairs)>=a.limit: break
        if len(role_pairs)>=a.limit: break
    out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    (out/'owner_object_pairs.json').write_text(json.dumps(owner_pairs[:a.limit],ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'cross_tenant_pairs.json').write_text(json.dumps(tenant_pairs[:a.limit],ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'role_boundary_pairs.json').write_text(json.dumps(role_pairs[:a.limit],ensure_ascii=False,indent=2),encoding='utf-8')
    md=['# A/B Pair Summary','',f'- objects loaded: {len(objects)}',f'- identities loaded: {len(idents)}',f'- tenants loaded: {len(tenants)}',f'- accounts loaded: {len(accounts)}',f'- owner/object pairs: {min(len(owner_pairs),a.limit)}',f'- cross-tenant pairs: {min(len(tenant_pairs),a.limit)}',f'- role boundary pairs: {min(len(role_pairs),a.limit)}','','## Recommended use','Replay one baseline request, substitute one object or actor boundary, and compare status, body shape, and state mutation.']
    (out/'ab_pair_summary.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'out':str(out),'owner_pairs':len(owner_pairs),'cross_tenant_pairs':len(tenant_pairs),'role_pairs':len(role_pairs)},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
