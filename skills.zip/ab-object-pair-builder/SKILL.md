---
name: ab-object-pair-builder
description: "Build A/B account and object test pairs for authorization and business logic validation. Use when object, identity, tenant, role, or account inventories exist and Codex needs minimal owner-object, cross-tenant, same-role, lower-role, or anonymous-vs-authenticated replay pairs without noisy enumeration."
role: builder
domain: auth-api
---

# A/B Object Pair Builder

Use this skill to convert extracted identifiers and account fixtures into a small validation matrix. The output is a test plan, not an exploit script.

## Workflow

1. Gather:
   - `object_inventory.json` from [object-identity-extractor](../object-identity-extractor/SKILL.md)
   - optional `identity_inventory.json` and `tenant_inventory.json`
   - optional account matrix from [account-fixture-manager](../account-fixture-manager/SKILL.md) or [auth-role-matrix-runner](../auth-role-matrix-runner/SKILL.md)
2. Build pairs:

   ```bash
   python scripts/build_pairs.py --objects runs/T/objects/object_inventory.json --identities runs/T/objects/identity_inventory.json --tenants runs/T/objects/tenant_inventory.json --accounts runs/T/accounts/account_matrix.json --out runs/T/pairs
   ```

3. Pick the smallest useful pair:
   - same tenant, different owner
   - different tenant, same role
   - lower role vs higher role
   - anonymous baseline vs logged-in request
4. Replay one request with one substituted object or identity value.
5. Package only pairs that produce an authorization or business-state difference.

## Pair Quality Rules

- Prefer pairs where ownership is observed, not guessed.
- Avoid broad ID walking; use known objects from captured traffic or fixtures.
- Keep tenant and role changes separate so the decisive boundary is clear.
- If account data is missing, emit candidate pairs as `needs_manual_owner_confirmation`.

## Outputs

The bundled script writes:

- `owner_object_pairs.json`
- `cross_tenant_pairs.json`
- `role_boundary_pairs.json`
- `ab_pair_summary.md`
