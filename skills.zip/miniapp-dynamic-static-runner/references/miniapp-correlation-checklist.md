# Miniapp Correlation Checklist

## Runtime facts

- CDP target URL or appid
- selected execution context
- `getCurrentPages()` route
- page `$vm` methods or data keys
- Network request URL, method, headers, body, response
- storage values used near request time

## Static facts

- `app.json` pages and subpackages
- request wrapper files
- domain/baseURL config
- token storage keys
- signing/encryption functions
- route/page file that invokes the wrapper

## Protection classification

- Plaintext: body and response visible as business JSON.
- Signed only: body is readable; signature/header validates integrity.
- Client-encrypted: plaintext enters a client crypto function before request.
- Hybrid: asymmetric key wraps symmetric key or server key agreement plus body cipher.
- Unresolved: opaque payload without observed plaintext/key path.
