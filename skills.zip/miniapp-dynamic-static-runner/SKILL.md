---
name: miniapp-dynamic-static-runner
description: "WeChat mini-program dynamic plus static security runner. Use when the user says 小程序, 微信, wxapkg, 远程调试, 反编译源码, has a remote debugging CDP ws/devtools URL and decompiled miniapp source, and Codex must correlate runtime network traffic, Burp captures, page methods, storage, request signing/encryption, static API wrappers, routes, tokens, and black-box business logic tests."
role: runner
domain: mobile-miniapp
---

# Miniapp Dynamic Static Runner

Use this as the entrypoint for mini-program work when both runtime debugging and decompiled source may be available. Runtime behavior wins over static guesses; static source explains and reproduces runtime findings.

## Operating Loop

1. Scope Gate: record appid, allowed accounts, allowed actions, and whether destructive workflows are excluded.
2. Static Inventory: scan decompiled source for pages, APIs, domains, storage, crypto, request wrappers, and suspicious business flows.
3. Runtime Bootstrap: use [wechat-miniapp-cdp-debug](../wechat-miniapp-cdp-debug/SKILL.md) to enumerate CDP targets, contexts, frames, current pages, and storage.
4. Traffic Capture: collect CDP network events and Burp Proxy history for the same user action.
5. Correlate: map captured URLs or workflow paths back to static files and request wrapper functions.
6. Classify Protection: decide plaintext, signed only, client-encrypted, hybrid, or unresolved using observed key/token lineage.
7. Replay: only after reconstruction is understood, run single-variable tests through Burp or raw replay.
8. Package: preserve raw runtime events, static file references, reconstructed request, and evidence.

## Static Inventory Script

```bash
python scripts/miniapp_static_inventory.py --src path/to/decompiled-miniapp --out runs/T/miniapp_static
```

Outputs:

- `miniapp_static_inventory.json`
- `miniapp_static_inventory.md`

## Runtime/Static Correlation

After traffic is mapped:

```bash
python scripts/correlate_runtime_static.py --inventory runs/T/miniapp_static/miniapp_static_inventory.json --traffic runs/T/workflows/workflow_map.json --out runs/T/miniapp_correlation
```

Outputs:

- `miniapp_correlation.json`
- `miniapp_correlation.md`

## Key Questions

- Which page method triggered the request?
- Which wrapper builds URL, headers, body, sign, timestamp, nonce, device ID, and token?
- Are payloads encrypted or only signed/encoded?
- Where do session, openid/unionid, tenant, role, appid, and device values come from?
- Can a captured object, tenant, role, status, amount, or token be changed independently?

## High-Value SRC Bias

Miniapp/APP reverse engineering is not the final finding. Use it to reconstruct replayable API knowledge, then return to Web/SRC logic testing:

- page method -> wrapper -> final URL/body/header/signature
- appid/openid/unionid/session/device/tenant/role lineage
- hidden pages, disabled actions, test/debug routes, and gray-release flags
- object IDs for orders, files, tasks, coupons, invoices, wallets, memberships, and approvals
- response fields that can become BOPLA candidates: `role`, `ownerId`, `tenantId`, `status`, `auditStatus`, `price`, `quota`, `plan`

After reconstruction, default to:

1. BOLA object swap across A/B accounts
2. BOPLA/mass-assignment one-field replay
3. workflow state mutation
4. payment/coupon/member/quota abuse
5. export/share/file token replay
6. signing/encryption helper generation only when needed for repeatable proof

## Routing

- Runtime CDP: [wechat-miniapp-cdp-debug](../wechat-miniapp-cdp-debug/SKILL.md)
- Complex JS reverse: [complex-js-reverse](../complex-js-reverse/SKILL.md)
- Crypto entry: [find-crypto-entry](../find-crypto-entry/SKILL.md)
- Request chain: [request-chain-tracer](../request-chain-tracer/SKILL.md)
- Key lineage: [storage-and-key-lineage](../storage-and-key-lineage/SKILL.md)
- Signature vs encryption: [signature-vs-encryption-triage](../signature-vs-encryption-triage/SKILL.md)
- Protocol diff: [protocol-diff-lab](../protocol-diff-lab/SKILL.md)
- Node environment patch: [env-patch](../env-patch/SKILL.md)
- Burp capture/replay: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)

## Output Format

Report:

1. runtime target/context selected
2. current page and triggered action
3. captured request/response evidence
4. static file/function correlation
5. crypto/token classification
6. replayability and single-variable test candidate
7. evidence paths and next step
