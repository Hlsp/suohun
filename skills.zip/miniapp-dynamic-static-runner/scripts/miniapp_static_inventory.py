#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path

URL_RE = re.compile(r'https?://[^\s"\'`<>]+|[\w.-]+\.(?:com|cn|net|org|io|top|xyz)(?:/[\w./?=&%-]*)?', re.I)
REQ_RE = re.compile(r'\b(wx|uni|my|tt)\.(request|uploadFile|downloadFile|connectSocket)|\brequest\s*\(|axios\s*\.', re.I)
STORAGE_RE = re.compile(r'\b(getStorageSync|setStorageSync|getStorage|setStorage|localStorage|sessionStorage)\b|token|openid|unionid|session|cookie|tenant|role|userId|uid', re.I)
CRYPTO_RE = re.compile(r'CryptoJS|crypto|AES|DES|RSA|SM2|SM3|SM4|SHA\d*|MD5|Hmac|sign|signature|encrypt|decrypt|nonce|timestamp|iv|salt', re.I)
ROUTE_RE = re.compile(r'pages?/[\w\-/]+')


def read(path):
    return path.read_text(encoding='utf-8', errors='replace')


def scan_file(path, root):
    text = read(path)
    rel = str(path.relative_to(root))
    hits = []
    for label, rx in [('request', REQ_RE), ('storage', STORAGE_RE), ('crypto', CRYPTO_RE)]:
        for m in rx.finditer(text):
            line = text.count('\n', 0, m.start()) + 1
            hits.append({'type': label, 'file': rel, 'line': line, 'match': m.group(0)[:120]})
    urls = sorted(set(URL_RE.findall(text)))[:200]
    routes = sorted(set(ROUTE_RE.findall(text)))[:200]
    return {'file': rel, 'urls': urls, 'routes': routes, 'hits': hits}


def load_app_json(root):
    app = root / 'app.json'
    if not app.exists():
        return {}
    try:
        return json.loads(read(app))
    except Exception:
        return {'parse_error': True, 'raw_path': str(app)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--max-files', type=int, default=5000)
    args = ap.parse_args()
    root = Path(args.src).resolve()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    exts = {'.js', '.ts', '.json', '.wxml', '.wxss', '.vue', '.jsx', '.tsx'}
    files = [p for p in root.rglob('*') if p.is_file() and p.suffix.lower() in exts]
    records = []
    all_urls, all_routes, all_hits = set(), set(), []
    for p in files[:args.max_files]:
        rec = scan_file(p, root)
        if rec['urls'] or rec['routes'] or rec['hits']:
            records.append(rec)
            all_urls.update(rec['urls'])
            all_routes.update(rec['routes'])
            all_hits.extend(rec['hits'])
    app_json = load_app_json(root)
    pages = app_json.get('pages', []) if isinstance(app_json, dict) else []
    subpackages = app_json.get('subpackages') or app_json.get('subPackages') or [] if isinstance(app_json, dict) else []
    result = {'src': str(root), 'files_scanned': min(len(files), args.max_files), 'app_json': app_json, 'pages': pages, 'subpackages': subpackages, 'urls': sorted(all_urls), 'routes': sorted(all_routes), 'hits': all_hits, 'records': records}
    (out / 'miniapp_static_inventory.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Miniapp Static Inventory', '', f'- source: `{root}`', f'- files scanned: {result["files_scanned"]}', f'- pages: {len(pages)}', f'- urls/domains: {len(all_urls)}', f'- signal hits: {len(all_hits)}', '', '## URLs / Domains']
    for u in sorted(all_urls)[:200]:
        lines.append(f'- `{u}`')
    lines += ['', '## Signal Hits', '| Type | File | Line | Match |', '|---|---|---:|---|']
    for h in all_hits[:300]:
        lines.append(f"| {h['type']} | `{h['file']}` | {h['line']} | `{h['match']}` |")
    (out / 'miniapp_static_inventory.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'src': str(root), 'files': result['files_scanned'], 'urls': len(all_urls), 'hits': len(all_hits), 'out': str(out)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
