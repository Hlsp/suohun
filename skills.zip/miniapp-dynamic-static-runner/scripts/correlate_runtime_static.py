#!/usr/bin/env python3
import argparse, json
from pathlib import Path
from urllib.parse import urlparse


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def traffic_items(data):
    if isinstance(data, dict) and 'workflows' in data:
        return data['workflows']
    if isinstance(data, dict) and 'items' in data:
        return data['items']
    if isinstance(data, list):
        return data
    return []


def path_tokens(url):
    p = urlparse(url if '://' in str(url) else 'http://x' + str(url)).path
    return [x for x in p.split('/') if len(x) >= 3 and not x.startswith('{')]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--inventory', required=True)
    ap.add_argument('--traffic', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    inv = load(args.inventory)
    traf = traffic_items(load(args.traffic))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    records = inv.get('records', [])
    correlations = []
    for item in traf:
        url = item.get('url') or item.get('path_template') or item.get('requestUrl') or ''
        toks = path_tokens(url)
        matches = []
        for rec in records:
            score = 0
            joined = ' '.join([rec.get('file','')] + rec.get('urls', []) + rec.get('routes', []) + [h.get('match','') for h in rec.get('hits', [])])
            for t in toks:
                if t.lower() in joined.lower():
                    score += 1
            if score:
                matches.append({'file': rec.get('file'), 'score': score, 'hit_types': sorted(set(h.get('type') for h in rec.get('hits', [])))})
        matches.sort(key=lambda x: x['score'], reverse=True)
        correlations.append({'workflow_id': item.get('id'), 'method': item.get('method'), 'url': url, 'tokens': toks, 'static_matches': matches[:10]})
    (out / 'miniapp_correlation.json').write_text(json.dumps({'items': correlations}, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Miniapp Runtime Static Correlation', '', '| Workflow | Method | URL | Top static matches |', '|---|---|---|---|']
    for c in correlations:
        top = ', '.join(f"`{m['file']}`({m['score']})" for m in c['static_matches'][:5])
        lines.append(f"| {c.get('workflow_id','')} | {c.get('method','')} | `{c.get('url','')}` | {top} |")
    (out / 'miniapp_correlation.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'traffic_items': len(traf), 'correlations': len(correlations), 'out': str(out)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
