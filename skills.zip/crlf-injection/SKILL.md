---
name: crlf-injection
description: "CRLF injection playbook. Use when user-controlled input may enter HTTP headers, redirects, cookies, logs, SMTP headers, cache metadata, proxy routing, or other line-oriented protocols."
role: specialist
domain: injection-server
---

# CRLF Injection

Use this skill when input may be interpreted as a line break by a downstream protocol or text parser.

## Core Model

CRLF injection is a boundary-breaking issue:

1. User input reaches a line-oriented sink.
2. The application or proxy decodes or preserves line separators.
3. The downstream component treats injected bytes as a new header, log line, protocol command, or message part.
4. The result changes routing, caching, cookies, redirects, email, logs, or client behavior.

The sink matters more than the raw payload.

## Recon Questions

- Which response headers reflect input: `Location`, `Set-Cookie`, `Content-Disposition`, `Link`, `Refresh`, custom headers?
- Are inputs decoded once, twice, or normalized by a proxy?
- Is the response served through CDN, reverse proxy, gateway, or cache?
- Can the effect be observed in raw response headers, logs, email source, or cache metadata?
- Does the target use HTTP/2, HTTP/1.1 downgrade, or framework-level header APIs?

## Test Families

### HTTP Response Header Injection

Test whether input can create or alter response headers. Validate in raw traffic and browser behavior separately.

### Redirect and Cookie Abuse

High-value sinks include `Location` and `Set-Cookie`. Check whether injected headers alter redirect target, cookie scope, cache policy, or browser security headers.

### Cache and Proxy Effects

If injected headers reach a shared cache, test only with cache-busters and self-scoped paths. Pivot to cache testing if response metadata changes.

### Email and Text Protocols

When the sink is SMTP, logs, CSV, or another line-oriented protocol, use the protocol-specific skill to avoid overclaiming.

### Encoding and Normalization

Try single decoding, double decoding, mixed newline forms, Unicode normalization, and path/header normalization one at a time.

## Validation Ladder

1. Find a reflection into a line-oriented sink.
2. Capture raw baseline traffic.
3. Inject one newline representation at a time.
4. Confirm sink-level effect in raw output.
5. Escalate only to a bounded impact: cookie, redirect, cache, email, or log proof.
6. Remove or expire test artifacts.

## Evidence Standard

Capture:

- sink location and baseline raw output
- mutated request
- raw output showing a new or changed line
- downstream impact, if any
- cache-buster or isolation marker
- cleanup step

## Pivots

- Email-specific sink: [email-header-injection](../email-header-injection/SKILL.md)
- Cache poisoning/deception: [web-cache-deception](../web-cache-deception/SKILL.md)
- Redirect sink: [open-redirect](../open-redirect/SKILL.md)
- Host-generated URLs: [http-host-header-attacks](../http-host-header-attacks/SKILL.md)
