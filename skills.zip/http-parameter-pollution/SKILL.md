---
name: http-parameter-pollution
description: "HTTP parameter pollution playbook. Use when duplicate keys, array syntax, mixed separators, encoded names, or parser differences between WAF, proxy, framework, and backend may change how parameters are interpreted."
role: specialist
domain: injection-server
---

# HTTP Parameter Pollution

## When to Use

Duplicate keys, array syntax, mixed separators, encoded names, or parser differences may alter parameter interpretation.

## High-Value Mutations

- `a=1&a=2`
- `a[]=1&a[]=2`
- `a=1;a=2`
- `a`, `%61`, `a%00`, case variants
- `role=user&role=admin`
- same semantic field in path/query/body

## Look For

Frontend/backend value mismatch, WAF/backend parser split, array fan-out, or polluted auth/tenant/object/price/status behavior.

## Pivots

- Role/org/tenant/object: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Amount/coupon/workflow: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- WAF parser differential: [waf-bypass-techniques](../waf-bypass-techniques/SKILL.md)
