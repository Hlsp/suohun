---
name: account-fixture-manager
description: "Manage black-box test account, tenant, role, object, token-reference, and state fixtures. Use when preparing A/B accounts, cross-tenant matrices, ownership proofs, special account states, object IDs, and safe credential references for BOLA, business logic, auth, race, and workflow tests."
role: specialist
domain: auth-api
---

# Account Fixture Manager

Use before BOLA, business logic, race, and auth-boundary testing.

## Principles
- Store secret references, not plaintext credentials.
- Record account role, tenant, state, and ownership context.
- Record object ownership separately from object IDs.
- Generate test pairs explicitly before mutation.

## Workflow
1. Initialize with `scripts/fixture_manager.py --file account_matrix.json init`.
2. Add accounts and owned objects.
3. Generate pairs for peer, cross-role, and cross-tenant tests.
4. Feed fixtures into runner and replay harness.

## Pivots
- BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- Runner: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
