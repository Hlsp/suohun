#!/usr/bin/env python3
import argparse,json
from pathlib import Path
def load(f):
    p=Path(f); return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'accounts':[],'objects':[],'pairs':[],'notes':[]}
def save(f,d): Path(f).parent.mkdir(parents=True,exist_ok=True); Path(f).write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--file',required=True); sub=ap.add_subparsers(dest='cmd',required=True); sub.add_parser('init')
    a=sub.add_parser('add-account'); a.add_argument('--label',required=True); a.add_argument('--role',default=''); a.add_argument('--tenant',default=''); a.add_argument('--state',default=''); a.add_argument('--secret-ref',default='do-not-store-secret-here')
    o=sub.add_parser('add-object'); o.add_argument('--id',required=True); o.add_argument('--type',required=True); o.add_argument('--owner',required=True); o.add_argument('--tenant',default=''); o.add_argument('--state',default=''); o.add_argument('--cleanup',default='')
    sub.add_parser('pairs'); args=ap.parse_args(); d=load(args.file)
    if args.cmd=='add-account':
        d['accounts']=[x for x in d.get('accounts',[]) if x.get('label')!=args.label]; d['accounts'].append({'label':args.label,'role':args.role,'tenant':args.tenant,'state':args.state,'secret_ref':args.secret_ref})
    elif args.cmd=='add-object':
        d['objects']=[x for x in d.get('objects',[]) if x.get('id')!=args.id]; d['objects'].append({'id':args.id,'type':args.type,'owner':args.owner,'tenant':args.tenant,'state':args.state,'cleanup':args.cleanup})
    elif args.cmd=='pairs':
        ac=d.get('accounts',[]); pairs=[]
        for i,x in enumerate(ac):
            for y in ac[i+1:]: pairs.append({'a':x.get('label'),'b':y.get('label'),'relation':'cross_tenant' if x.get('tenant')!=y.get('tenant') else ('cross_role' if x.get('role')!=y.get('role') else 'peer')})
        d['pairs']=pairs
    save(args.file,d); print(json.dumps({'file':args.file,'accounts':len(d.get('accounts',[])),'objects':len(d.get('objects',[])),'pairs':len(d.get('pairs',[]))},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
