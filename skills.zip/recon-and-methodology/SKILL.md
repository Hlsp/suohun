---
name: recon-and-methodology
description: "Reconnaissance and methodology playbook. Use when mapping authorized targets, scope, assets, entry points, auth states, technologies, APIs, frontend routes, high-value workflows, and test prioritization."
role: playbook
domain: recon-traffic-mcp
---

# Recon and Methodology

Use this skill at the start of an authorized assessment or when the target map is incomplete.

## Core Model

Good recon converts a large target into a prioritized test matrix:

1. Scope: allowed domains, apps, accounts, roles, environments, and exclusions.
2. Surface: hosts, ports, paths, APIs, frontend routes, mobile endpoints, WebSockets, files, and integrations.
3. State: auth levels, tenants, roles, objects, workflows, and business assets.
4. Priority: features where broken trust produces meaningful impact.

Do not expand breadth forever. Build enough map to choose high-value tests.

## Recon Questions

- What is explicitly in scope and what test accounts/roles are available?
- Which assets are active, authenticated, state-changing, or data-rich?
- Where are docs, schemas, source maps, route manifests, mobile configs, or API collections?
- Which features touch money, identity, tenant/admin control, files, exports, invites, approval, or secrets?
- Which technologies shape the next test: SPA, API gateway, GraphQL, CDN, SSO, object storage, workers?
- What rate, safety, and cleanup constraints apply?

## Workflow

1. Read scope and define account/role matrix.
2. Inventory live surfaces with minimal, low-noise probes.
3. Capture browser traffic and API docs before fuzzing.
4. Mark high-value workflows and object types.
5. Route each candidate to a focused skill instead of using a generic checklist.
6. Store evidence and unresolved leads separately.

## Prioritization Signals

- authenticated APIs with object IDs or tenant IDs
- account recovery, SSO, invite, delegation, admin, role flows
- payment, coupon, wallet, subscription, refund, quota, reward flows
- upload, preview, export, share, download, recycle-bin flows
- GraphQL schemas, hidden parameters, WebSockets, async workers
- cache/CDN/proxy layers and host/header trust

## Evidence Standard

Record scope item, asset, auth state, interesting endpoint/workflow, why it is high value, and next skill to load.

## Pivots

- Directory scan: [recon-dir-scan](../recon-dir-scan/SKILL.md)
- Fingerprinting: [recon-fingerprint](../recon-fingerprint/SKILL.md)
- API docs: [api-recon-and-docs](../api-recon-and-docs/SKILL.md)
- Browser orchestrator: [browser-pentest-orchestrator](../browser-pentest-orchestrator/SKILL.md)
- Business logic hunter: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
