---
name: binary-protection-bypass
description: "Binary hardening and protection bypass router. Use when reversing or exploiting native targets protected by ASLR, DEP, RELRO, PIE, stack canaries, CFG, packers, or sandbox boundaries and you need to route toward the right primitive-specific skill."
role: router
domain: native-pwn-reverse
---

# Binary Protection Bypass

Map format, mitigations, loader/libc/runtime, controllable bytes, leaks, target object, and crash offset. Route to stack, heap, format-string, arbitrary-write, browser, or sandbox skill by primitive.
