---
name: api-auth-and-jwt-abuse
description: "API authentication and JWT abuse router. Use when API requests depend on bearer tokens, cookies, API keys, JWTs, OAuth tokens, refresh tokens, device IDs, tenants, or claim-based authorization."
role: router
domain: auth-api
---

# API Auth and JWT Abuse

Use this as a fast router for API authentication and token-boundary testing.

## Route First

- JWT structure, claims, signatures, refresh, or replay: [jwt-oauth-token-attacks](../jwt-oauth-token-attacks/SKILL.md)
- OAuth/OIDC login, linking, redirect, state, nonce, or PKCE: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- Object or tenant authorization after authentication: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Login, reset, MFA, invite, or recovery bypass: [authbypass-authentication-flaws](../authbypass-authentication-flaws/SKILL.md)

## Core Questions

- What credential type authenticates the API request?
- Which service validates it and which service authorizes the object/action?
- Are user ID, tenant ID, role, scope, device, and MFA claims server-trusted or rechecked?
- Can the same token work across clients, tenants, environments, or API versions?
- Does logout, reset, revocation, or role change invalidate the token everywhere?

## Minimal Workflow

1. Capture one successful authenticated API request.
2. Remove credentials to confirm auth is required.
3. Swap credential between two self-owned accounts.
4. Mutate token claims or API object IDs one variable at a time.
5. Confirm server-side data/state change, not just response code.
6. Package replay steps and revoke test credentials.

## Evidence Standard

Record request, credential type, mutation, endpoint, response, actual state/data impact, and cleanup action.
