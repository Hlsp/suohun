---
name: runner-results-bridge
description: "Bridge blackbox-pentest-runner and Burp evidence outputs into persistent results and reports. Use when converting findings.json, Burp scanner/collaborator evidence, Repeater proof, and evidence directories into Markdown summaries, JSON imports, results-storage records, report drafts, or lifecycle statuses."
role: bridge
domain: reporting-governance
---

# Runner Results Bridge

Use after a runner cycle has candidate or confirmed findings.

## Workflow

1. Read `findings.json` from a runner workspace.
2. If Burp evidence exists, normalize it first with [burp-finding-bridge](../burp-finding-bridge/SKILL.md).
3. Normalize fields into storage-friendly records.
4. Export Markdown and JSON summaries.
5. Optionally import confirmed findings into `results-storage`.
6. Hand off Markdown to `pentest-report`.

## Lifecycle

`lead` -> `candidate` -> `confirmed` -> `reported` -> `fixed` -> `verified`

## Command

```bash
python scripts/bridge_results.py --run-dir runs/T --out runs/T/report
```

Add `--db-path path/to/results.sqlite` only when importing confirmed/reportable findings into persistent storage.

## Burp Evidence Rule

Scanner and Collaborator evidence should enter as `candidate` unless one replay path proves impact. Do not import scanner-only leads as confirmed vulnerabilities.

## Pivots

- Runner: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- Burp finding bridge: [burp-finding-bridge](../burp-finding-bridge/SKILL.md)
- Storage: [results-storage](../results-storage/SKILL.md)
- Report: [pentest-report](../pentest-report/SKILL.md)
- Fix verification: [logic-fix-verification](../logic-fix-verification/SKILL.md)
