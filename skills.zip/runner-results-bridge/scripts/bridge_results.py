#!/usr/bin/env python3
import argparse,json,sys
from pathlib import Path
ORD={'Critical':0,'High':1,'Medium':2,'Low':3,'Info':4}
def findings(run):
    p=Path(run)/'findings.json'; d=json.loads(p.read_text(encoding='utf-8-sig')) if p.exists() else {'findings':[]}; return d.get('findings',d if isinstance(d,list) else [])
def markdown(fs):
    lines=['# Runner Findings','']
    for i,f in enumerate(sorted(fs,key=lambda x:ORD.get(x.get('severity','Info'),9)),1):
        lines += [f"## {i}. {f.get('title','Untitled')}",'',f"- severity: {f.get('severity','Info')}",f"- status: {f.get('status','candidate')}",f"- confidence: {f.get('confidence','')}",f"- affected: {f.get('url') or f.get('affected_component','')}",'','### Impact','',str(f.get('impact','')).strip(),'','### Evidence']
        for k in ['baseline_request_ref','mutated_request_ref','before_state_ref','after_state_ref','cleanup_ref','evidence_path']:
            if f.get(k): lines.append(f"- {k}: `{f[k]}`")
        lines.append('')
    return '\n'.join(lines)
def import_db(fs,db,skill):
    sys.path.insert(0,str(Path(skill)/'scripts')); from storage_api import StorageAPI
    api=StorageAPI(db); ids=[]
    try:
        for f in fs:
            if f.get('status') not in ('confirmed','reported'): continue
            ids.append(api.store_vulnerability(host_ip=f.get('host_ip') or f.get('host') or '0.0.0.0',vuln_type=f.get('type','business-logic'),severity=f.get('severity','Medium'),title=f.get('title','Untitled finding'),subsystem=f.get('subsystem'),url=f.get('url'),parameter=f.get('parameter'),http_method=f.get('http_method','GET'),payload=f.get('mutated_request_ref') or f.get('payload'),response_evidence=f.get('after_state_ref') or f.get('evidence_path'),description=f.get('description') or f.get('impact'),affected_component=f.get('affected_component') or f.get('workflow_id'),proof_of_concept=f.get('reproduction') or f.get('evidence_path'),discovered_by_skill=f.get('discovered_by_skill','blackbox-pentest-runner')))
    finally: api.close()
    return ids
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--run-dir',required=True); ap.add_argument('--out',required=True); ap.add_argument('--db-path'); ap.add_argument('--storage-skill',default=r'C:\Users\zhang\.codex\skills\results-storage'); a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); fs=findings(a.run_dir)
    (out/'findings.normalized.json').write_text(json.dumps({'findings':fs},ensure_ascii=False,indent=2),encoding='utf-8'); (out/'findings.md').write_text(markdown(fs),encoding='utf-8')
    ids=import_db(fs,a.db_path,a.storage_skill) if a.db_path else []
    print(json.dumps({'findings':len(fs),'out':str(out),'imported_ids':ids},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
