﻿#!/usr/bin/env python3
"""Scan Java/JVM source for Ghost Bits high-byte truncation candidates."""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, List, Optional

DEFAULT_SUFFIXES = {".java", ".kt", ".scala", ".groovy"}
DEFAULT_EXCLUDE = {".git", ".svn", "target", "build", "out", "node_modules", ".idea", ".gradle"}
HOT_PATH_HINTS = re.compile(r"(?i)(controller|handler|filter|interceptor|servlet|upload|multipart|header|mail|smtp|http|proxy|path|url|decode|parser|serializer|bcel|redis|template|sql|auth)")


@dataclass
class PatternDef:
    name: str
    severity: str
    regex: str
    why: str


PATTERNS: List[PatternDef] = [
    PatternDef("data_output_write_bytes", "high", r"\b(?:DataOutputStream\s*\.\s*)?writeBytes\s*\(", "writeBytes(String) discards high 8 bits of every char"),
    PatternDef("random_access_file_write_bytes", "high", r"\bRandomAccessFile\b", "RandomAccessFile.writeBytes has the same low-byte behavior"),
    PatternDef("explicit_byte_cast", "high", r"\(\s*byte\s*\)\s*[A-Za-z_$][\w$]*(?:\s*\.\s*charAt\s*\([^)]*\))?", "explicit narrowing to byte"),
    PatternDef("low_byte_mask", "high", r"&\s*(?:0[xX]0*[Ff]{2}\b|255\b)", "manual low-byte extraction"),
    PatternDef("output_stream_write_single_int", "medium", r"\.\s*write\s*\(\s*[A-Za-z_$][\w$]*(?:\s*\.\s*charAt\s*\([^)]*\))?\s*\)", "OutputStream.write(int) writes only low-order 8 bits; confirm receiver type"),
    PatternDef("byte_array_output_stream", "medium", r"\bByteArrayOutputStream\b", "often paired with write(int) low-byte accumulation"),
    PatternDef("legacy_string_low_byte_api", "medium", r"\bStringBufferInputStream\b|\.\s*getBytes\s*\(\s*\d+\s*,\s*\d+\s*,", "legacy string-to-byte APIs discard high bits"),
    PatternDef("char_iteration_to_byte", "medium", r"\.\s*charAt\s*\([^)]*\).*?(?:\(\s*byte\s*\)|&\s*(?:0[xX]0*[Ff]{2}|255)|\.\s*write\s*\()", "charAt value appears to feed byte projection"),
    PatternDef("permissive_hex_digit", "low", r"Character\s*\.\s*digit\s*\(|convertHexDigit|fromHex|hexTo", "custom hex decoders may hide low-byte or parser-view issues"),
    PatternDef("charset_default_getbytes", "low", r"\.\s*getBytes\s*\(\s*\)", "default charset conversion; not Ghost Bits by itself but worth checking near filters"),
]


@dataclass
class Hit:
    file: str
    line: int
    column: int
    pattern: str
    severity: str
    adjusted_severity: str
    snippet: str
    why: str


def severity_rank(s: str) -> int:
    return {"low": 1, "medium": 2, "high": 3}.get(s, 0)


def bump_severity(sev: str, path: Path, line: str) -> str:
    combined = f"{path} {line}"
    if HOT_PATH_HINTS.search(combined) and severity_rank(sev) < 3:
        return "high" if sev == "medium" else "medium"
    return sev


def iter_files(root: Path, suffixes: set[str]) -> Iterable[Path]:
    if root.is_file():
        if root.suffix.lower() in suffixes:
            yield root
        return
    for p in root.rglob("*"):
        if any(part in DEFAULT_EXCLUDE for part in p.parts):
            continue
        if p.is_file() and p.suffix.lower() in suffixes:
            yield p


def scan_file(path: Path, context: int) -> List[Hit]:
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    hits: List[Hit] = []
    for idx, line in enumerate(lines, start=1):
        for pat in PATTERNS:
            for m in re.finditer(pat.regex, line):
                start = max(1, idx - context)
                end = min(len(lines), idx + context)
                snippet = "\n".join(f"{n}: {lines[n-1]}" for n in range(start, end + 1))
                adj = bump_severity(pat.severity, path, line)
                hits.append(Hit(
                    file=str(path),
                    line=idx,
                    column=m.start() + 1,
                    pattern=pat.name,
                    severity=pat.severity,
                    adjusted_severity=adj,
                    snippet=snippet,
                    why=pat.why,
                ))
    return hits


def render_markdown(hits: List[Hit], root: Path) -> str:
    counts = {"high": 0, "medium": 0, "low": 0}
    for h in hits:
        counts[h.adjusted_severity] = counts.get(h.adjusted_severity, 0) + 1
    lines = [
        "# Ghost Bits Java truncation scan",
        "",
        f"Root: `{root}`",
        f"Hits: {len(hits)} (high={counts.get('high',0)}, medium={counts.get('medium',0)}, low={counts.get('low',0)})",
        "",
    ]
    for h in sorted(hits, key=lambda x: (-severity_rank(x.adjusted_severity), x.file, x.line, x.pattern)):
        lines.extend([
            f"## {h.adjusted_severity.upper()} {h.pattern} `{h.file}:{h.line}`",
            "",
            f"Reason: {h.why}",
            "",
            "```",
            h.snippet,
            "```",
            "",
            "Next: prove user control, downstream byte/protocol semantics, and check-before-use divergence.",
            "",
        ])
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Scan Java/JVM source for Ghost Bits truncation candidates")
    ap.add_argument("--root", required=True, help="source root or file")
    ap.add_argument("--suffix", action="append", help="extra suffix to include, e.g. .jsp")
    ap.add_argument("--context", type=int, default=2, help="context lines around each hit")
    ap.add_argument("--format", choices=["markdown", "json"], default="markdown")
    ap.add_argument("--out", help="write report to file")
    args = ap.parse_args(argv)

    root = Path(args.root).resolve()
    suffixes = set(DEFAULT_SUFFIXES)
    if args.suffix:
        suffixes.update(s if s.startswith(".") else f".{s}" for s in args.suffix)

    hits: List[Hit] = []
    for f in iter_files(root, suffixes):
        hits.extend(scan_file(f, args.context))

    if args.format == "json":
        output = json.dumps({"root": str(root), "hits": [asdict(h) for h in hits]}, ensure_ascii=False, indent=2)
    else:
        output = render_markdown(hits, root)

    if args.out:
        Path(args.out).write_text(output + "\n", encoding="utf-8", newline="\n")
    else:
        sys.stdout.reconfigure(encoding="utf-8")
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())






