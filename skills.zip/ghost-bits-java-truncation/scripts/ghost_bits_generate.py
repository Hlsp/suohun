﻿#!/usr/bin/env python3
"""Generate deterministic Ghost Bits / low-byte Unicode variants.

The generated Unicode characters preserve the target low byte. If a Java/JVM
sink later writes only low-order 8 bits, the original byte payload is restored.
"""
from __future__ import annotations

import argparse
import codecs
import json
import random
import sys
import urllib.parse
from dataclasses import dataclass, asdict
from typing import Iterable, List, Optional

SURROGATE_HIGHS = set(range(0xD8, 0xE0))


@dataclass
class Mapping:
    index: int
    original_repr: str
    original_codepoint: str
    low_byte: str
    ghost_char: str
    ghost_codepoint: str
    high_byte: str
    transformed: bool


def parse_payload(args: argparse.Namespace) -> str:
    if args.payload_hex:
        raw = bytes.fromhex(args.payload_hex.replace(" ", ""))
        return raw.decode("latin-1")
    payload = args.payload or ""
    if args.decode_escapes:
        payload = codecs.decode(payload, "unicode_escape")
    return payload


def printable_repr(ch: str) -> str:
    if ch == "\r":
        return r"\r"
    if ch == "\n":
        return r"\n"
    if ch == "\t":
        return r"\t"
    if ch == " ":
        return "SPACE"
    if ord(ch) < 0x20 or ord(ch) == 0x7F:
        return f"\\x{ord(ch):02x}"
    return ch


def choose_high(low: int, rng: random.Random, mode: str, fixed: Optional[int]) -> int:
    if fixed is not None:
        if fixed <= 0 or fixed > 0xFF or fixed in SURROGATE_HIGHS:
            raise ValueError("--high-byte must be 0x01..0xff and not 0xd8..0xdf")
        return fixed
    if mode == "cjk":
        # CJK Unified Ideographs: U+4E00..U+9FFF. This keeps output printable.
        return rng.randint(0x4E, 0x9F)
    if mode == "bmp":
        choices = [h for h in range(0x01, 0x100) if h not in SURROGATE_HIGHS]
        return rng.choice(choices)
    if mode == "low-noise":
        # Mostly printable extended Latin / Greek / Cyrillic zones, less visually noisy than CJK.
        choices = [0x01, 0x02, 0x03, 0x04]
        return rng.choice(choices)
    raise ValueError(f"unknown high-byte mode: {mode}")


def should_transform(ch: str, only: Optional[str], skip: Optional[str], ascii_only: bool) -> bool:
    if ascii_only and ord(ch) > 0x7F:
        return False
    if only is not None and ch not in only:
        return False
    if skip is not None and ch in skip:
        return False
    return True


def make_variant(payload: str, args: argparse.Namespace) -> tuple[str, List[Mapping]]:
    rng = random.Random(args.seed)
    variant_chars: List[str] = []
    rows: List[Mapping] = []
    fixed = int(args.high_byte, 0) if args.high_byte else None
    for idx, ch in enumerate(payload):
        transform = should_transform(ch, args.only_chars, args.skip_chars, args.ascii_only)
        low = ord(ch) & 0xFF
        if transform:
            high = choose_high(low, rng, args.high, fixed)
            cp = (high << 8) | low
            ghost = chr(cp)
        else:
            high = 0
            cp = ord(ch)
            ghost = ch
        variant_chars.append(ghost)
        rows.append(Mapping(
            index=idx,
            original_repr=printable_repr(ch),
            original_codepoint=f"U+{ord(ch):04X}",
            low_byte=f"0x{low:02X}",
            ghost_char=ghost,
            ghost_codepoint=f"U+{ord(ghost):04X}",
            high_byte=f"0x{high:02X}" if transform else "",
            transformed=transform,
        ))
    return "".join(variant_chars), rows


def json_escape(s: str) -> str:
    return "".join(f"\\u{ord(ch):04x}" for ch in s)


def low_projection(s: str) -> str:
    return "".join(chr(ord(ch) & 0xFF) for ch in s)


def render_table(rows: Iterable[Mapping]) -> str:
    lines = ["idx | original | low | ghost | codepoint | high | transformed",
             "---:|---|---|---|---|---|---"]
    for r in rows:
        ghost_display = r.ghost_char if r.transformed else r.original_repr
        lines.append(f"{r.index} | {r.original_repr} | {r.low_byte} | {ghost_display} | {r.ghost_codepoint} | {r.high_byte} | {r.transformed}")
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Generate Ghost Bits low-byte Unicode variants")
    ap.add_argument("--payload", help="literal payload string")
    ap.add_argument("--payload-hex", help="payload bytes as hex, decoded with latin-1")
    ap.add_argument("--decode-escapes", action="store_true", help=r"decode Python-style escapes in --payload, e.g. \r\n")
    ap.add_argument("--seed", type=int, default=1337, help="deterministic RNG seed")
    ap.add_argument("--high", choices=["cjk", "bmp", "low-noise"], default="cjk", help="high-byte selection strategy")
    ap.add_argument("--high-byte", help="fixed high byte such as 0x4e")
    ap.add_argument("--only-chars", help="only transform these literal characters")
    ap.add_argument("--skip-chars", help="do not transform these literal characters")
    ap.add_argument("--ascii-only", action="store_true", default=True, help="skip input chars above 0x7f (default true)")
    ap.add_argument("--format", choices=["all", "json", "table", "raw", "url", "json-escape"], default="all")
    ap.add_argument("--out", help="write output to file with UTF-8")
    args = ap.parse_args(argv)

    if not args.payload and not args.payload_hex:
        ap.error("provide --payload or --payload-hex")

    payload = parse_payload(args)
    variant, rows = make_variant(payload, args)
    data = {
        "original": payload,
        "variant": variant,
        "url_encoded_utf8": urllib.parse.quote(variant, safe=""),
        "json_escape": json_escape(variant),
        "low_byte_projection": low_projection(variant),
        "seed": args.seed,
        "high_mode": args.high,
        "mapping": [asdict(r) for r in rows],
    }

    if args.format == "json":
        output = json.dumps(data, ensure_ascii=True, indent=2)
    elif args.format == "table":
        output = render_table(rows)
    elif args.format == "raw":
        output = variant
    elif args.format == "url":
        output = data["url_encoded_utf8"]
    elif args.format == "json-escape":
        output = data["json_escape"]
    else:
        output = (
            f"Original: {payload}\n"
            f"Variant: {variant}\n"
            f"URL-encoded UTF-8: {data['url_encoded_utf8']}\n"
            f"JSON escape: {data['json_escape']}\n"
            f"Low-byte projection: {data['low_byte_projection']}\n\n"
            + render_table(rows)
        )

    if args.out:
        with open(args.out, "w", encoding="utf-8", newline="\n") as f:
            f.write(output)
            f.write("\n")
    else:
        sys.stdout.reconfigure(encoding="utf-8")
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

