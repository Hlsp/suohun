# External source notes

These links informed the skill design and should be treated as background anchors, not as proof for any specific target.

- Oracle Java SE 21 `DataOutputStream.writeBytes`: documents that each character is written by discarding high eight bits. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/io/DataOutputStream.html
- Oracle Java SE 21 `OutputStream.write(int)`: documents that only low-order eight bits are written and high bits are ignored. https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/io/OutputStream.html
- Java Language Specification 5.1.3: narrowing conversion from `char` to smaller integral types discards higher bits. https://docs.oracle.com/javase/specs/jls/se21/html/jls-5.html
- Public Ghost Bits / Cast Attack writeups summarize the view-difference model and common audit patterns. Example: https://www.hacktwohub.com/5501.html
- Request smuggling background for protocol-boundary proofs: https://portswigger.net/web-security/request-smuggling
- Vendor advisories should be used for component version truth. Example GeoServer advisory: https://github.com/geoserver/geoserver/security/advisories/GHSA-6jj6-gm7p-fcvv
