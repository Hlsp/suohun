# Integrating Ghost Bits into the existing skill suite

This skill should act as a specialist branch inside the user's normal Web/SRC workflow.

## Daily routing matrix

| Normal task | Start with | Switch to this skill when |
|---|---|---|
| 黑盒不可登录单 URL | `security-test-dispatcher`, `blackbox-pentest-runner`, `preauth-js-hidden-logic-hunter` | Java stack evidence plus non-ASCII/parser/WAF view difference appears. |
| 黑盒可登录 / A-B账号 | `auth-role-matrix-runner`, `traffic-to-workflow-mapper`, `single-variable-replay-harness` | One object/action has a filter/parser mismatch and a Java backend is likely. |
| 上传、导入、附件、预览 | `upload-insecure-files`, `file-access-vuln`, `arbitrary-write-to-rce` | File name or extension checks may be Unicode-view vs byte-view inconsistent. |
| Header、邮件、回调、网关 | `crlf-injection`, `email-header-injection`, `request-smuggling` | CR/LF or protocol delimiter may be reconstructed by low-byte writes. |
| Java源码审计 | `security-bounty-hunter`, `injection-checking`, this skill | Sinks like `writeBytes`, `(byte) ch`, `ch & 0xff`, or custom decoders appear. |
| WAF绕过 | `waf-bypass-techniques` | Only after a backend low-byte sink is proven or strongly indicated. |
| 报告与复测 | `logic-evidence-pack`, `results-storage`, `pentest-report` | A stable replay and evidence package exist. |

## Prompt snippets

- `使用 $ghost-bits-java-truncation 审计这个 Java 项目，先扫 char->byte 截断点，再按可达性排序输出高价值候选。`
- `使用 $ghost-bits-java-truncation 针对这个上传接口做单变量验证，只改 filename 字段，输出 Ghost Bits 映射表和复现请求。`
- `这个接口疑似 Java 后端 + WAF 拦截，请先判断是否存在低8位执行视图，不要只做通用 WAF payload。`

## Evidence standard for daily reports

A reportable case should include:

1. why Java/JVM low-byte behavior is relevant
2. the exact sink or parser chain
3. baseline vs normal payload vs Ghost Bits payload
4. mapping table and fixed seed
5. backend semantic proof
6. cleanup/rollback step

## Where this fills a gap

The existing suite already has strong routers for injection, file access, upload, CRLF, request smuggling, deserialization, and WAF bypass. This skill adds a missing **cross-cutting parser-view differential** layer: it decides when Unicode high-byte characters can be projected into dangerous low bytes and then hands the confirmed case back to the relevant specialist skill for impact verification.


## Java target default policy

User preference: when a target is a Java/JVM website, automatically try Ghost Bits as a bounded bypass strategy during normal vulnerability hunting.

Operationally this means:

1. Fingerprint Java clues early: `JSESSIONID`, Tomcat/Spring/Struts/Shiro/JSP errors, `.do`, `.action`, `/actuator`, Java stack traces, GeoServer-like paths, Maven/Gradle artifacts, or Java-style API names.
2. For every promising payload class selected by another skill, create a Ghost Bits sibling payload:
   - upload/path payloads from `upload-insecure-files`, `path-traversal-lfi`, `file-access-vuln`
   - injection payloads from `sqli-sql-injection`, `cmdi-command-injection`, `ssti-server-side-template-injection`, `expression-language-injection`
   - protocol payloads from `crlf-injection`, `email-header-injection`, `request-smuggling`
   - deserialization/class-name payloads from `deserialization-insecure`, `jndi-injection`
3. Keep the first pass small: baseline + normal payload + 1 Ghost Bits variant. Add more variants only after response behavior changes.
4. Record Ghost Bits attempts even if they are negative; they explain that Java-specific bypass was considered.
5. Still require backend semantic proof before reporting impact.

### Suggested default prompt addition

When you start a Java target, add this sentence to the task prompt:

`如果目标是 Java/JVM 网站，请默认启用 $ghost-bits-java-truncation：对每个高价值候选 payload 生成 1-3 个 Ghost Bits 变体，按单变量方式验证，并只把有后端语义证据的结果进入报告。`
