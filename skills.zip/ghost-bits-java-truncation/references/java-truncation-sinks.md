# Java truncation sinks and audit guidance

## Highest-value sinks

| Sink / pattern | Why it matters | First validation step | Common false positives |
|---|---|---|---|
| `DataOutputStream.writeBytes(String)` | Each Java `char` is written as one low byte; high 8 bits are discarded. | Trace the string source and downstream protocol parser. | Intentional ISO-8859-1 byte bridge with prior ASCII-only validation. |
| `OutputStream.write(int)` / `ByteArrayOutputStream.write(int)` | API writes only the low 8 bits of the integer argument. | Check whether argument originates from `char`, Unicode string iteration, or decoder output. | Already-masked binary byte buffers. |
| `(byte) ch`, `(byte) c`, `(byte) someChar` | Explicit narrowing from 16-bit char/int to signed byte. | Confirm attacker can control the narrowed value. | Binary parsing where input is already bytes. |
| `ch & 0xff`, `c & 255` | Manual low-byte extraction; often used in decoders/protocol clients. | Find whether result is written to byte protocol or used as syntax. | Correct binary handling after `InputStream.read()`. |
| `RandomAccessFile.writeBytes(String)` | Writes each character low byte to file. | Check user-controlled file/path/content writes. | Internal fixed ASCII strings. |
| deprecated `String.getBytes(int,int,byte[],int)` / `StringBufferInputStream` | Legacy low-byte APIs. | Identify old libraries and reachable call chains. | Dead code or tests. |
| custom hex/URL decoders: `fromHex`, `convertHexDigit`, `Character.digit` wrappers | Permissive folding can turn invalid-looking Unicode or `%2>`-style input into syntax. | Compare strict decoder output vs runtime output. | Correct strict rejection path. |

## Ranking logic

Prioritize a hit when all three are true:

1. The value is attacker-controlled or comes from request, file, queue, DB, or external protocol data.
2. The low-byte result is consumed by a security-sensitive grammar: file extension, path separator, CRLF, HTTP framing, SMTP command, Redis RESP, SQL/template syntax, serialized class name, or bytecode string.
3. There is a check-before-use boundary: WAF, filter, regex, allowlist, extension check, auth exclusion, or log/alert logic sees the Unicode string before the low-byte sink.

## Minimal audit commands

```powershell
Select-String -Path .\src\**\*.java -Pattern 'writeBytes\(|&\s*0[xX]?ff\b|&\s*255\b|\(\s*byte\s*\)|StringBufferInputStream|RandomAccessFile|OutputStream\.write|ByteArrayOutputStream'
python .\scripts\scan_java_truncation.py --root .\src --format markdown --out ghostbits-scan.md
```

## Remediation patterns

- Use explicit encodings: `value.getBytes(StandardCharsets.UTF_8)` or a protocol-required charset.
- Validate after final decode/normalization, not before it.
- Reject unexpected non-ASCII in protocol fields that are supposed to be ASCII: header names/values, file extensions, path control segments, SMTP/Redis commands.
- Replace permissive hex/URL decoders with strict decoders that reject invalid digits and overlong or mixed encodings.
- Log both the original Unicode string and the final byte/protocol view for security-relevant parsers.

## Source anchors

- Java `DataOutputStream.writeBytes` explicitly discards high eight bits of each character: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/io/DataOutputStream.html
- Java `OutputStream.write(int)` writes the low-order eight bits and ignores high-order bits: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/io/OutputStream.html
- JLS narrowing primitive conversion from `char` to smaller integral types discards higher bits: https://docs.oracle.com/javase/specs/jls/se21/html/jls-5.html
