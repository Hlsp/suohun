# Ghost Bits payload profiles

These are seed payload lanes for Java/JVM targets. They are not proof by themselves; they are inputs for bounded single-variable tests.

## Profiles

### java-web-default

A small first-pass set covering high-value Java web parser boundaries:

- upload/file extension: `.jsp`, `.jspx`, `shell.jsp`, `a.jsp;.jpg`
- path traversal: `../`, `../../WEB-INF/web.xml`, `..\..\windows\win.ini`
- CRLF/header: `\r\nX-Ghost: 1`, `\r\nContent-Length: 0\r\n\r\n`
- SQL metacharacters: `' OR '1'='1`, `' UNION SELECT NULL--`
- command separators: `; id`, `| whoami`, `$(id)`
- template/expression markers: `${7*7}`, `#{7*7}`, `%{7*7}`
- deserialization/class markers: `@type`, `com.sun.org.apache.bcel.internal.util.ClassLoader`, `ldap://127.0.0.1/a`

### upload-path

Use with upload, preview, download, import, and static resource endpoints.

### header-protocol

Use with headers, callbacks, proxy/gateway features, mail fields, and request-smuggling hypotheses.

### injection-core

Use when a specialist injection skill has already identified a likely SQL/CMD/SSTI/EL parser boundary.

## Triage labels

- `no effect`: same response as baseline and no relevant side effect.
- `filter bypass only`: WAF/filter response changed but backend semantics did not.
- `parser view difference`: backend error, route, or parser branch changed in a way consistent with low-byte projection.
- `backend semantic proof`: low-byte result created an observable server-side effect.
- `reportable impact`: semantic proof plus meaningful data access, write, code execution, auth bypass, or cross-boundary action.
