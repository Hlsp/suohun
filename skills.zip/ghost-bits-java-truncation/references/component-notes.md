# Component-focused Ghost Bits notes

Use these profiles only after you have a concrete input and suspected Java/JVM low-byte sink.

## Uploads and file names

Hypothesis: extension or path validation sees Unicode, while a later file write or multipart parser stores low-byte ASCII.

- Candidate low bytes: `.`, `/`, `\`, `j`, `s`, `p`, `%`, NUL-like separators if the downstream API mishandles them.
- Proof artifact: stored file name, resolved path, rejected-vs-accepted extension decision, or server-side file content reachable through expected route.
- Pair with `upload-insecure-files`, `arbitrary-write-to-rce`, or `exploit-file-download` depending on impact.

## Header / CRLF / request framing

Hypothesis: header validation allows a Unicode value, but low-byte write creates `\r\n`, extra header, response split, SMTP command, or request smuggling boundary.

- Candidate low bytes: CR `0x0d`, LF `0x0a`, `:`, space, `C`, `L`, `T`, `E`.
- Proof artifact: captured raw bytes, downstream server receiving extra header/request, response header split, or mail envelope mutation.
- Pair with `crlf-injection`, `email-header-injection`, or `request-smuggling`.

## Paths and URL decoders

Hypothesis: auth/router/filter checks one path view, but a later decoder or path normalizer folds low bytes into `../`, `%2e`, slash, semicolon, or matrix-param syntax.

- Candidate low bytes: `.`, `/`, `\`, `%`, `;`, `?`, `#`.
- Proof artifact: same request reaches a route or file outside the validated path, or an auth exclusion is bypassed.
- Pair with `path-traversal-lfi`, `open-redirect`, or `authbypass-authentication-flaws` as appropriate.

## Deserialization / class names / BCEL-like byte strings

Hypothesis: a class name, marker string, or encoded bytecode is filtered as Unicode text, then low-byte conversion reconstructs dangerous ASCII or bytecode.

- Candidate low bytes: `@`, `$`, `.`, `/`, `;`, class-name letters, BCEL marker bytes, serialized stream magic bytes.
- Proof artifact: class resolution attempt, deserializer error with reconstructed name, controlled gadget/class loading path, or safe canary execution in a CTF sandbox.
- Pair with `deserialization-insecure`, `jndi-injection`, or `vm-and-bytecode-reverse`.

## SQL / template / command payloads

Use Ghost Bits here only when the app has a confirmed low-byte decode bridge before the SQL/template/shell sink. Otherwise use normal injection skills first.

- Candidate low bytes: quote, space, comment marker, pipe, semicolon, backtick, dollar, braces.
- Proof artifact: backend parser semantics changed, not just WAF response changed.
- Pair with `sqli-sql-injection`, `ssti-server-side-template-injection`, `cmdi-command-injection`, or `expression-language-injection`.

## Defensive triage

- Search recent logs for non-ASCII in sensitive fields: path, query, header, multipart file names, email fields, serialized or encoded parameters.
- Compare Unicode string view and low-byte projection: `''.join(chr(ord(c) & 0xff) for c in value)` in a local script.
- Upgrade affected components according to vendor advisories, but still audit self-written low-byte bridges.
