---
name: ghost-bits-java-truncation
description: Use for authorized CTF, SRC, code audit, or Web/API vulnerability hunting against Java/JVM websites, especially Spring, Servlet, Tomcat, JSP, Struts, Shiro, GeoServer, Java gateways, or WAF-protected Java APIs. Trigger on Java target fingerprinting, Ghost Bits, Cast Attack, Unicode low-byte payload variants, payload bypass attempts, Java char-to-byte truncation, DataOutputStream.writeBytes, OutputStream.write(int), RandomAccessFile.writeBytes, (byte) char, ch & 0xff, file-name/header/path parser discrepancies, WAF bypass candidates, or parser view-difference evidence.
role: hunter
domain: java-jvm
metadata:
  short-description: Java Ghost Bits truncation testing
---

# Ghost Bits Java Truncation

Use this skill to test **Ghost Bits / Cast Attack** style bugs: security checks see a Unicode string, but a later Java/JVM byte sink discards high bits and executes a different low-byte protocol view.

## Core model

- Use this opportunistically on Java/JVM targets as a **bounded bypass lane** for candidate payloads, especially when normal payloads are blocked, normalized, filtered, or logged differently.
- Impact still depends on evidence: Ghost Bits is strongest when Java/JVM char-to-byte narrowing, low-byte writes, permissive decoder folding, or component parser splits are present.
- Mental model: `ghost_char = (high_byte << 8) | target_byte`; if a sink keeps only the low 8 bits, `ghost_char` becomes `target_byte` at execution time.
- Decisive evidence is **view divergence**: validator/log/WAF sees Unicode, while file system, HTTP, SMTP, Redis, deserializer, or another byte protocol sees ASCII control syntax.
- Never report “WAF bypass” alone. Confirm the backend low-byte semantics changed behavior, reached a parser branch, wrote a file name, changed a header/request boundary, or hit a vulnerable sink.

## Fast routing

1. **Source or bytecode available**: scan for sinks first, then build targeted payloads.
2. **Only traffic available**: use single-variable replay; mutate one parameter/header/path segment at a time and compare baseline, blocked normal payload, and Ghost Bits variant.
3. **Known Java component**: check version and component notes, then verify the exact parser chain rather than spraying payloads.
4. **Java/JVM target but no sink evidence yet**: run opportunistic mode. For each high-value candidate payload chosen by the relevant specialist skill, generate 1-3 deterministic Ghost Bits variants and test them as an alternate encoding lane. Keep it bounded and single-variable.
5. **No Java/JVM evidence**: defer to normal WAF/injection/file/auth skills; do not force this technique.

## Workflow

### 0. Java-default opportunistic mode

When the target is likely Java/JVM (`JSESSIONID`, `X-Powered-By` clues, Spring/Struts/Shiro/Tomcat/JSP errors, Java stack traces, `.do`/`.action`/Spring-style APIs, GeoServer-like apps, Maven/Gradle artifacts, or bundle/API naming), always add a small Ghost Bits lane to normal vulnerability testing:

- Do not replace the normal payload path; run it beside `sqli`, `cmdi`, `ssti`, `path traversal`, `upload`, `crlf`, `deserialization`, and `request smuggling` checks.
- Generate variants only for payloads already selected by the active specialist skill or workflow hypothesis.
- Use `--seed` and keep 1-3 variants per payload first; expand only when one variant changes behavior.
- Test exactly one request location at a time: one path segment, one query key/value, one JSON field, one filename, or one header.
- Classify results as: `no effect`, `filter bypass only`, `parser view difference`, `backend semantic proof`, or `reportable impact`.

Quick batch helper:

```powershell
python .\scripts\ghost_bits_batch.py --profile java-web-default --format markdown --out ghostbits-payloads.md
python .\scripts\ghost_bits_batch.py --profile upload-path --seed-base 9000 --format jsonl --out ghostbits-upload.jsonl
```

### 1. Establish a narrow hypothesis

Capture:

- target input location: path, query, JSON field, multipart filename, header, cookie, email field, serialized blob, or protocol value
- expected dangerous low-byte sequence: `.jsp`, `../`, CRLF, `@type`, SQL metacharacter, BCEL marker, protocol delimiter
- suspected sink: `writeBytes`, `write(int)`, `(byte) ch`, `ch & 0xff`, custom hex decoder, legacy byte bridge, or component version

### 2. Static sink triage

Run the scanner when source is available:

```powershell
python .\scripts\scan_java_truncation.py --root <project-or-src> --format markdown --out ghostbits-scan.md
```

Prioritize hits that are both:

- reachable from user input or external data, and
- upstream of file names, headers, path normalization, network clients, deserializers, caches, or embedded protocol builders.

Read `references/java-truncation-sinks.md` for sink ranking and false-positive handling.

### 3. Generate reproducible variants

Use deterministic payload generation first:

```powershell
python .\scripts\ghost_bits_generate.py --payload ".jsp" --seed 1337 --high cjk --format all
python .\scripts\ghost_bits_generate.py --payload "\r\nX-Test: 1" --seed 7 --format json
python .\scripts\ghost_bits_batch.py --profile java-web-default --format markdown --out ghostbits-payloads.md
```

Prefer CJK/BMP printable variants for HTTP-visible fields. Avoid broad random fuzzing until one narrow flow is proven.

### 3.1 Preserve transport fidelity for multipart filename attacks

When the Ghost Bits target is a **multipart filename**, verify that your client preserves the Unicode filename end to end before blaming the server:

- Some Python or HTTP helper stacks will downgrade non-ASCII multipart `filename=` values to `?` or another fallback during body generation.
- For filename-differential testing, prefer a real browser-origin upload (`fetch` + `FormData` + `File`) or a raw captured multipart request in Repeater.
- First prove a harmless projection such as `a.txt` before moving to blocked targets such as `a.jsp`.
- Compare four views when available:
  1. original filename shown by the app or WAF
  2. block/allow decision
  3. backend parsed filename
  4. returned retrieval path or href

If the backend parsed filename is wrong even though the low-byte math looks correct, the problem may be the **transport or parser charset lane**, not the Ghost Bits idea itself.

### 3.2 Brute-force the blocker character, not the whole payload

For upload WAF bypass, do not fuzz the entire filename first. Keep all other low-byte positions stable and brute-force only the decisive blocked character or separator:

- Example workflow:
  - prove safe baseline `a.txt`
  - prove normal `a.jsp` is blocked
  - search only the dot or extension characters until the backend really parses `a.txt`
  - freeze that working high-byte lane
  - project the same lane onto `a.jsp`
- This keeps the request single-variable and quickly distinguishes:
  - client/body encoding damage
  - parser-specific Unicode folding
  - real low-byte truncation success

For Tomcat/JSP upload labs, a printable BMP codepoint may fail while another one with the same low byte succeeds. Save the exact working code point per critical byte and reuse that lane for later payloads.

### 4. Validate one variable at a time

For black-box testing, keep three requests:

1. baseline business request
2. normal attack string that is blocked or rejected
3. Ghost Bits variant with the same low-byte semantics

Record each attempt in the active run directory as a normal single-variable replay:

- baseline request file
- request location mutated
- original payload
- Ghost Bits payload and deterministic seed
- Unicode code point -> low byte mapping
- response/business/state diff
- classification: `no effect`, `filter bypass only`, `parser view difference`, `backend semantic proof`, or `reportable impact`

A valid finding needs at least one of:

- byte-level artifact: created file, changed path, altered header, split request, changed stored value
- parser branch: backend error or behavior proving low-byte interpretation
- confirmed sink: stack trace, code line, instrumentation, or component advisory matching the flow
- replay stability from a clean state

### 5. Component-focused checks

Read `references/component-notes.md` only for the relevant component class:

- uploads and file names
- HTTP request/response headers and request smuggling boundaries
- path and URL decoders
- Java serialization / BCEL / class-name strings
- SMTP, Redis, and other line-oriented protocols

### 6. Evidence package

Save concise evidence:

- exact baseline and mutated requests
- generated mapping table: original char -> ghost char -> Unicode code point -> low byte
- response diff or runtime artifact
- sink location and data-flow path when available
- safe cleanup or reset step

For upload-to-RCE cases, add one extra proof chain:

- blocked normal filename such as `a.jsp`
- allowed Ghost Bits filename
- backend parsed filename or returned href showing real low-byte extension
- direct retrieval of the stored object
- execution proof such as JSP output or command execution

## Integration with this skill suite

Use this as a specialist step, not a top-level router.

- Start black-box Web/SRC runs with `security-test-dispatcher`, `blackbox-pentest-runner`, or `browser-pentest-orchestrator`.
- Use this skill when Java low-byte view divergence becomes a hypothesis.
- Pair with `single-variable-replay-harness` for controlled request mutation.
- Pair with `waf-bypass-techniques` only after a real backend sink exists.
- Pair with `upload-insecure-files`, `path-traversal-lfi`, `crlf-injection`, `request-smuggling`, `deserialization-insecure`, `sqli-sql-injection`, or `cmdi-command-injection` according to the low-byte semantics being tested.
- Store confirmed evidence through `logic-evidence-pack`, `results-storage`, or the active pentest runner.

See `references/skill-integration.md` for daily-use prompt patterns and `references/payload-profiles.md` for default payload lanes.

## Guardrails for quality

- Treat non-ASCII presence as a signal, not proof.
- Treat HTTP 500 as a triage lead, not impact.
- Do not mutate multiple fields in one proof request.
- Do not claim exploitability if only the WAF/log view changed and the backend semantic result did not.
- Prefer fixed seeds and saved mapping tables so another tester can replay the exact same characters.
