---
name: idor-broken-object-authorization
description: "IDOR and object-level authorization playbook. Use when URLs, JSON bodies, headers, cookies, or GraphQL arguments contain object identifiers and you need to test cross-user or cross-tenant read/write access, nested object authorization, or direct object reference flaws."
role: specialist
domain: auth-api
---

# IDOR Broken Object Authorization

Use this as the focused object-authorization playbook. Prefer [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md) when many API endpoints must be mapped first.

## When to Use

- Object IDs appear in path, query, body, header, cookie, multipart fields, or GraphQL variables.
- List/detail/update/delete/export/share/download actions depend on object keys.
- You suspect cross-user, cross-tenant, nested-object, or child-resource authorization failure.

## Core Loop

1. Build A/B account or tenant fixtures when possible.
2. Capture account A's normal baseline.
3. Change exactly one object key at a time.
4. Repeat for alternate methods, bulk APIs, export APIs, history/version APIs, and async job APIs.
5. Prove read before write; self-object before peer-object; cross-tenant last.

## Output Evidence

Record baseline object, target object, exact field changed, sensitive fields or state change, account/tenant context, and browserless replay result.
