---
name: capture-bootstrap-check
description: "Verify that Burp/browser traffic capture is ready before black-box testing. Use when Burp history is empty, browser traffic is not appearing, intercept may block automation, proxy listener or filters may be wrong, HTTPS capture may fail, or a run needs a preflight capture readiness check."
role: specialist
domain: recon-traffic-mcp
---

# Capture Bootstrap Check

Run this before traffic-driven analysis when Burp is the capture source.

## Burp MCP Preflight

1. Call `output_project_options`.
2. Confirm a running loopback listener, usually `127.0.0.1:8080`.
3. Confirm whether Proxy Intercept is on. Turn it off with `set_proxy_intercept_state(false)` when autonomous browsing or scripted replay would otherwise hang.
4. Check display filters: do not assume history is empty until filters are considered.
5. Call `get_proxy_http_history` with a small count.
6. If HTTP history is empty, generate one browser request through the Burp proxy, then query history again.
7. If HTTPS traffic fails, check browser trust of the Burp CA outside the skill before continuing.

## Readiness Output

Report these fields:

- `listener`: host, port, running
- `intercept`: on/off and whether it was changed
- `history`: item count or empty
- `filters`: anything likely to hide target traffic
- `next_action`: capture traffic, map workflow, fix proxy, fix certificate, or proceed

## Optional Local Script

If `output_project_options` output is saved to a JSON/text file, run:

```bash
python scripts/check_project_options.py --input burp_options.json
```

Use the script result as a local sanity check; live MCP observations override saved files.

## Pivots

- Burp tool routing: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Convert captured history: [burp-history-to-workflow](../burp-history-to-workflow/SKILL.md)
- Browser-heavy capture: [browser-pentest-orchestrator](../browser-pentest-orchestrator/SKILL.md)
