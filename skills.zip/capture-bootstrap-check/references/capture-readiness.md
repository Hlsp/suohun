# Capture Readiness Checklist

## Ready

- Burp listener is running.
- Browser or client routes traffic through Burp.
- Intercept is off unless manual interception is intended.
- Proxy history receives at least one request from the target.
- Filters do not hide the target traffic.
- HTTPS requests appear without certificate errors.

## Common blockers

- Browser proxy disabled or using a different profile.
- Intercept left on, causing requests to hang.
- Burp display filter hides static or out-of-scope traffic.
- Target uses a native client or certificate pinning.
- HTTP/2 or WebSocket traffic is present but only HTTP history is checked.
