#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path


def load_jsonish(path):
    text = Path(path).read_text(encoding='utf-8-sig', errors='replace')
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r'\{.*\}', text, re.S)
        if not m:
            raise SystemExit('No JSON object found in input')
        return json.loads(m.group(0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    args = ap.parse_args()
    data = load_jsonish(args.input)
    proxy = data.get('proxy', {})
    listeners = proxy.get('request_listeners', [])
    active = [x for x in listeners if x.get('running')]
    intercept = proxy.get('intercept_client_requests', {}).get('do_intercept')
    hist_filter = proxy.get('http_history_display_filter', {})
    target_scope = data.get('target', {}).get('scope', {})
    result = {
        'listeners_running': [{'port': x.get('listener_port'), 'listen_mode': x.get('listen_mode'), 'http2': x.get('enable_http2')} for x in active],
        'intercept_client_requests': intercept,
        'history_filter_disabled': hist_filter.get('filter_disabled'),
        'target_scope_include_count': len(target_scope.get('include', []) or []),
        'target_scope_exclude_count': len(target_scope.get('exclude', []) or []),
        'ready_hint': bool(active) and intercept is False,
        'next_action': 'capture target traffic through Burp' if active else 'start or fix Burp proxy listener'
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
