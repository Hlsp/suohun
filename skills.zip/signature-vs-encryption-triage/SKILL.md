---
name: signature-vs-encryption-triage
description: Quickly classify protected frontend fields as encoding, signature, MAC, symmetric encryption, asymmetric wrapping, or hybrid protection before deeper reverse engineering. Use when the main question is whether a field such as `sign`, `data`, `key`, `result`, `ciphertext`, or `payload` is reversible and what analysis path to take next.
role: bridge
domain: browser-frontend-reverse
---

# Signature Vs Encryption Triage

Use this skill when the first blocker is classification rather than extraction. Its job is to stop wasted effort on non-reversible fields and point the task toward the right next skill.

## Fast Checks

1. Capture at least two protected request or response samples from the same action.
2. Mark which plaintext inputs changed between samples.
3. Compare field length, alphabet, stability, and placement.
4. Search code for nearby wrapper names before touching low-level primitives.

## Classification Ladder

Apply these checks in order:

1. Encoding only
   - Base64, URL encoding, JSON stringify, protobuf, gzip, and compression are not encryption.
2. Signature or MAC
   - Fixed-length hex or Base64 digests, sorted-param concatenation, and fields named `sign`, `signature`, `digest`, or `tokenSign` are strong signature candidates.
3. Symmetric encryption
   - Large opaque fields with observable client-side key or IV sources, `CryptoJS.AES`, `SM4`, `DES`, `TripleDES`, or `subtle.encrypt`.
4. Asymmetric wrapping
   - Shorter encrypted blobs around keys or passwords, `JSEncrypt`, `RSA`, `SM2`, `setPublicKey`, or wrapped `key` fields.
5. Hybrid protection
   - Business payload encrypted symmetrically, then a key, nonce, or signature added by an interceptor.

## Evidence Rules

- Do not call a field decryptable unless you can point to a client-side decrypt path, a key source, or a reproducible wrapper.
- Do not call a field a signature only because it is short; check code and controlled input changes.
- Prefer live runtime evidence over ciphertext-length heuristics.
- If the classification is still uncertain, say that explicitly and list the competing hypotheses.

## Good Tool Patterns

- `list_network_requests` and `get_network_request` for paired samples
- `get_request_initiator` for wrapper location
- `search_in_sources` for `sign`, `encrypt`, `decrypt`, `nonce`, `timestamp`, `appId`, `publicKey`
- `get_storage` and `evaluate_script` for key or nonce sources

## Handoff Rules

- If the field is a real crypto wrapper or layered request flow, continue with `complex-js-reverse`
- If the main value is secret inventory or config leakage, use `extract-frontend-sensitive-info`
- If the original browser function must be reused offline, switch to `env-patch`
- If the user wants a formal authorized assessment report, combine with `mcp-frontend-security-audit`

## Output

Return a short triage note with:

- observed field candidates
- most likely protection type
- strongest evidence
- unresolved ambiguity
- recommended next skill
