---
name: performing-web-application-penetration-test
description: "Legacy OWASP-style web application penetration-test methodology router. Use when the user explicitly asks for formal web pentest methodology or gray-box coordination; for Zhang's normal target-driven Web/SRC/CTF work, prefer zhang-web-src-default-runner -> blackbox-pentest-runner."
role: playbook
domain: general-security
---

# Performing Web Application Penetration Test

Use this as a lightweight legacy methodology router for formal end-to-end authorized web testing. For Zhang's normal target-driven Web/SRC/CTF workflow, prefer `zhang-web-src-default-runner` first, then focused skills for actual testing.

## Workflow

1. Confirm scope, accounts, roles, rate limits, and cleanup expectations.
2. Map app surfaces: browser routes, APIs, WebSockets, files, admin, SSO, integrations, workers.
3. Build account/tenant/object matrix.
4. Prioritize high-impact workflows over generic scanning.
5. Route each candidate to a specialized skill.
6. Package findings with reproducible evidence.

## Route Map

- Recon: [recon-and-methodology](../recon-and-methodology/SKILL.md)
- Browser/frontend: [browser-pentest-orchestrator](../browser-pentest-orchestrator/SKILL.md)
- API: [api-fuzzing-bug-bounty](../api-fuzzing-bug-bounty/SKILL.md)
- Auth/session: [authbypass-authentication-flaws](../authbypass-authentication-flaws/SKILL.md)
- BOLA/IDOR: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- File/upload/download: [file-access-vuln](../file-access-vuln/SKILL.md)
- Injection: [injection-checking](../injection-checking/SKILL.md)
- Reporting: [pentest-report](../pentest-report/SKILL.md)

## Evidence Standard

For each finding, capture scope, account role, baseline, mutated request, state/data impact, reproducibility, cleanup, and recommended fix.

## Local Assets

- `scripts/agent.py` for bundled tool wrapper.
- `references/api-reference.md` for generated tool notes.
