---
name: ast-deobfuscate
description: "Babel AST JavaScript deobfuscation workflow. Use when code contains _0x variables, string arrays, control-flow flattening, dead code, anti-debugging, sojson/obfuscator patterns, or the user asks to restore obfuscated JS."
role: specialist
domain: browser-frontend-reverse
---

# AST Deobfuscate

Use this skill to recover readable JavaScript through small, reversible Babel AST transforms.

## Core Model

Deobfuscation is an incremental transform chain:

1. Preserve the original file unchanged.
2. Identify obfuscation families and runtime dependencies.
3. Apply one AST transform at a time.
4. Save intermediate artifacts after every step.
5. Validate behavior with small runtime probes.

## Workspace Layout

```text
source/original/       original files, read-only
scripts/               one-off Babel transform scripts
intermediate/          step outputs for rollback
deobfuscated/          final readable output
notes/                 transform log and validation cases
```

## Standard Workflow

1. Format and baseline the original file.
2. Scan for string arrays, decoder calls, rotation IIFEs, proxy functions, flattened switches, dead branches, anti-debug code, and dynamic eval.
3. Build a plan of only the transforms needed for this sample.
4. Implement each transform as a separate script.
5. Compare AST/output before and after each step.
6. Validate decoded functions or request-signing logic with known inputs.

## Tooling

Use Babel packages when available:

```bash
npm install @babel/parser @babel/traverse @babel/generator @babel/types prettier
```

Use browser or JS reverse MCP only for targeted runtime inspection; use local Node scripts for bulk transforms.

## Detailed Manual

Load `references/ast-deobfuscation-manual.md` only when you need the full technique catalog and examples.

## Pivots

- Complex frontend reverse: [complex-js-reverse](../complex-js-reverse/SKILL.md)
- Browser crypto entrypoint: [find-crypto-entry](../find-crypto-entry/SKILL.md)
- Environment patching: [env-patch](../env-patch/SKILL.md)
- General obfuscation triage: [code-obfuscation-deobfuscation](../code-obfuscation-deobfuscation/SKILL.md)
