---
name: saml-sso-assertion-attacks
description: "SAML SSO assertion testing playbook. Use when reviewing SAML login, XML signatures, assertions, ACS endpoints, audience, recipient, issuer, NameID, attributes, replay, and account binding."
role: specialist
domain: auth-api
---

# SAML SSO Assertion Attacks

Use this skill when authentication relies on SAML assertions between an Identity Provider and Service Provider.

## Core Model

SAML bugs are XML trust and account-binding failures:

1. IdP issues a signed assertion or response.
2. Browser posts it to the SP ACS endpoint.
3. SP validates signature, issuer, audience, recipient, time, and replay state.
4. SP maps NameID and attributes to a local account, tenant, role, or session.

Impact usually comes from skipped validation or wrong local account binding.

## Recon Questions

- Is the response signed, assertion signed, both signed, or neither?
- Does the SP validate issuer, audience, recipient, destination, ACS URL, and time window?
- Are assertions single-use and replay-protected?
- How are NameID, email, groups, tenant, and roles mapped locally?
- Are multiple IdPs, tenants, or environments accepted by the same ACS endpoint?
- Is XML parsing hardened against wrapping and XXE-style parser behavior?

## Test Families

- unsigned or partially signed response handling
- XML signature wrapping and duplicate assertion confusion
- audience, recipient, destination, and issuer mismatch
- assertion replay and stale assertion acceptance
- NameID/email/account linking confusion
- role/group attribute overtrust
- ACS/open redirect or relay-state abuse

## Validation Ladder

1. Capture a full valid SAML flow with a self-owned account.
2. Decode and label response, assertion, signature, and attributes.
3. Mutate one validation field at a time.
4. Confirm final local account, tenant, role, and session.
5. Test replay and account-linking only with controlled accounts.
6. Revoke sessions and clean linked identities.

## Evidence Standard

Capture baseline SAML response summary, mutated field, ACS response, final session/account state, and cleanup.

## Pivots

- XML parser issues: [xxe-xml-external-entity](../xxe-xml-external-entity/SKILL.md)
- OAuth/OIDC sibling flows: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- Account binding: [account-binding-invite-delegation-abuse](../account-binding-invite-delegation-abuse/SKILL.md)
