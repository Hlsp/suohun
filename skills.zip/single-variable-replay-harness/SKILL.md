---
name: single-variable-replay-harness
description: "Single-variable request mutation and replay harness. Use with a baseline HTTP request to change exactly one query, path, header, JSON, or form variable, generate a mutated request, optionally replay it in authorized scope, compare responses, and save evidence."
role: harness
domain: business-logic
---

# Single Variable Replay Harness

Use after a workflow and variable are selected. Default mode is offline mutation; active replay is optional.

This skill is the default bridge from "methodology" to "proof". If a target has a baseline request and a candidate variable, prefer this harness over further checklist discussion.

## Workflow
1. Save the baseline raw HTTP request.
2. Choose one variable from `hypothesis_queue.json`.
3. Run `scripts/single_variable_replay.py` to generate `mutated_request.txt`.
4. Replay with Yak MCP `http_fuzzer` or script `--send --yes-send` mode.
5. Compare HTTP, business fields, and server-side state/data, not just HTTP status.
6. Append the result to the active run directory's `05_mutation_log.md` and promote only proven impact to `06_evidence_log.md`.

## Required Inputs

- baseline raw request or browser action
- exact variable location: path, query, header, cookie, JSON, form, multipart part, GraphQL field, or request order
- old value and new value
- expected security boundary: object, tenant, role, property, state, token, amount, file key, or parser boundary
- verification method: re-read state, compare response field, observe file/token/session, or check owner account

## Guardrails
- Change exactly one variable per run.
- Preserve baseline and mutated raw requests.
- Send active requests only inside authorized scope.
- Normalize volatile fields before claiming a diff: timestamp, nonce, traceId, rotating CSRF, request id, pagination noise.
- Do not treat generic `500`, WAF block, or wording-only changes as findings without backend semantic impact.

## Output Record

Each replay should produce this compact record:

```text
BASELINE_FILE:
VARIABLE:
OLD_VALUE:
NEW_VALUE:
MUTATED_FILE:
REPLAY_METHOD:
HTTP_DIFF:
BUSINESS_FIELD_DIFF:
STATE_OR_DATA_PROOF:
CLEANUP:
DECISION:
```

## Common High-Value Variables

- object: `id`, `userId`, `uid`, `ownerId`, `fileId`, `orderId`, `taskId`, `entry`
- tenant/org: `tenantId`, `orgId`, `deptId`, supplier/customer id
- property: `role`, `isAdmin`, `status`, `auditStatus`, `price`, `quota`, `plan`
- token/link: reset, invite, share, export, callback, coupon, session
- money/quota: amount, price, qty, discount, balance, points
- parser: method, content-type, duplicate key, path suffix, encoded slash/dot, Java Ghost Bits variant

## Pivots
- Traffic mapping: [traffic-to-workflow-mapper](../traffic-to-workflow-mapper/SKILL.md)
- Account fixtures: [account-fixture-manager](../account-fixture-manager/SKILL.md)
- Runner: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- State diff: [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md)
- Evidence pack: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
