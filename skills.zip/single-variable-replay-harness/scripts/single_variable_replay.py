#!/usr/bin/env python3
import argparse,json,re,http.client,ssl
from pathlib import Path
from urllib.parse import urlparse,parse_qsl,urlencode,urlunparse
R=re.compile(r'^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(\S+)\s+HTTP/(\S+)$',re.I)
def parse(path):
    t=Path(path).read_text(encoding='utf-8-sig',errors='replace').lstrip('\ufeff\n\r ').replace('\r\n','\n'); h,_,b=t.partition('\n\n'); lines=h.split('\n'); m=R.match(lines[0].strip())
    if not m: raise SystemExit('bad raw request')
    hs=[]
    for line in lines[1:]:
        if ':' in line: k,v=line.split(':',1); hs.append((k.strip(),v.strip()))
    return {'method':m.group(1).upper(),'target':m.group(2),'version':m.group(3),'headers':hs,'body':b}
def mut(req,loc,name,val):
    if loc=='query':
        u=urlparse(req['target']); ps=parse_qsl(u.query,keep_blank_values=True); hit=False; new=[]
        for k,v in ps:
            if k==name: v=val; hit=True
            new.append((k,v))
        if not hit: new.append((name,val))
        req['target']=urlunparse((u.scheme,u.netloc,u.path,u.params,urlencode(new,doseq=True),u.fragment))
    elif loc=='header':
        hit=False; new=[]
        for k,v in req['headers']:
            if k.lower()==name.lower(): v=val; hit=True
            new.append((k,v))
        if not hit: new.append((name,val))
        req['headers']=new
    elif loc=='json':
        obj=json.loads(req['body'] or '{}'); cur=obj; parts=name.split('.')
        for x in parts[:-1]: cur=cur[re.sub(r'\[\d+\]','',x)]
        last=re.sub(r'\[\d+\]','',parts[-1]); cur[last]=json.loads(val) if val in ('true','false','null') or val[:1] in '[{"' or re.fullmatch(r'-?\d+(\.\d+)?',val) else val; req['body']=json.dumps(obj,ensure_ascii=False,separators=(',',':'))
    elif loc=='body':
        ps=parse_qsl(req['body'],keep_blank_values=True); hit=False; new=[]
        for k,v in ps:
            if k==name: v=val; hit=True
            new.append((k,v))
        if not hit: new.append((name,val))
        req['body']=urlencode(new,doseq=True)
    elif loc=='path':
        idx=int(re.search(r'\[(\d+)\]',name).group(1)) if '[' in name else int(name); u=urlparse(req['target']); seg=u.path.split('/'); seg[idx]=val; req['target']=urlunparse((u.scheme,u.netloc,'/'.join(seg),u.params,u.query,u.fragment))
    return req
def raw(req):
    body=req.get('body',''); hs=[]; seen=False
    for k,v in req['headers']:
        if k.lower()=='content-length': v=str(len(body.encode())); seen=True
        hs.append((k,v))
    if body and not seen: hs.append(('Content-Length',str(len(body.encode()))))
    return f"{req['method']} {req['target']} HTTP/{req['version']}\r\n"+'\r\n'.join(f'{k}: {v}' for k,v in hs)+'\r\n\r\n'+body
def send(req,base,timeout):
    h={k.lower():v for k,v in req['headers']}; u=urlparse(req['target'] if req['target'].startswith('http') else base); scheme=u.scheme or urlparse(base).scheme; host=u.netloc or h.get('host') or urlparse(base).netloc; path=req['target'] if not req['target'].startswith('http') else urlunparse(('', '', u.path or '/', u.params, u.query, u.fragment))
    C=http.client.HTTPSConnection if scheme=='https' else http.client.HTTPConnection; c=C(host,timeout=timeout,context=ssl._create_unverified_context()) if scheme=='https' else C(host,timeout=timeout)
    c.request(req['method'],path,body=req.get('body',''),headers={k:v for k,v in req['headers'] if k.lower() not in ('host','content-length')}); r=c.getresponse(); data=r.read().decode('utf-8','replace'); return {'status':r.status,'reason':r.reason,'headers':dict(r.getheaders()),'body':data}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--request',required=True); ap.add_argument('--location',required=True,choices=['query','header','json','body','path']); ap.add_argument('--name',required=True); ap.add_argument('--value',required=True); ap.add_argument('--out',required=True); ap.add_argument('--send',action='store_true'); ap.add_argument('--yes-send',action='store_true'); ap.add_argument('--base-url',default='http://127.0.0.1'); ap.add_argument('--timeout',type=int,default=10); a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    req=mut(parse(a.request),a.location,a.name,a.value); (out/'mutated_request.txt').write_text(raw(req),encoding='utf-8')
    meta={'baseline':a.request,'location':a.location,'name':a.name,'value':a.value,'mutated_request':str(out/'mutated_request.txt')}
    if a.send:
        if not a.yes_send: raise SystemExit('--send requires --yes-send')
        resp=send(req,a.base_url,a.timeout); (out/'response_body.txt').write_text(resp.pop('body'),encoding='utf-8'); meta['response']=resp; meta['response_body']=str(out/'response_body.txt')
    (out/'evidence_meta.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(meta,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
