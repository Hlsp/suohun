---
name: performing-graphql-depth-limit-attack
description: "Focused GraphQL depth and complexity validation skill. Use when safely checking depth limits, alias batching, recursion, query cost, and resolver amplification controls in authorized assessments."
role: specialist
domain: auth-api
---

# Performing GraphQL Depth Limit Attack

Use this focused skill to validate GraphQL depth, complexity, alias, and batching controls without stressing the target unnecessarily.

## Core Model

GraphQL complexity issues happen when the client can make the server perform disproportionate resolver work:

1. Query shape controls depth, breadth, aliases, fragments, batching, or pagination.
2. Server lacks effective depth, cost, rate, timeout, or resolver-level limits.
3. Work multiplies across nested relations or expensive resolvers.
4. Impact is shown by bounded latency/resource change or bypass of documented limits.

## Safe Validation Ladder

1. Start from a normal UI query.
2. Increase one dimension at a time: depth, aliases, fields, fragments, batch count, page size.
3. Keep request volume low and use small bounded increments.
4. Record latency, status, error messages, and server limit responses.
5. Stop when a clear missing-limit signal appears; do not push to outage.
6. Package the minimal query that demonstrates the control gap.

## Test Families

- nested relation depth
- alias duplication of expensive fields
- fragment recursion or repeated fragments
- batched operations in one request
- pagination limit bypass
- introspection query size and depth
- subscription or WebSocket amplification, if applicable

## Local Assets

- `scripts/agent.py` for bundled tool wrapper.
- `references/api-reference.md` for generated tool notes.

## Evidence Standard

Capture baseline query, mutated query dimension, request count, latency/error matrix, documented or expected limit, minimal proof query, and cleanup/no-impact note.

## Pivots

- Full GraphQL assessment: [performing-graphql-security-assessment](../performing-graphql-security-assessment/SKILL.md)
- Introspection: [performing-graphql-introspection-attack](../performing-graphql-introspection-attack/SKILL.md)
- API rate/logic: [api-fuzzing-bug-bounty](../api-fuzzing-bug-bounty/SKILL.md)
