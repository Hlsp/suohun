---
name: graphql-and-hidden-parameters
description: "GraphQL and hidden parameter testing playbook. Use when APIs expose GraphQL schemas, variables, persisted queries, undocumented fields, over-posting, mass assignment, or hidden business parameters."
role: specialist
domain: auth-api
---

# GraphQL and Hidden Parameters

Use this skill when API behavior depends on fields or variables not visible in the normal UI.

## Core Model

Hidden-parameter bugs happen when the server trusts client-supplied structure more than the UI reveals:

1. Frontend sends a subset of available fields or variables.
2. Server resolver, DTO, ORM, or workflow accepts additional fields.
3. Hidden input changes ownership, role, price, state, tenant, scope, or returned fields.
4. Impact is confirmed through server-side state or data exposure.

## Recon Questions

- Is there a schema, introspection, persisted-query map, frontend operation name, or mobile config?
- Which variables identify user, tenant, object, role, price, plan, status, or workflow step?
- Are unknown fields rejected, ignored, stored, or interpreted?
- Can the same operation be replayed with additional variables or nested input fields?
- Do resolvers enforce object-level authorization per field and node?

## Test Families

### Schema and Operation Discovery

Use introspection when available. Otherwise mine frontend bundles, persisted query hashes, error messages, and operation names.

### Variable Expansion

Add likely fields to input objects: role, status, tenant, owner, price, quota, plan, verified, admin, deleted, public, hidden.

### Field-Level Data Exposure

Request additional fields and nested relations. Confirm whether resolver authorization differs from UI visibility.

### ID and Node Swapping

Swap IDs across accounts, tenants, and roles at root query, nested object, and mutation levels.

### Persisted Query Abuse

Check whether query hashes, operation names, and variables are bound together. Reuse or swap hashes only with self-owned accounts.

## Validation Ladder

1. Capture one baseline operation and variables.
2. Map schema or infer fields from errors/frontend assets.
3. Add or swap one field at a time.
4. Confirm actual resolver output or state mutation.
5. Repeat across account and tenant boundaries.
6. Remove changed test data.

## Single-Variable GraphQL Rules

- Change only one of these per replay: operation name, one variable value, one added input field, one requested response field, one node ID, or one persisted-query hash.
- Separate GraphQL BOLA, BOPLA, and BFLA:
  - BOLA: node/id/tenant swap.
  - BOPLA: added input field such as `role`, `ownerId`, `status`, `price`, `quota`, or `plan`.
  - BFLA: mutation/function that the role should not call.
- Re-read state after mutations; do not rely on GraphQL `errors` shape alone.
- Save baseline variables and mutated variables as separate artifacts.

## Evidence Standard

Capture operation, variables, mutation, response diff, authorization context, final data/state proof, and cleanup.

## Pivots

- GraphQL assessment: [performing-graphql-security-assessment](../performing-graphql-security-assessment/SKILL.md)
- Introspection: [performing-graphql-introspection-attack](../performing-graphql-introspection-attack/SKILL.md)
- BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- API fuzzing: [api-fuzzing-bug-bounty](../api-fuzzing-bug-bounty/SKILL.md)
