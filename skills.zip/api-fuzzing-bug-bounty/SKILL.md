---
name: api-fuzzing-bug-bounty
description: "API fuzzing and bug bounty playbook. Use when testing REST, GraphQL, SOAP, mobile, or undocumented APIs for auth, authorization, hidden parameters, validation, injection, mass assignment, and business logic flaws."
role: playbook
domain: auth-api
metadata:
  risk: offensive
  source: refined-local
---

# API Fuzzing for Bug Bounty

Use this skill to drive efficient black-box API testing after scope, accounts, and rate limits are understood.

## Core Model

API bugs are usually boundary mismatches:

1. Documentation or frontend reveals intended objects, roles, and parameters.
2. Client requests contain identifiers, claims, hidden flags, filters, and state transitions.
3. Server validation is incomplete across auth, object ownership, tenant, schema, and workflow state.
4. Impact appears as data exposure, unauthorized action, state corruption, or business logic abuse.

Prioritize authenticated, state-changing, and object-addressing APIs over blind wordlist fuzzing.

## Recon Questions

- What API styles exist: REST, GraphQL, SOAP, JSON-RPC, gRPC-web, mobile, WebSocket?
- Where are schemas or docs exposed: OpenAPI, Swagger, GraphQL, frontend bundles, mobile configs?
- Which endpoints carry object IDs, tenant IDs, user IDs, role flags, prices, quotas, or workflow states?
- What auth modes are used: cookie, bearer, API key, JWT, OAuth, mTLS, device ID?
- Which endpoints are state-changing and which are read-only?
- Are errors detailed enough to reveal validation or hidden parameters?

## Test Families

### Endpoint and Schema Discovery

Collect docs, frontend routes, mobile endpoints, OPTIONS responses, error messages, and historical versions. Build a small candidate list before fuzzing.

### Auth and Session Boundaries

Remove, swap, replay, downgrade, and expire credentials. Confirm which endpoints are unauthenticated, partially authenticated, or token-claim driven.

### Authorization and Object Access

Swap object IDs across two self-owned accounts and tenants. Focus on BOLA, BFLA, tenant mixing, role changes, and indirect object references.

### Parameter and Schema Mutation

Test hidden parameters, type changes, arrays vs scalars, mass assignment, over-posting, enum expansion, nulls, negative values, and duplicate keys.

### Workflow and Business Logic

Replay, reorder, skip, race, or partially complete multi-step flows. Track server state before and after each mutation.

### Injection and Parser Boundaries

Only after input reaches a parser, pivot to SQLi, NoSQL, command injection, XXE, SSRF, SSTI, or prototype pollution skills.

## Validation Ladder

1. Build endpoint inventory from live traffic and docs.
2. Create an auth matrix with anonymous, user A, user B, low-privileged, and admin-like test accounts where available.
3. Prioritize endpoints by impact: identity, money, tenant, export, admin, secrets, workflow.
4. Mutate one dimension at a time: auth, object, tenant, role, parameter, state, method.
5. Confirm actual data/state impact, not just response differences.
6. Save replayable requests and cleanup changed state.

## Evidence Standard

Capture endpoint, account roles, baseline request, mutation, response diff, authoritative state/data proof, and cleanup action.

## Pivots

- API recon/docs: [api-recon-and-docs](../api-recon-and-docs/SKILL.md)
- API auth/JWT: [api-auth-and-jwt-abuse](../api-auth-and-jwt-abuse/SKILL.md)
- BOLA/authorization: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- GraphQL/hidden params: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
