---
name: dependency-confusion
description: "Dependency confusion and package namespace trust testing. Use when internal package names appear in npm, pip, Maven, NuGet, Gem, Composer, or CI/CD build flows and you need to assess whether private dependencies could be resolved from public registries."
role: specialist
domain: general-security
---

# Dependency Confusion

Check internal package names, registry precedence, namespace/scope pinning, and version override rules. Prefer safe proof that public resolution can participate over publishing or executing risky packages. Related: [insecure-source-code-management](../insecure-source-code-management/SKILL.md), [extract-frontend-sensitive-info](../extract-frontend-sensitive-info/SKILL.md).
