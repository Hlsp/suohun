---
name: secknowledge-skill
description: "Reference lookup router for bundled Web/AI security knowledge. Use only after a live target, codebase, API, traffic sample, MCP/agent/RAG system, or confirmed hypothesis needs scenario-specific references; do not use as a first-entry router."
role: knowledge-vault
domain: recon-traffic-mcp
---

# SecKnowledge Skill

Use this skill as a reference lookup router, not as a first-entry workflow and not as a replacement for live evidence. It is useful only after a live/source-driven Web or AI-security task needs methodology, risk taxonomy, or payload/reference lookup from the bundled `references/` files.

## Trigger Conditions

Use only when all are true:

1. The task intent is security assessment, audit, exploitation in a CTF/sandbox, or vulnerability validation.
2. A concrete target, codebase, API, model, agent, MCP server, RAG system, or traffic sample exists.
3. The question benefits from the bundled Web/AI references rather than normal reasoning alone.

Do not trigger for concept Q&A, ordinary code/debug work, deep source-sink code audit better handled by another workflow, or fresh CVE/doc lookup that needs current sources.

## Reference Navigation

| Scene | Reference |
|---|---|
| SQLi, XSS, command injection, XXE, deserialization | `references/web-injection.md` |
| Authorization, account, payment, reset, business logic | `references/web-logic-auth.md` |
| Upload, traversal, SSRF, information disclosure | `references/web-file-infra.md` |
| CORS, GraphQL, HTTP smuggling, WebSocket, OAuth | `references/web-modern-protocols.md` |
| Supply chain, deployment, cloud, CI/CD, framework clues | `references/web-deployment-security.md` |
| Prompt injection, MCP, agent, AI app risks | `references/ai-app-security.md` |
| Model, jailbreak, adversarial, model-theft risks | `references/ai-model-security.md` |
| RAG/data leakage, data poisoning, exfiltration | `references/ai-data-security.md` |
| Identity, permission, role, session, agent impersonation | `references/ai-identity-security.md` |
| Infra, sandbox, container, supply-chain risks | `references/ai-baseline-security.md` |
| GAARM risk lookup | `references/gaarm-risk-matrix.md` |
| Methodology and OWASP mappings | `references/testing-methodology.md` |
| Payload lookup | `references/payloads.md` |

## Operating Rules

- Start from live runtime behavior, captured traffic, or source evidence; use references to enrich hypotheses.
- Mark the difference between hypothesis and confirmed finding.
- Do not invent CVE IDs, GAARM IDs, OWASP mappings, or payload provenance.
- Keep outputs short: scenario, selected references, 3-5 hypotheses, and next decisive validation step.

## Output Shape

```text
SCENE:
REFERENCES_TO_LOAD:
HYPOTHESES:
NEXT_DECISIVE_TEST:
EVIDENCE_NEEDED:
```
