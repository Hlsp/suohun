import argparse
import json
import os
import re
from typing import Dict, List


DEFAULT_ROOTS = [
    r"Z:\pocs\pocs-custom-13171",
    r"Z:\pocs\pocs-custom-60265",
]


FAMILY_PATTERNS: Dict[str, List[str]] = {
    "fastjson": [r"fastjson", r"@type", r"basicdatasource"],
    "shiro": [r"shiro", r"rememberme", r"default-key", r"\bcbc\b", r"\bgcm\b"],
    "struts": [r"struts", r"\bs2[-_ ]?\d+", r"ognl", r"\.action"],
    "spring": [r"springboot", r"spring framework", r"spring cloud", r"spring security", r"spring-"],
    "druid": [r"\bdruid\b", r"statview", r"monitor"],
    "nacos": [r"\bnacos\b"],
    "geoserver": [r"geoserver", r"geotools"],
    "solr": [r"\bsolr\b"],
    "jolokia": [r"jolokia"],
    "swagger": [r"swagger", r"knife4j", r"doc\.html"],
    "h2": [r"h2console", r"h2-console"],
    "log4j": [r"log4j"],
    "jackson": [r"jackson"],
    "xxl-job": [r"xxl-job"],
}


def load_names(roots: List[str]) -> List[str]:
    names = []
    seen = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        for name in os.listdir(root):
            if not name.lower().endswith(".yaml"):
                continue
            if name in seen:
                continue
            seen.add(name)
            names.append(name)
    return sorted(names)


def main() -> None:
    parser = argparse.ArgumentParser(description="Find Java component PoCs in Z:\\pocs")
    parser.add_argument("--family", help="component family keyword such as fastjson, shiro, struts, spring, druid")
    parser.add_argument("--query", help="free text regex/substring query against filenames")
    parser.add_argument("--limit", type=int, default=30)
    parser.add_argument("--json", action="store_true", help="emit JSON")
    args = parser.parse_args()

    names = load_names(DEFAULT_ROOTS)
    results = names

    if args.family:
        family = args.family.lower()
        pats = FAMILY_PATTERNS.get(family, [re.escape(args.family)])
        cre = [re.compile(p, re.I) for p in pats]
        results = [n for n in results if any(r.search(n) for r in cre)]

    if args.query:
        q = re.compile(args.query, re.I)
        results = [n for n in results if q.search(n)]

    results = results[: args.limit]

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for n in results:
            print(n)


if __name__ == "__main__":
    main()
