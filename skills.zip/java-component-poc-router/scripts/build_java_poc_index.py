import argparse
import csv
import json
import os
import re
from typing import Dict, List, Optional

import yaml


DEFAULT_ROOTS = [
    r"Z:\pocs\pocs-custom-13171",
    r"Z:\pocs\pocs-custom-60265",
]

FAMILY_PATTERNS: Dict[str, List[str]] = {
    "fastjson": [r"fastjson", r"@type", r"basicdatasource"],
    "shiro": [r"shiro", r"rememberme", r"default-key", r"\bcbc\b", r"\bgcm\b"],
    "struts": [r"struts", r"\bs2[-_ ]?\d+", r"ognl", r"\.action"],
    "spring": [r"springboot", r"spring framework", r"spring cloud", r"spring security", r"spring-"],
    "druid": [r"\bdruid\b", r"statview", r"monitor"],
    "nacos": [r"\bnacos\b"],
    "geoserver": [r"geoserver", r"geotools"],
    "solr": [r"\bsolr\b"],
    "jolokia": [r"jolokia"],
    "swagger": [r"swagger", r"knife4j", r"doc\.html"],
    "h2": [r"h2console", r"h2-console"],
    "log4j": [r"log4j"],
    "jackson": [r"jackson"],
    "xxl-job": [r"xxl-job"],
}


def classify_family(name: str) -> Optional[str]:
    for family, pats in FAMILY_PATTERNS.items():
        if any(re.search(p, name, re.I) for p in pats):
            return family
    return None


def classify_kind(name: str, data: dict) -> str:
    lname = name.lower()
    tags = str((data.get("info", {}) or {}).get("tags", "")).lower()
    text = f"{lname} {tags}"
    if any(x in text for x in ["default-login", "default-key", "unauth", "authentication bypass", "auth-bypass", "auth bypass", "info-disclosure", "monitor", "list"]):
        return "detect-or-verify"
    if any(x in text for x in ["rce", "remote code", "deserialization", "jndi", "ognl"]):
        return "exploit"
    if any(x in text for x in ["file read", "local file", "xxe", "ssrf", "sqli", "directory traversal"]):
        return "exploit"
    return "unknown"


def extract_http_shape(data: dict) -> Dict[str, str]:
    res = {"method": "", "path_hint": "", "has_raw": "false", "has_path": "false"}
    http = data.get("http")
    if not isinstance(http, list) or not http:
        return res
    first = http[0]
    if not isinstance(first, dict):
        return res
    if "method" in first:
        res["method"] = str(first.get("method", ""))
    if "path" in first and isinstance(first["path"], list) and first["path"]:
        res["path_hint"] = str(first["path"][0])[:120]
        res["has_path"] = "true"
    if "raw" in first and isinstance(first["raw"], list) and first["raw"]:
        raw = str(first["raw"][0])
        res["path_hint"] = raw.splitlines()[0][:120]
        res["has_raw"] = "true"
    return res


def main() -> None:
    parser = argparse.ArgumentParser(description="Build structured Java PoC index from Z:\\pocs")
    parser.add_argument("--json-out", required=True)
    parser.add_argument("--csv-out", required=True)
    args = parser.parse_args()

    entries = []
    seen = set()
    for root in DEFAULT_ROOTS:
        if not os.path.isdir(root):
            continue
        for filename in os.listdir(root):
            if not filename.lower().endswith(".yaml"):
                continue
            if filename in seen:
                continue
            seen.add(filename)
            family = classify_family(filename)
            if not family:
                continue
            full = os.path.join(root, filename)
            try:
                with open(full, "r", encoding="utf-8", errors="replace") as fh:
                    data = yaml.safe_load(fh) or {}
            except Exception:
                continue
            info = data.get("info", {}) if isinstance(data, dict) else {}
            meta = info.get("metadata", {}) if isinstance(info.get("metadata", {}), dict) else {}
            http_shape = extract_http_shape(data if isinstance(data, dict) else {})
            entry = {
                "file": filename,
                "family": family,
                "id": data.get("id", "") if isinstance(data, dict) else "",
                "name": info.get("name", ""),
                "severity": info.get("severity", ""),
                "vendor": meta.get("vendor", ""),
                "product": meta.get("product", ""),
                "tags": info.get("tags", "") or data.get("tags", "") if isinstance(data, dict) else "",
                "kind": classify_kind(filename, data if isinstance(data, dict) else {}),
                **http_shape,
            }
            entries.append(entry)

    with open(args.json_out, "w", encoding="utf-8") as fh:
        json.dump(entries, fh, ensure_ascii=False, indent=2)

    fieldnames = ["family", "kind", "file", "id", "name", "severity", "vendor", "product", "tags", "method", "path_hint", "has_raw", "has_path"]
    with open(args.csv_out, "w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in entries:
            writer.writerow({k: row.get(k, "") for k in fieldnames})

    print(f"indexed={len(entries)}")


if __name__ == "__main__":
    main()
