# Local PoC First 2026-05-02

When the issue is a framework/component challenge:

1. prove the family from runtime
2. search `Z:\pocs`
3. classify PoCs into detector / verify / exploit
4. adapt the best local PoC to live validation
5. only then consult public write-ups if local PoCs are insufficient

For Struts double-evaluation targets, treat `Apache Struts -=2.5.20-Remote Code Execution-CVE-2019-0230.yaml` as the narrow detector/verify PoC and `Apache Struts 2.0.0-2.5.25-Remote Code Execution-CVE-2020-17530.yaml` as a reusable BeanMap exploit skeleton when the live sink parameter is already known.
