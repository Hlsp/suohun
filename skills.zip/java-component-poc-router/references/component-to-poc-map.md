# Component clue -> PoC family map

## `rememberMe`

- `shiro-default-key-*`
- product-specific shiro default-key PoCs

## `@type`, `autoType is not support`, `com.alibaba.fastjson`

- `fastjson-*`
- vendor fastjson RCE chains
- product fastjson chains

## `.action`, OGNL, multipart parser

- `Apache Struts*`
- `Struts2*`
- product-specific `struts2-rce`
- title/body says `S2-059`, `double evaluation`, or `evaluated again` -> start with `Apache Struts -=2.5.20-Remote Code Execution-CVE-2019-0230.yaml`
- arithmetic OGNL proves the sink but classic static probes are constrained and `org.apache.tomcat.InstanceManager` is reachable from application scope -> adapt the BeanMap / ValueStack exploit skeleton from `Apache Struts 2.0.0-2.5.25-Remote Code Execution-CVE-2020-17530.yaml`

## `/druid/index.html`, SQL monitor clues

- `Alibaba-druid-*`
- `apache-druid-*`
- product-specific druid unauth/default-login

## `/nacos/` or `/nacos/v1/`

- `Alibaba-nacos-*`
- `nacos-*`

## `/geoserver/`, WFS/WPS/WMS/REST

- `GeoServer*`
- `geoserver-*`

## `/solr/`, `/solr/admin/`

- `Apache Solr*`
- `apache-solr-*`

## `/jolokia/`

- `jolokia-*`
- `Jolokia*`

## `/swagger-ui*`, `/doc.html`

- `swagger-ui-*`
- `swagger*`
- `knife4j*`

## Spring Boot 404 shell + mgmt roots

- `springboot-*`
- `Spring Boot Actuator*`
- `Spring Cloud*`
- `Spring-*`
