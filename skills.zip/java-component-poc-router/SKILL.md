---
name: java-component-poc-router
description: Use when a black-box or CTF Java target appears to involve a framework or middleware component and Codex should combine runtime/component fingerprinting with the local PoC corpus under `Z:\pocs` instead of blindly guessing payloads. Trigger when the user asks to use local PoCs, mentions Java 第三方组件, 中间件漏洞, fastjson, shiro, struts, spring, druid, nacos, geoserver, solr, swagger, jolokia, h2-console, or when component clues appear in routes, errors, cookies, assets, or stack traces and Codex must map them to existing YAML PoCs plus manual/MCP validation steps.
role: router
domain: java-jvm
---

# Java Component PoC Router

Use this skill when a Java target smells like a known component family and you want to route from **live runtime clue -> local PoC candidate under `Z:\pocs` -> safe validation plan**, instead of blind payload spraying or immediate public write-up hunting.

## Goal

Turn `Z:\pocs` from a huge YAML pile into a decision aid:

1. fingerprint the component
2. shortlist matching PoCs
3. separate detector PoCs from exploit PoCs
4. convert the best PoC into:
   - browser/MCP validation
   - raw HTTP replay
   - minimal manual PoC

## Default selection rule

For each plausible component family, choose candidates in this order:

1. **starter detector**
2. **behavioral verify**
3. **exploit**

Use `references/best-starter-pocs.md` first, then refine with:

- `scripts/find_component_pocs.py`
- `references/java-poc-index.generated.json`
- `references/java-poc-index.generated.csv`

## Core rule

Do not run PoCs just because a filename matches.
Do not search public write-ups first. Confirm from runtime, then search the local PoC corpus under `Z:\pocs`, and only after that use public material if local PoCs are insufficient.

First prove:

- the component family is plausible
- the endpoint family exists
- the HTTP method/content-type/route shape fit
- the vulnerability family matches the runtime behavior

## Workflow

### 1. Build the component hypothesis

Use runtime clues first:

- page titles
- error pages
- cookies
- route suffixes
- assets and static paths
- API names
- stack traces
- admin console roots

Examples:

- `rememberMe` -> Shiro
- `@type` / `autoType is not support` -> Fastjson
- `.action` / OGNL errors -> Struts
- `Whitelabel Error Page` + `/actuator` style routes -> Spring family
- `/druid/index.html` -> Druid
- `/nacos/v1/*` -> Nacos
- `/geoserver/wfs` -> GeoServer
- `/solr/admin/*` -> Solr

### 2. Search `Z:\pocs` for the component family

Prefer narrowing by:

- component name
- route family
- CVE family
- version hints
- protocol or parser clues

Use the keywords in `references/java-component-keywords.md`.

### 3. Classify each candidate PoC

Mentally tag candidates as:

- **detect-only**
  - title/header/body checks
  - default login / unauth exposure / info leak
- **behavioral verify**
  - parser proof
  - auth bypass proof
  - callback-only SSRF/JNDI
- **active exploit**
  - file read / RCE / deserialization / OGNL / write primitive

Start as far left as possible.

### 4. Translate YAML into a live plan

Extract:

- expected path
- expected method
- required headers
- required content-type
- body placement
- matcher logic
- OOB dependency

Then translate to one of:

- browser MCP `fetch(...)`
- raw HTTP request
- curl / PowerShell replay
- manual browser action plus network capture

### 5. Prove one narrow chain

Stop when one of these is true:

- component confirmed and vulnerable behavior reproduced
- component disproved by runtime mismatch
- candidate PoC shown incompatible with the target

Then either pivot deeper or move to the next best candidate.

## How to read YAML PoCs

Read these first:

- `id`
- `info.name`
- `info.description`
- `reference`
- `tags`
- `http.raw` or `http.path`
- `matchers`
- `extractors`
- token / cookie / OOB variables

## Practical interpretation patterns

### Detection PoC

Example:

- `GET /druid/index.html`
- matcher expects `Druid Stat Index</title>`

Meaning:

- presence check only
- good for first discriminator

### Default secret / default token PoC

Example:

- static rememberMe payload
- static Nacos JWT

Meaning:

- ideal for black-box auth bypass validation
- verify route family first

### OOB PoC

Example:

- `interactsh-url`
- JNDI / LDAP / RMI / callback references

Meaning:

- use only when the parser family fits
- prefer non-destructive callback first

### Error-based exploit PoC

Example:

- matcher expects stack trace or parser error
- status `400` / `500`

Meaning:

- often the best first proof for Struts / parser / deserialization families

## Component-specific routing notes

### Fastjson

- first verify JSON entrypoint and `@type`
- then shortlist `fastjson-*` plus vendor/product-specific fastjson chains
- separate:
  - old JNDI/JdbcRowSet exploit PoCs
  - restricted AutoType challenge PoCs
  - read/write challenge payloads

### Shiro

- start with rememberMe oracle/default-key PoCs
- do not jump to gadget exploit before the cookie behavior is confirmed

### Struts

- extract exact header/body OGNL placement from YAML
- if runtime already says `S2-059`, `double evaluation`, or `evaluated again`, prove the sink first with one arithmetic payload on the reflected parameter instead of spraying broader Struts families
- for reflected-attribute double evaluation, prefer a local two-step lane: `Apache Struts -=2.5.20-Remote Code Execution-CVE-2019-0230.yaml` to prove the sink, then the BeanMap / `org.apache.tomcat.InstanceManager` / `freemarker.template.utility.Execute` skeleton from the local `CVE-2020-17530` PoC when you need stable in-band command output or file reads
- prefer parser/error proof before full command payload
- use dnslog / OOB only as a fallback when in-band proof such as `whoami`, `id`, or direct flag reads is blocked

### Spring family

- many `springboot-*` PoCs are detector PoCs
- use them as an endpoint shortlist, not as magic bullets

### Tomcat default webapps and `CVE-2025-24813`

- when the live target is a default Tomcat page and `/manager/html`, `/host-manager/html`, `/docs/`, or `/examples/` return Tomcat-branded local-only `403` pages, treat that as a strong Tomcat-family discriminator and do a Tomcat-specific narrow lane before broader Java probing
- verify `DefaultServlet` write behavior with a harmless text file first:
  - `PUT /probe.txt` -> `201/204`
  - `GET /probe.txt` -> uploaded content
- verify that `Jasper` is a separate execution boundary:
  - direct `PUT /probe.jsp` may fail with a JSP-specific `404/405`
  - mixed-case `.Jsp`, `.jspx`, or `.jsp%20` paths may be stored as static text rather than executed
  - this proves writable static content without yet proving code execution
- for `CVE-2025-24813`, do not trust clients that normalize traversal:
  - prefer `curl --path-as-is`
  - test the exact raw path you intend to send
- verify `partial PUT` correctly:
  - use an explicit `Content-Range`, for example `bytes 0-3/4`
  - confirm the uploaded file length matches the partial body you intended
- a practical proof sequence is:
  1. `Apache Tomcat/9.x` title or branded error page
  2. local-only Tomcat default webapp `403` clues
  3. successful static `PUT`
  4. successful raw-path `partial PUT`
  5. attempted write into a candidate `.session` path
  6. trigger with the matching `JSESSIONID`
- high-value negative results that should change your hypothesis quickly:
  - `X-Forwarded-For` / `X-Real-IP` does not change manager/docs/examples `403`
  - `MOVE`, `COPY`, or `PROPFIND` unsupported
  - WAR upload to ROOT does not auto-deploy into a new context
  - `JSESSIONID` trigger returns the normal page with no `500`, `ObjectInputStream`, or session-load side effect
- if step 5 succeeds but step 6 does nothing, record the exact interpretation:
  - you have proven the writable + partial-PUT half of the Tomcat lane
  - you have **not** yet proven that the current app uses file-based session persistence or that the chosen route actually loads sessions
  - pivot from payload generation to finding the real session-loading app or context instead of grinding gadget variants too early

### Druid / Nacos / Solr / GeoServer / Jolokia

- many have both presence and exploit PoCs
- presence first, exploit second

## `Z:\pocs` usage notes

- the corpus is noisy and repetitive
- many entries are nuclei detection templates, not end-to-end exploit recipes
- some PoCs assume helpers (e.g. interactsh) and must be translated
- some filenames are stale; trust runtime behavior over filename confidence

## References

- PoC interpretation notes: `references/poc-usage-notes.md`
- Java family search keywords: `references/java-component-keywords.md`
- Component clue -> PoC family map: `references/component-to-poc-map.md`
- Family index from the local corpus: `references/family-index.md`
- Best starter PoCs by family: `references/best-starter-pocs.md`

## Scripts

- `scripts/find_component_pocs.py`
  - quick filename shortlist helper for `Z:\pocs`
  - examples:
    - `python scripts/find_component_pocs.py --family fastjson`
    - `python scripts/find_component_pocs.py --family struts --query "2017|ognl"`
    - `python scripts/find_component_pocs.py --query "nacos.*auth|default-token"`
- `scripts/build_java_poc_index.py`
  - builds a structured JSON/CSV index from Java-family PoCs in `Z:\pocs`
  - example:
    - `python scripts/build_java_poc_index.py --json-out references/java-poc-index.generated.json --csv-out references/java-poc-index.generated.csv`

## Practical routing contract

When this skill is active, the next answer should name:

```text
COMPONENT_FAMILY:
STARTER_DETECTOR:
BEHAVIORAL_VERIFY:
EXPLOIT_CANDIDATE:
WHY_THIS_ORDER:
TRANSLATED_FIRST_REQUEST:
```

If the answer only lists filenames, the routing is incomplete.

## Evidence standard

Capture:

- the component clue
- shortlisted PoC filenames
- why each candidate matches or mismatches
- translated request or browser/MCP validation step
- decisive response, side effect, or disproof
