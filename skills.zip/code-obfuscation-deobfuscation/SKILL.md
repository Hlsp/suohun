---
name: code-obfuscation-deobfuscation
description: "Code obfuscation analysis and deobfuscation playbook. Use when reversing obfuscated JavaScript, native binaries, bytecode, packers, string encryption, control-flow flattening, anti-analysis, or VM-like protectors."
role: specialist
domain: native-pwn-reverse
---

# Code Obfuscation and Deobfuscation

Use this skill when code is intentionally hard to read and you need to recover behavior, configuration, secrets, protocols, or exploit-relevant logic.

## Core Model

Deobfuscation is a transform recovery task:

1. Identify the protection family and execution entrypoint.
2. Recover literals, control flow, and API boundaries in the order they are used at runtime.
3. Validate recovered behavior with small inputs or traces.
4. Preserve original and derived artifacts separately.

Runtime behavior beats comments and dead code.

## Recon Questions

- What artifact type is it: JavaScript bundle, native binary, bytecode, mobile app, VM, packed script?
- Is the obstacle string encryption, control-flow flattening, anti-debug, packing, virtualization, dead code, or dynamic loading?
- What input/output behavior matters: signing, encryption, license, C2 config, routes, feature flags, exploit primitive?
- Can it run safely in a sandbox with tracing or instrumentation?
- Which decoded artifacts should be kept separate from originals?

## Workflow

1. Hash and preserve the original artifact.
2. Identify entrypoints, imports, strings, sections, modules, and dynamic loaders.
3. Unpack or emulate only the layer blocking the next question.
4. Rename symbols around observed behavior, not guesses.
5. Validate each recovered transform with a minimal script or runtime trace.
6. Document exact steps and generated artifacts.

## Technique Families

- string table recovery and decoder extraction
- AST normalization for JavaScript bundles
- control-flow flattening simplification
- dynamic tracing around decrypt/decode points
- anti-debug bypass routing
- VM handler and bytecode mapping

## Evidence Standard

Capture original hash, protection type, tools/scripts used, decoded artifacts, validation input/output, and remaining uncertainty.

## Pivots

- JavaScript AST: [ast-deobfuscate](../ast-deobfuscate/SKILL.md)
- Complex frontend reverse: [complex-js-reverse](../complex-js-reverse/SKILL.md)
- VM/bytecode: [vm-and-bytecode-reverse](../vm-and-bytecode-reverse/SKILL.md)
- Anti-debug: [anti-debugging-techniques](../anti-debugging-techniques/SKILL.md)
