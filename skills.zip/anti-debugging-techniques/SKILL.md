---
name: anti-debugging-techniques
description: "Anti-debugging techniques router. Use when browser, script, or native targets use traps, timing checks, self-defending code, console detection, or anti-instrumentation to block analysis."
role: router
domain: browser-frontend-reverse
---

# Anti Debugging Techniques

Route browser/frontend cases to [anti-debug-frontend-bypass](../anti-debug-frontend-bypass/SKILL.md). Pair obfuscation with [code-obfuscation-deobfuscation](../code-obfuscation-deobfuscation/SKILL.md). Bypass one trap at a time.
