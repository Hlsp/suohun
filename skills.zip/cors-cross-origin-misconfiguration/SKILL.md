---
name: cors-cross-origin-misconfiguration
description: "CORS misconfiguration playbook. Use when browser APIs expose authenticated data cross-origin through reflected origins, weak allowlists, credentialed requests, null origins, subdomain trust, or preflight mistakes."
role: specialist
domain: auth-api
---

# CORS Cross-Origin Misconfiguration

Use this skill when a browser from another origin may read protected API responses because the server returns overly permissive CORS headers.

## Core Model

CORS impact requires both access and readable data:

1. A cross-origin request is allowed by `Access-Control-Allow-Origin`.
2. Credentials are included when the target data requires cookies or HTTP auth.
3. The browser exposes the response to the calling origin.
4. The response contains sensitive data or enables a state-changing chain.

A permissive header without sensitive readable content is usually weak evidence.

## Recon Questions

- Which endpoints return account, tenant, token, payment, export, admin, or private data?
- Does the endpoint use cookies, bearer tokens, or anonymous access?
- Are `ACAO`, `ACAC`, `Vary: Origin`, and preflight responses consistent?
- Does the server reflect arbitrary origins or match weak suffix/prefix patterns?
- Are `null`, local files, sandboxed iframes, subdomains, or takeoverable origins trusted?
- Does CDN caching mix CORS headers between origins?

## Test Families

### Reflected Origin

Send a unique external Origin and see whether it is echoed. Then verify whether credentials are allowed and sensitive data is readable by browser JavaScript.

### Weak Allowlist

Test suffix, prefix, case, scheme, port, encoded dot, trailing dot, and subdomain parsing mistakes. Focus on domains the tester controls or can safely simulate.

### Null and Non-HTTP Origins

Check whether `Origin: null` is trusted for file, sandboxed iframe, data URL, or mobile-webview style contexts.

### Preflight and Method Confusion

Compare simple requests and preflighted requests. Some APIs block preflight but accept simple content types or method overrides.

### Cache Interaction

If `Vary: Origin` is missing, CORS headers may be cached and replayed across origins. Use cache-busters and clean sessions.

## Validation Ladder

1. Identify an endpoint with sensitive data using a self-owned account.
2. Send baseline same-origin request.
3. Send cross-origin requests with controlled Origin values.
4. Confirm `ACAO` and `ACAC` behavior.
5. Validate in a real browser harness; raw HTTP alone is not enough.
6. Prove readable sensitive data or meaningful chain.
7. Clean test accounts, tokens, and cache entries.

## Evidence Standard

Capture:

- target endpoint and data sensitivity
- request Origin and response CORS headers
- browser proof that JavaScript can read the response
- credential mode and cookie attributes
- allowlist bypass pattern, if any
- cleanup or token revocation

## Pivots

- Subdomain trust and takeover: [subdomain-takeover](../subdomain-takeover/SKILL.md)
- CSRF versus readable data: [csrf-cross-site-request-forgery](../csrf-cross-site-request-forgery/SKILL.md)
- Cache header mixing: [web-cache-deception](../web-cache-deception/SKILL.md)
- XSS on trusted origin: [xss-cross-site-scripting](../xss-cross-site-scripting/SKILL.md)
- Extra scenarios: [SCENARIOS.md](./SCENARIOS.md)
