---
name: business-logic-vuln
description: >-
role: router
domain: business-logic
  Entry P1 category router for business logic testing. Use when workflow abuse,
  race conditions, pricing flaws, or multi-step state attacks matter more than
  parser-level input injection.
---

# Business Logic Vuln

Use when rules, states, order, quota, price, tenant, actor, or object invariants matter more than parser payloads. State the invariant, capture baseline, build single-variable mutations, and route to [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md), [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md), or [logic-race-harness](../logic-race-harness/SKILL.md).
