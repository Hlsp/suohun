---
name: browser-crypto-helper-builder
description: Generate focused browser-side HTML or JavaScript helpers for encrypt, decrypt, sign, and paste-driven response decoding using observed frontend behavior. Use when the user wants a quick local helper page, reproducible browser PoC, or interactive validation harness for frontend crypto logic.
role: builder
domain: browser-frontend-reverse
---

# Browser Crypto Helper Builder

Use this skill when the user wants a practical artifact quickly: a local HTML helper, browser console helper, or small JavaScript page that validates the observed crypto flow.

## Preferred Outputs

- HTML helper for encrypt or decrypt testing
- paste-driven response decoder
- browser-side signature playground
- small JS snippet for console replay

## Build Rules

1. Match the observed serialization and encoding chain exactly.
2. Separate observed logic from inferred placeholders.
3. Keep session-bound or unknown values explicit and easy to edit.
4. Prefer browser-side CryptoJS parity when Node `crypto` semantics may drift from the site.
5. If the helper is only algorithm-equivalent and not the original code path, say so clearly.

## Workflow

1. Confirm the target artifact type: HTML page, browser snippet, or lightweight JS helper.
2. Collect the minimum proven evidence:
   - plaintext shape
   - key source
   - IV or nonce source
   - serialization order
   - final transport encoding
3. Build the smallest helper that reproduces the proven part of the flow.
4. Add one or two built-in sample inputs for quick validation.
5. Make the helper tolerant of pasted JSON, nested `result` or `key` envelopes, and noisy text when useful.

## When Not To Use This Skill

- when the main task is still classification; use `signature-vs-encryption-triage`
- when the algorithm path is still unresolved; use `complex-js-reverse`
- when the user needs the original browser function running offline; use `env-patch`

## Output

Ship a helper with:

- one clear entrypoint
- editable sample inputs
- visible intermediate values when helpful
- a note on what is observed versus inferred
