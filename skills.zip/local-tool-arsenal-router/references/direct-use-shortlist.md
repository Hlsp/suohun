# Current direct-use shortlist

## Already suitable for direct invocation

- `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\fscan\fscan.exe`
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\spring\SpringBoot-Scan.py`
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\dirsearch\dirsearch.py`
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\sqlmap\sqlmap.py`
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json\JsonExp.exe` via wrapper

## Why these first

- proven CLI or script entry
- clear task fit
- low friction for integration into a skill workflow

## Important caveat

`SpringBoot-Scan.py` is only **partially** direct-use today because many code paths are interactive. Prefer:

- source-backed understanding
- selective wrappering
- or a future non-interactive patch path

By contrast, `JsonExp` via wrapper and `fscan` via wrapper are already practical.
