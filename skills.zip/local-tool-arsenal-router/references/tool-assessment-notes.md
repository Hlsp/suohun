# Tool assessment notes

## Tool 1: 天狐渗透工具箱

This is best treated as a **launcher database** rather than a single automatable tool.

Valuable parts:

- `config/tools.json` gives underlying paths and types
- categories help cluster tools by task
- `utils.py` shows how the launcher runs Python, Java, GUI, batch, and web tools

Automation lesson:

- reuse the underlying tools directly
- do not automate the GUI shell first

### Learned subtools so far

#### JsonExp

- executable: `gui_scan\json\JsonExp.exe`
- status: **learned and wrapper-ready**
- notes:
  - supports URL / URL file / raw request / LDAP / RMI / proxy
  - must run from its own working directory because it loads local templates and user-agent files
  - best for Fastjson/Jackson parser-family detection and payload-family narrowing

#### SpringBoot-Scan

- script: `gui_scan\spring\SpringBoot-Scan.py`
- status: **partially learned, partially wrapper-ready**
- notes:
  - info leak, vuln, dump, and asset-export capability confirmed from source/README
  - original script is highly interactive (`input()` in multiple code paths)
  - `-u` and `-uf` routes can be wrapper-driven by pre-answering delay/concurrency prompts
  - `-d` dump mode is suitable for direct wrapper execution
  - `-v` single-target exploit mode remains manual-first because it may enter command interaction
  - best treated as source-backed workflow knowledge plus selective wrapper target

#### Shiro jars

- jars:
  - `gui_scan\shiro\shiro\shiro_attack-4.7.0-SNAPSHOT-all.jar`
  - `gui_scan\shiro\shiro_attack2\Pyke-Shiro_0.3.jar`
- status: **manual-first**
- notes:
  - GUI-main jars
  - rich key dictionaries and family-specific value confirmed
  - no stable non-interactive CLI contract proven yet

#### NacosExploit

- jar: `gui_scan\nacos\NacosExploit-1.0.1-SNAPSHOT-jar-with-dependencies.jar`
- status: **manual-first**
- notes:
  - GUI-main jar
  - bundled auth / yaml / jraft related modules observed
  - good knowledge source for Nacos family paths, but not yet automation-ready

#### Hyacinth

- jar: `gui_scan\struts2\hyacinth.jar`
- status: **manual-first**
- notes:
  - GUI-main jar
  - clearly Struts-oriented
  - no proven CLI contract yet

## Tool 2: 端口扫描 toolbox

This directory mixes:

- direct binaries (`fscan.exe`)
- GUI/toolkit metadata (`ToolKit.json`)
- config and dictionaries
- local PoC corpora

Automation lesson:

- direct binaries first
- toolkit metadata second
- GUI wrappers later

### Learned subtools so far

#### fscan

- executable: `fscan\fscan.exe`
- status: **learned and wrapper-ready**
- notes:
  - usable CLI confirmed
  - supports host, host file, URL, URL file, web PoC, threading, timeout, output, and targeted modes

#### Railgun

- executable: `railgun\Railgun.exe`
- status: **wrapper candidate**
- notes:
  - promising binary, but CLI behavior still not characterized

#### TscanPlus

- executable: `TscanPlus_Win_Arm64.exe`
- status: **wrapper candidate**
- notes:
  - promising, but CLI behavior still not characterized
