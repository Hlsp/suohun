# Wrapper candidates

## Good future wrapper targets

### JsonExp

- path: `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json\JsonExp.exe`
- reason:
  - likely high value for fastjson/jackson challenge lanes
  - payload template files already exist nearby
  - supports URL / URL file / raw request / LDAP / RMI / proxy usage
- current status:
  - wrapper added: `scripts/run_jsonexp.py`
  - must run from its own working directory because it loads local templates and user-agent files
- best use:
  - parser-family detector after Fastjson/Jackson clue exists
  - request-file mode when a specific parameter position is known

### Railgun

- path: `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\railgun\Railgun.exe`
- reason:
  - likely capable, but invocation style still needs characterization

### TscanPlus

- path: `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\TscanPlus_Win_Arm64.exe`
- reason:
  - likely broad scanning capability
  - needs CLI behavior mapping

### Shiro / Nacos helper jars

- paths:
  - `...\gui_scan\shiro\...jar`
  - `...\gui_scan\nacos\NacosExploit-*.jar`
- reason:
  - strong family-specific value
  - need usage notes or wrappers before safe autonomous use
  - current deep-read shows they are GUI-main jars with rich bundled libs, but direct headless help/CLI behavior is not yet characterized
