# Direct invocation recipes

## fscan

Wrapper:

- `scripts/run_fscan.py`

Good uses:

- host/port/service sweep
- lightweight web+service mixed recon
- initial internal or wide-scope technical surface map

Good defaults:

- `--threads 200`
- `--timeout 3`
- `--web-timeout 8`

Examples:

```powershell
python scripts/run_fscan.py --hosts 192.168.1.0/24 --mode all --no-brute --no-poc
python scripts/run_fscan.py --url http://target --mode web --json --output fscan-web.json
```

Do not use first when:

- only one business web target exists and browser/runtime truth is more valuable
- you already know the exact endpoint and need parser/business logic proof, not breadth

## SpringBoot-Scan

Wrapper:

- `scripts/run_springboot_scan.py`

Good uses:

- Spring Boot shell with Whitelabel / `/error`
- likely actuator/doc/heapdump/config route exposure
- Spring-family CVE lane shortlist

Examples:

```powershell
python scripts/run_springboot_scan.py --url http://target
python scripts/run_springboot_scan.py --url http://target --delay 0
python scripts/run_springboot_scan.py --url-file urls.txt --delay 0 --concurrency 10
python scripts/run_springboot_scan.py --dump http://target
```

Safer autonomous modes:

- `--url`
- `--url-file`
- `--dump`

Manual-first mode:

- `--vuln-url`

because the upstream tool may enter interactive command execution loops.

Do not use first when:

- the target is clearly not Spring
- you already have a stronger runtime clue for another component family

## JsonExp

Wrapper:

- `scripts/run_jsonexp.py`

Good uses:

- Fastjson / Jackson family detection
- request-file mode when a parser sink or exact parameter location is already known
- LDAP/RMI callback-based parser confirmation

Examples:

```powershell
python scripts/run_jsonexp.py --url http://target/json --ldap 127.0.0.1:1389
python scripts/run_jsonexp.py --request-file req.txt --protocol https --ldap 127.0.0.1:1389
python scripts/run_jsonexp.py --url-file urls.txt --payload-file D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json\template\jackson.txt --ldap 127.0.0.1:1389
```

Important:

- run through the wrapper so the working directory is set correctly
- do not treat it as a one-click exploit tool; use it to narrow parser family and candidate payload lanes
