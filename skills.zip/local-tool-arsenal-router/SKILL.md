---
name: local-tool-arsenal-router
description: Use when the task may benefit from the user's local tool arsenal and Codex should choose whether to invoke a local executable/script directly, wrap it behind a simpler CLI, or only document it in the current workflow. Trigger when the user provides tool directories, asks to use local tools, or when a workflow would be stronger if Codex reused an existing scanner, exploit helper, recon binary, or GUI framework launcher from the local machine.
role: router
domain: general-security
---

# Local Tool Arsenal Router

Use this skill to decide:

1. what local tool fits the current task
2. whether it is directly callable
3. whether it should be wrapped
4. whether it is GUI-only and should be treated as a reference instead of an automation dependency

## Core rule

Do not treat every local tool directory as equally automatable.

Classify each tool into one of these buckets:

- **direct CLI**
- **direct script**
- **wrapper candidate**
- **MCP candidate**
- **GUI-only / documentation-only**

## Current known local arsenals

### Tool 1

- root: `D:\杂项\天狐渗透工具箱-社区版V1.2`
- nature: **GUI launcher / aggregator framework**
- evidence:
  - `main.py`, `utils.py`, `config/tools.json`
  - many tools registered in JSON and launched by type
  - categories include recon, exploit, cracking, webshell, proxy, post-exploitation

Interpretation:

- this is **not** one tool; it is a launcher shell over many sub-tools
- best use:
  - mine `config/tools.json` for executable/script locations
  - pick the underlying sub-tool directly
  - avoid automating the PyQt GUI itself unless absolutely needed

### Tool 2

- root: `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描`
- nature: **mixed toolbox with several strong direct binaries and a GUI toolkit**
- evidence:
  - `fscan\fscan.exe`
  - `railgun\Railgun.exe`
  - `TscanPlus_Win_Arm64.exe`
  - `config\ToolKit.json`
  - PoC directories and config dictionaries

Interpretation:

- this root contains both:
  - directly automatable scanners
  - a second GUI/toolkit layer

## What is already worth using directly

### High-value direct CLI/script candidates

Use these first when their task fit is strong:

- `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\fscan\fscan.exe`
  - direct CLI
  - good for host/port/service and mixed network service probing
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\spring\SpringBoot-Scan.py`
  - direct Python script
  - good for Spring Boot route/feature/vuln family checks
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\dirsearch\dirsearch.py`
  - direct Python script
  - useful when route fuzzing is justified
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\sqlmap\sqlmap.py`
  - direct Python script
  - use only after an injection hypothesis exists
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json\JsonExp.exe`
  - direct binary through wrapper
  - useful for Fastjson/Jackson parser-family detection

Direct wrappers are available for:

- `scripts/run_fscan.py`
- `scripts/run_springboot_scan.py`
- `scripts/run_jsonexp.py`

### High-value wrapper candidates

These are promising but should usually be mediated through a wrapper or explicit skill guidance:

- `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\railgun\Railgun.exe`
  - likely useful, but needs command-line behavior characterization
- `Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\TscanPlus_Win_Arm64.exe`
  - likely useful, but needs CLI contract characterization
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json\JsonExp.exe`
  - strong Fastjson/Jackson challenge helper candidate
  - likely needs wrapper/usage note extraction from `Readme.md` and templates
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\shiro\...jar`
  - likely useful as Shiro oracle/default-key helper
  - best accessed through a usage summary, not blind GUI launch
- `D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\nacos\NacosExploit-*.jar`
  - likely useful for Nacos family testing
  - wrapper or usage normalization recommended

### GUI-only / launcher-only assets

Treat these as references unless the workflow truly requires them:

- the PyQt “天狐渗透工具箱” shell itself
- Burp/Fiddler/Reqable-style GUI launchers from the tool launcher
- Godzilla / Behinder / AntSword launch entries

These can be documented and manually launched, but should not be the first automation target.

## Decision rules

### Use direct CLI when

- the binary/script already accepts useful CLI arguments
- stdout/stderr are enough for decision-making
- task is single-shot or batch-friendly

### Use a wrapper when

- invocation is possible but parameters are messy
- output is noisy or not machine-friendly
- you want standardized input/output for repeated use

### Consider MCP when

- the tool is stateful or query-oriented
- repeated interactive calls would help multiple workflows
- the tool behaves more like a service than a one-shot command

### Use docs only when

- the tool is GUI-first and hard to drive headlessly
- the real value is its underlying method, not automation
- launching it blindly would interrupt the flow

## Good current routes

### Bare URL, unknown Java target

- first: `blackbox-business-shape-router`
- if Spring clues: `SpringBoot-Scan.py`
- if component clues: `java-third-party-component-hunter` -> `java-component-poc-router`
- only then use `dirsearch.py` if route probing is justified

### Network / intranet / host-range task

- first: `fscan.exe`
- later: evaluate `Railgun.exe` / `TscanPlus_Win_Arm64.exe` for wrapper integration

### Fastjson / Jackson parser challenge

- first: runtime canary and parser mapping
- then: inspect `gui_scan\json\Readme.md` and templates
- use `JsonExp.exe` as helper only after understanding the expected payload family

## References

- arsenal assessment notes: `references/tool-assessment-notes.md`
- current direct-use shortlist: `references/direct-use-shortlist.md`
- wrapper candidates: `references/wrapper-candidates.md`
- direct invocation recipes: `references/invocation-recipes.md`

## Evidence standard

For each tool considered, record:

- tool path
- category
- why it fits the task
- direct CLI / wrapper / MCP / doc-only classification
- the exact invocation or the blocker preventing invocation
