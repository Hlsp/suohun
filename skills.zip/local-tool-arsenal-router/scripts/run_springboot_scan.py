import argparse
import os
import subprocess
import sys


SCRIPT = r"D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\spring\SpringBoot-Scan.py"
BASE_DIR = os.path.dirname(SCRIPT)


def main() -> int:
    parser = argparse.ArgumentParser(description="Thin wrapper for local SpringBoot-Scan.py")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", help="single target URL")
    group.add_argument("--url-file", help="TXT file with target URLs")
    group.add_argument("--vuln-url", help="single target URL for vuln mode")
    group.add_argument("--vuln-file", help="TXT file for vuln batch mode")
    group.add_argument("--dump", help="single target URL for dump mode")
    parser.add_argument("--proxy", help="HTTP proxy")
    parser.add_argument("--header-file", help="custom header TXT file")
    parser.add_argument("--zoomeye", help="ZoomEye API key")
    parser.add_argument("--fofa", help="Fofa API key")
    parser.add_argument("--hunter", help="Hunter API key")
    parser.add_argument("--delay", default="0", help="answer for delay prompt in scan modes")
    parser.add_argument("--concurrency", default="10", help="answer for concurrency prompt in batch scan modes")
    args = parser.parse_args()

    if not os.path.isfile(SCRIPT):
        print(f"[ERR] SpringBoot-Scan not found: {SCRIPT}", file=sys.stderr)
        return 2

    cmd = ["python", SCRIPT]
    if args.url:
        cmd += ["-u", args.url]
    elif args.url_file:
        cmd += ["-uf", args.url_file]
    elif args.vuln_url:
        cmd += ["-v", args.vuln_url]
    elif args.vuln_file:
        cmd += ["-vf", args.vuln_file]
    elif args.dump:
        cmd += ["-d", args.dump]
    if args.proxy:
        cmd += ["-p", args.proxy]
    if args.header_file:
        cmd += ["-t", args.header_file]
    if args.zoomeye:
        cmd += ["-z", args.zoomeye]
    if args.fofa:
        cmd += ["-f", args.fofa]
    if args.hunter:
        cmd += ["-y", args.hunter]

    print("[RUN]", " ".join(cmd))

    stdin_data = None
    if args.url:
        stdin_data = f"{args.delay}\n"
    elif args.url_file:
        stdin_data = f"{args.delay}\n{args.concurrency}\n"
    elif args.vuln_file:
        stdin_data = "\n"
    elif args.vuln_url:
        # interactive exploit mode is not a good autonomous default
        print("[WARN] vuln-url mode may enter command interaction. Prefer manual supervision.", file=sys.stderr)
    elif args.dump:
        stdin_data = None

    proc = subprocess.Popen(
        cmd,
        cwd=BASE_DIR,
        stdin=subprocess.PIPE if stdin_data is not None else None,
        text=True,
    )
    if stdin_data is not None and proc.stdin:
        proc.stdin.write(stdin_data)
        proc.stdin.flush()
        proc.stdin.close()
    return proc.wait()


if __name__ == "__main__":
    raise SystemExit(main())
