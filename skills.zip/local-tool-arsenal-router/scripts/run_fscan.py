import argparse
import os
import subprocess
import sys


FSCAN = r"Z:\BaiduNetdiskDownload\Tools\信息收集\端口扫描\fscan\fscan.exe"


def main() -> int:
    parser = argparse.ArgumentParser(description="Thin wrapper for local fscan")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--hosts", help="host or host range for -h")
    group.add_argument("--host-file", help="host file for -hf")
    group.add_argument("--url", help="single URL for -u")
    group.add_argument("--url-file", help="URL file for -uf")
    parser.add_argument("--mode", default="all", help="scan mode for -m")
    parser.add_argument("--ports", help="port expression for -p")
    parser.add_argument("--threads", type=int, default=200, help="thread count for -t")
    parser.add_argument("--timeout", type=int, default=3, help="timeout seconds for -time")
    parser.add_argument("--web-timeout", type=int, default=8, help="web timeout seconds for -wt")
    parser.add_argument("--no-poc", action="store_true", help="pass -nopoc")
    parser.add_argument("--no-brute", action="store_true", help="pass -nobr")
    parser.add_argument("--json", action="store_true", help="pass -json")
    parser.add_argument("--output", default="result.txt", help="output file for -o")
    parser.add_argument("--extra", nargs=argparse.REMAINDER, help="extra raw args after --extra")
    args = parser.parse_args()

    if not os.path.isfile(FSCAN):
        print(f"[ERR] fscan not found: {FSCAN}", file=sys.stderr)
        return 2

    cmd = [FSCAN]
    if args.hosts:
        cmd += ["-h", args.hosts]
    elif args.host_file:
        cmd += ["-hf", args.host_file]
    elif args.url:
        cmd += ["-u", args.url]
    elif args.url_file:
        cmd += ["-uf", args.url_file]

    cmd += ["-m", args.mode, "-t", str(args.threads), "-time", str(args.timeout), "-wt", str(args.web_timeout), "-o", args.output]
    if args.ports:
        cmd += ["-p", args.ports]
    if args.no_poc:
        cmd.append("-nopoc")
    if args.no_brute:
        cmd.append("-nobr")
    if args.json:
        cmd.append("-json")
    if args.extra:
        cmd += args.extra

    print("[RUN]", " ".join(cmd))
    return subprocess.call(cmd)


if __name__ == "__main__":
    raise SystemExit(main())
