import argparse
import os
import subprocess
import sys


BASE = r"D:\杂项\天狐渗透工具箱-社区版V1.2\gui_scan\json"
EXE = os.path.join(BASE, "JsonExp.exe")


def main() -> int:
    parser = argparse.ArgumentParser(description="Thin wrapper for local JsonExp")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--url", help="single target URL")
    group.add_argument("--url-file", help="TXT file with target URLs")
    group.add_argument("--request-file", help="raw request file with $payload$")
    parser.add_argument("--timeout", type=int, default=5, help="request timeout seconds")
    parser.add_argument("--payload-file", default=os.path.join(BASE, "template", "fastjson.txt"), help="payload template file")
    parser.add_argument("--method", default="post", choices=["get", "post"], help="HTTP method")
    parser.add_argument("--ldap", help="LDAP host:port")
    parser.add_argument("--rmi", help="RMI host:port")
    parser.add_argument("--cookie", help="cookie string")
    parser.add_argument("--protocol", choices=["http", "https"], default="http", help="for --request-file mode")
    parser.add_argument("--proxy", help="HTTP proxy URL")
    args = parser.parse_args()

    if not os.path.isfile(EXE):
        print(f"[ERR] JsonExp not found: {EXE}", file=sys.stderr)
        return 2

    cmd = [EXE]
    if args.url:
        cmd += ["-u", args.url]
    elif args.url_file:
        cmd += ["-uf", args.url_file]
    elif args.request_file:
        cmd += ["-req", args.request_file]

    cmd += ["-to", str(args.timeout), "-f", args.payload_file, "-t", args.method]
    if args.ldap:
        cmd += ["-l", args.ldap]
    if args.rmi:
        cmd += ["-r", args.rmi]
    if args.cookie:
        cmd += ["-c", args.cookie]
    if args.request_file and args.protocol:
        cmd += ["-pro", args.protocol]
    if args.proxy:
        cmd += ["-proxy", args.proxy]

    print("[RUN]", " ".join(cmd))
    return subprocess.call(cmd, cwd=BASE)


if __name__ == "__main__":
    raise SystemExit(main())
