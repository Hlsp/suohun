---
name: performing-jwt-none-algorithm-attack
description: "Focused JWT none-algorithm validation skill. Use when checking whether a JWT verifier accepts unsigned tokens, missing signatures, or algorithm downgrades in an authorized assessment."
role: specialist
domain: auth-api
---

# Performing JWT None Algorithm Attack

Use this focused skill only for the unsigned-token class of JWT validation bugs. For broader JWT work, load [jwt-oauth-token-attacks](../jwt-oauth-token-attacks/SKILL.md).

## Core Model

The bug exists when a server accepts a JWT whose header claims no signature is required, or otherwise accepts a token without verifying integrity.

Useful proof requires:

1. Baseline valid JWT from a self-owned account.
2. Modified header or signature state.
3. Server acceptance by a protected endpoint.
4. Observable claim-driven impact, such as changed role, subject, tenant, or scope.

## Validation Ladder

1. Decode the original JWT and record algorithm, issuer, audience, subject, and expiry.
2. Create an unsigned variant while changing only one low-risk claim first.
3. Replay to a protected endpoint that requires authentication.
4. If accepted, test a meaningful but reversible claim change.
5. Confirm server-side state or authorization difference.
6. Revoke the session and record cleanup.

## False Positives

- The frontend accepts the token but backend rejects it.
- The endpoint does not require authentication.
- The server ignores the changed claim and uses session state elsewhere.
- A gateway accepts the token but downstream services reject it.

## Evidence Standard

Capture original token source, modified header/claim summary, endpoint replay, server acceptance proof, actual authorization difference, and cleanup action.

## Local Assets

- `scripts/agent.py` for tool wrapper usage.
- `references/api-reference.md` for bundled tool notes.

## Pivots

- Full JWT workflow: [testing-for-json-web-token-vulnerabilities](../testing-for-json-web-token-vulnerabilities/SKILL.md)
- Algorithm confusion: [exploiting-jwt-algorithm-confusion-attack](../exploiting-jwt-algorithm-confusion-attack/SKILL.md)
- API authorization: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
