#!/usr/bin/env python3
import base64
import json

TITLE = "__TITLE__"
SAMPLE = json.loads(r'''__SAMPLE_JSON__''')


def encrypt_flow(plain_object):
    # TODO: Replace with recovered browser logic.
    plain_text = json.dumps(plain_object, ensure_ascii=False, separators=(",", ":"))
    return {
        "data": base64.b64encode(plain_text.encode("utf-8")).decode("ascii"),
        "key": "TODO",
    }


def decrypt_flow(cipher_text, wrapped_key):
    # TODO: Replace with recovered browser logic.
    plain_text = base64.b64decode(cipher_text).decode("utf-8")
    return json.loads(plain_text)


def main():
    print(TITLE)
    encrypted = encrypt_flow(SAMPLE)
    print("encrypted:", encrypted)
    print("decrypted:", decrypt_flow(encrypted["data"], encrypted["key"]))


if __name__ == "__main__":
    main()
