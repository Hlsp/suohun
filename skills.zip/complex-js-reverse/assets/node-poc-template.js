#!/usr/bin/env node

const SAMPLE = __SAMPLE_JSON__;
const TITLE = "__TITLE__";

function encryptFlow(plainObject) {
  // TODO: Replace with recovered browser logic.
  const plainText = JSON.stringify(plainObject);
  return {
    data: Buffer.from(plainText, 'utf8').toString('base64'),
    key: 'TODO'
  };
}

function decryptFlow(cipherText, wrappedKey) {
  // TODO: Replace with recovered browser logic.
  const plainText = Buffer.from(cipherText, 'base64').toString('utf8');
  return JSON.parse(plainText);
}

function main() {
  console.log(TITLE);
  const encrypted = encryptFlow(SAMPLE);
  console.log('encrypted:', encrypted);
  console.log('decrypted:', decryptFlow(encrypted.data, encrypted.key));
}

main();
