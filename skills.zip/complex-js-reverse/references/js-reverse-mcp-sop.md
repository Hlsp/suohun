# JS Reverse MCP SOP

## 1. Session Prep

Use these tools first:

- `mcp__js_reverse_mcp__check_browser_health`
- `mcp__js_reverse_mcp__list_pages`
- `mcp__js_reverse_mcp__select_page`
- `mcp__js_reverse_mcp__save_session_state`
- `mcp__js_reverse_mcp__get_storage`

If browser startup fails because of profile conflicts, stop and fix isolation before proceeding.

## 2. Capture the Target Flow

1. Navigate to the page.
2. Trigger the target action.
3. List network requests.
4. Identify the request id for the encrypted API call.
5. Pull the request details and the initiator.

Preferred tools:

- `mcp__js_reverse_mcp__navigate_page`
- `mcp__js_reverse_mcp__list_network_requests`
- `mcp__js_reverse_mcp__get_network_request`
- `mcp__js_reverse_mcp__get_request_initiator`

## 3. Narrow the Code Search

Once you know the request path or initiator file, search nearby first.

Preferred tools:

- `mcp__js_reverse_mcp__search_in_sources`
- `mcp__js_reverse_mcp__list_scripts`
- `mcp__js_reverse_mcp__find_in_script`
- `mcp__js_reverse_mcp__get_script_source`
- `mcp__js_reverse_mcp__collect_code`
- `mcp__js_reverse_mcp__summarize_code`

Start from:

- API path fragments
- encrypted field names such as `data`, `key`, `result`, `sign`
- nearby business strings from the request
- `axios` interceptors, request builders, and response transformers

## 4. Hook the Runtime

Hook the narrowest useful function first.

Best order:

1. app wrapper that builds request params or unwraps responses
2. interceptor or serializer layer
3. crypto primitive
4. transport primitive such as `fetch` or `XMLHttpRequest`

Preferred tools:

- `mcp__js_reverse_mcp__hook_function`
- `mcp__js_reverse_mcp__trace_function`
- `mcp__js_reverse_mcp__create_hook`
- `mcp__js_reverse_mcp__inject_hook`
- `mcp__js_reverse_mcp__get_hook_data`

Useful primitive targets:

- `CryptoJS.AES.encrypt`
- `CryptoJS.AES.decrypt`
- `window.crypto.subtle.encrypt`
- `window.crypto.subtle.decrypt`
- `JSEncrypt.prototype.encrypt`
- `fetch`
- `XMLHttpRequest.prototype.send`

## 5. Inspect Runtime State

Look for secrets and deterministic inputs in runtime state.

Preferred tools:

- `mcp__js_reverse_mcp__get_storage`
- `mcp__js_reverse_mcp__inspect_object`
- `mcp__js_reverse_mcp__evaluate_script`
- `mcp__js_reverse_mcp__search_in_scripts`

Check for:

- public keys
- IV seeds
- timestamps and nonce builders
- tenant or app config
- token or device id values

## 6. Reconstruct the Flow

Build two separate chains:

- request chain: plaintext -> serialize -> encrypt/sign -> encode -> transport
- response chain: receive -> decode -> decrypt -> parse -> consumer

Do not claim symmetry until both chains are observed.

## 7. Produce Deliverables

At minimum deliver:

- encrypted field mapping
- likely crypto stack
- source locations and hooks used
- verified PoC
- remaining uncertainty

Use `references/report-template.md` for the final structure.
