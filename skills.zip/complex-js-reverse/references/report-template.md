# Reverse Engineering Report Template

Use this template when the user asks for a final analysis report.

## 1. Interface Overview

- target page
- API path or websocket channel
- request method
- encrypted request fields
- encrypted response fields

## 2. Evidence Summary

- capture method
- request ids or frame ids used
- initiator locations
- hooks used
- storage or runtime artifacts used

## 3. Crypto Stack Assessment

List each component with an evidence note:

- request data encryption
- key transport
- response decryption
- signature or MAC if present
- transport encoding

## 4. Key Code Locations

For each location include:

- file or script url
- function name if known
- line or nearby match context
- role in the flow

## 5. Verified Flow

Describe the exact chain:

- request plaintext -> ... -> ciphertext
- response ciphertext -> ... -> plaintext

Separate verified facts from inference.

## 6. PoC

Provide one of:

- Node.js script
- Python script
- HTML page

The PoC should include:

- sample input
- encrypt path if verified
- decrypt path if verified
- notes for unknown values that must be supplied by the user

## 7. Remaining Gaps

List:

- unknown key material
- unverified branches
- anti-debug or anti-bot blockers
- missing samples
