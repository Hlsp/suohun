# Complex JS Reverse Playbook

## Fast Triage

Use this order unless the page is already paused at a useful breakpoint:

1. Confirm browser health and active page.
2. Trigger the target request.
3. Inspect network requests and identify the exact request id.
4. Pull the request initiator / stack.
5. Search the corresponding sources near the initiator first.
6. Add hooks to the nearest wrapper.
7. Fall back to generic crypto hooks only if wrapper search fails.

## Search Terms

Search exact strings and partial fragments around the target flow:

- `encrypt`
- `decrypt`
- `CryptoJS`
- `AES`
- `RSA`
- `JSEncrypt`
- `publicKey`
- `privateKey`
- `subtle.encrypt`
- `subtle.decrypt`
- `iv`
- `nonce`
- `salt`
- `sign`
- `signature`
- `result`
- `data`
- `key`
- `ciphertext`
- `paramsSerializer`
- `interceptors.request`
- `interceptors.response`
- `transformRequest`
- `transformResponse`

Also search for the API path fragment, host, or a nearby business string from the request payload.

## Hook Targets

Prefer narrow hooks first:

- Request wrapper functions that build `{data, key}` or `{result, key}`
- Axios request / response interceptors
- Business helpers like `encryptParams`, `encryptRequest`, `decryptResponse`
- Library primitives:
  - `CryptoJS.AES.encrypt`
  - `CryptoJS.AES.decrypt`
  - `window.crypto.subtle.encrypt`
  - `window.crypto.subtle.decrypt`
  - `JSEncrypt.prototype.encrypt`
  - `JSEncrypt.prototype.decrypt`
  - `fetch`
  - `XMLHttpRequest.prototype.open`
  - `XMLHttpRequest.prototype.send`

## Common Patterns

### Hybrid encryption

Strong signal:

- one large `data` blob plus one smaller `key` blob
- front end contains an RSA public key
- request plaintext becomes AES ciphertext
- AES key or random secret is RSA-encrypted and sent as `key`

### Response-wrapped encryption

Strong signal:

- response JSON has fields like `result`, `data`, `cipher`, or `encrypt`
- app UI still renders meaningful data after the response arrives
- response interceptor or parsing helper transforms the body before components consume it

### Signature-only requests

Strong signal:

- fields like `sign`, `timestamp`, `nonce`, `appId`
- sorted parameter concatenation
- hashing without reversible decryption

Do not promise decryption when the mechanism is only a signature or MAC.

## Runtime Artifacts To Inspect

- `localStorage`
- `sessionStorage`
- cookies
- global config objects
- webpack module exports
- environment variables embedded in bundles
- request headers generated at runtime

## PoC Checklist

- match the same serialization order as the browser
- match AES mode and padding exactly
- match IV / nonce source exactly
- keep Base64 vs hex output identical to the page
- preserve URL encoding when the API expects query params
- verify decrypting a real captured response before claiming success

## Compact Report Template

Use this shape when producing a final report:

- Interface overview
- Encrypted request fields
- Encrypted response fields
- Likely crypto stack
- Key source and IV source
- Source locations and hooks used
- Verified plaintext / ciphertext mapping
- Runnable PoC
- Remaining uncertainties
