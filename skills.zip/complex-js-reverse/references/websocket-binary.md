# WebSocket And Binary Workflow

## 1. Identify the Connection

Use:

- `mcp__js_reverse_mcp__list_websocket_connections`
- `mcp__js_reverse_mcp__analyze_websocket_messages`

Do not start by dumping all frames. Group the traffic first.

## 2. Group Before Reading

Use `analyze_websocket_messages` to get message groups and counts, then read only the groups that matter.

Follow with:

- `mcp__js_reverse_mcp__get_websocket_messages`
- `mcp__js_reverse_mcp__get_websocket_message`

## 3. Correlate With Page Actions

Trigger one action at a time and note which message groups change. If needed, monitor DOM events or hook the function that calls `WebSocket.prototype.send`.

Useful tools:

- `mcp__js_reverse_mcp__monitor_events`
- `mcp__js_reverse_mcp__hook_function`
- `mcp__js_reverse_mcp__trace_function`

## 4. Distinguish Framing From Encryption

Binary payloads may be:

- protobuf or flatbuffers
- compression layers
- framing headers
- actual encrypted payloads

Do not call it encryption until there is evidence of key material or decrypt logic.

## 5. Find Decode Consumers

Search for:

- `onmessage`
- `addEventListener("message"`
- `protobuf`
- `decode`
- `inflate`
- `gunzip`
- `pako`

Then inspect the code that consumes the decoded object.

## 6. Deliverables

Include:

- websocket URL
- relevant frame groups
- send and receive handlers
- any decode or decrypt functions involved
- PoC or decoding notes if full decryption is not yet proven
