# Crypto Pattern Notes

## Distinguish the Major Cases

### Reversible encryption

Strong signals:

- ciphertext fields that are later consumed by UI as meaningful data
- a response transformer or decrypt helper before parsing
- library calls to AES or WebCrypto decrypt functions
- paired fields such as `data` and `key`

### Hybrid encryption

Strong signals:

- one large ciphertext plus one smaller encrypted key
- visible RSA public key in the bundle or runtime config
- random AES secret generated per request
- RSA wrapping of the AES secret

### Signature or MAC only

Strong signals:

- fields such as `sign`, `signature`, `nonce`, `timestamp`, `appId`
- stable plaintext params remain visible while one digest field changes
- hashing or HMAC functions without any decrypt path

Do not promise decryptability for signature-only schemes.

## Common Implementation Clues

### CryptoJS

Look for:

- `CryptoJS.AES.encrypt`
- `CryptoJS.AES.decrypt`
- `CryptoJS.enc.Utf8.parse`
- `CryptoJS.mode.CBC`
- `CryptoJS.pad.Pkcs7`

### WebCrypto

Look for:

- `window.crypto.subtle.importKey`
- `window.crypto.subtle.encrypt`
- `window.crypto.subtle.decrypt`
- algorithm objects containing `name`, `iv`, or `length`

### RSA wrappers

Look for:

- `JSEncrypt`
- PEM blocks beginning with `-----BEGIN PUBLIC KEY-----`
- `RSAKey`
- `setPublicKey`

## What To Verify Before Building a PoC

- serialization order
- text encoding
- Base64 vs hex output
- IV or nonce source
- URL encoding requirements
- whether the app signs in addition to encrypting
- whether response decryption runs before or after JSON parse
