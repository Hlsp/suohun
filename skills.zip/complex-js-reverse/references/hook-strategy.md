# Hook Strategy

## Preferred Escalation

Use this order unless you already know you need local variables from a paused frame:

1. `hook_function`
2. `trace_function`
3. transport hooks such as `fetch` or `XMLHttpRequest.prototype.send`
4. `set_breakpoint_on_text` or `set_breakpoint`

## When To Use Each Tool

### hook_function

Use when the target is a global function or object method and you want argument and result capture without pausing execution.

Best for:

- `CryptoJS.AES.encrypt`
- `CryptoJS.AES.decrypt`
- `JSEncrypt.prototype.encrypt`
- wrapper methods on `window.app`, `window.api`, or similar globals

### trace_function

Use when the function is internal to a bundle and not easy to hook by object path, but the function name appears in source.

Best for:

- named helper functions in webpack or rollup bundles
- internal decrypt handlers found by source search

### create_hook and inject_hook

Use when you need custom logic, property interception, or repeated monitoring across reloads.

### breakpoints

Use only when local variables inside the active function are essential and hooks are not enough.

Risks:

- execution pauses can disrupt anti-bot logic
- repeated resume cycles are noisy and brittle

## Practical Target Order

1. business wrapper
2. interceptor or serializer
3. crypto primitive
4. transport primitive
5. DOM event or click source only if earlier layers are unclear

## Minimal Logging Principle

Start with the smallest useful hook scope. Too much logging can hide the important values.

Capture at least:

- arguments
- result when useful
- call stack only when source location is unknown
