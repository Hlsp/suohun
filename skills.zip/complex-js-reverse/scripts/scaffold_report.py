#!/usr/bin/env python3
import argparse
from pathlib import Path


def build_report(target_url: str, api_path: str, method: str) -> str:
    return f"""# Web Reverse Engineering Report

## 1. Interface Overview
- target page: `{target_url}`
- api path: `{api_path}`
- method: `{method}`
- encrypted request fields: `[fill]`
- encrypted response fields: `[fill]`

## 2. Evidence Summary
- capture method: `[fill]`
- request ids or frame ids: `[fill]`
- initiator locations: `[fill]`
- hooks used: `[fill]`
- storage or runtime artifacts: `[fill]`

## 3. Crypto Stack Assessment
- request data encryption: `[fill]`
- key transport: `[fill]`
- response decryption: `[fill]`
- signature or MAC: `[fill]`
- transport encoding: `[fill]`

## 4. Key Code Locations
- file or script url: `[fill]`
- function name: `[fill]`
- role in flow: `[fill]`

## 5. Verified Flow
- request plaintext -> ... -> ciphertext
- response ciphertext -> ... -> plaintext

## 6. PoC
```text
[attach or paste PoC here]
```

## 7. Remaining Gaps
- `[fill]`
"""


def main() -> None:
    parser = argparse.ArgumentParser(description="Scaffold a reverse-engineering markdown report")
    parser.add_argument("--target-url", required=True)
    parser.add_argument("--api-path", required=True)
    parser.add_argument("--method", default="GET")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    out_path = Path(args.out)
    out_path.write_text(build_report(args.target_url, args.api_path, args.method), encoding="ascii")
    print(out_path)


if __name__ == "__main__":
    main()
