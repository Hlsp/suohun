#!/usr/bin/env node
/**
 * Decode response bodies shaped like { key, result } where:
 * - key is base64 bytes, converted to hex, slice(2), then SM2-decrypted to an AES key
 * - result is AES-256-CBC ciphertext
 * - IV is the first 16 bytes/chars of the AES key
 *
 * Usage:
 *   node sm2_aes_response_decoder.js --private-key <hex> --input responses.jsonl --out decoded.jsonl
 *   node sm2_aes_response_decoder.js --private-key <hex> --body '{"key":"...","result":"..."}'
 */

const fs = require("fs");
const crypto = require("crypto");
const { sm2 } = require("sm-crypto");

function parseArgs(argv) {
  const args = {};
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const k = a.slice(2);
      const v = argv[i + 1] && !argv[i + 1].startsWith("--") ? argv[++i] : true;
      args[k] = v;
    }
  }
  return args;
}

function parseMaybeJson(s) {
  if (typeof s !== "string") return s;
  const t = s.trim();
  if (!t) return null;
  return JSON.parse(t);
}

function unwrapRecord(record) {
  if (record && record.key && record.result) return record;
  for (const k of ["body", "response", "text", "raw"]) {
    if (record && typeof record[k] === "string") {
      try {
        const nested = JSON.parse(record[k]);
        if (nested && nested.key && nested.result) return nested;
      } catch (_) {}
    }
  }
  throw new Error("record does not contain key/result");
}

function decodeOne(record, privateKey) {
  const wrapped = unwrapRecord(record);
  const cipherHex = Buffer.from(wrapped.key, "base64").toString("hex").slice(2);
  const aesKey = sm2.doDecrypt(cipherHex, privateKey);
  if (!aesKey) throw new Error("SM2 decrypt returned empty AES key");
  const keyBuf = Buffer.from(aesKey, "utf8");
  const iv = Buffer.from(aesKey.slice(0, 16), "utf8");
  const decipher = crypto.createDecipheriv("aes-256-cbc", keyBuf, iv);
  let plain = decipher.update(wrapped.result, "base64", "utf8");
  plain += decipher.final("utf8");
  let parsed = null;
  try { parsed = JSON.parse(plain); } catch (_) {}
  return { aesKey, plain, json: parsed };
}

function main() {
  const args = parseArgs(process.argv);
  const privateKey = args["private-key"] || process.env.SM2_PRIVATE_KEY;
  if (!privateKey) {
    console.error("missing --private-key or SM2_PRIVATE_KEY");
    process.exit(2);
  }
  const out = args.out;
  const lines = [];

  if (args.body) {
    lines.push(JSON.stringify(parseMaybeJson(args.body)));
  } else if (args.input) {
    lines.push(...fs.readFileSync(args.input, "utf8").split(/\r?\n/).filter(Boolean));
  } else {
    const stdin = fs.readFileSync(0, "utf8");
    lines.push(...stdin.split(/\r?\n/).filter(Boolean));
  }

  const decoded = lines.map((line, idx) => {
    try {
      const record = parseMaybeJson(line);
      const res = decodeOne(record, privateKey);
      return JSON.stringify({ index: idx, ok: true, ...res });
    } catch (e) {
      return JSON.stringify({ index: idx, ok: false, error: e.message });
    }
  });

  if (out) fs.writeFileSync(out, decoded.join("\n") + "\n", "utf8");
  else process.stdout.write(decoded.join("\n") + "\n");
}

main();

