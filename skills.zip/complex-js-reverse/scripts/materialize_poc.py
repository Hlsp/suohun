#!/usr/bin/env python3
import argparse
from pathlib import Path


TEMPLATE_MAP = {
    "html": "html-poc-template.html",
    "node": "node-poc-template.js",
    "python": "python-poc-template.py",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Materialize a PoC template from bundled assets")
    parser.add_argument("--format", choices=sorted(TEMPLATE_MAP), required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--title", default="Crypto PoC Harness")
    parser.add_argument("--sample-json", default='{"phone":"13800000000","code":"123456"}')
    parser.add_argument("--sample-json-file")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    asset_dir = script_dir.parent / "assets"
    template_path = asset_dir / TEMPLATE_MAP[args.format]
    content = template_path.read_text(encoding="ascii")

    if args.sample_json_file:
        sample_json = Path(args.sample_json_file).read_text(encoding="utf-8")
    else:
        sample_json = args.sample_json

    content = content.replace("__TITLE__", args.title)
    content = content.replace("__SAMPLE_JSON__", sample_json)

    out_path = Path(args.out)
    out_path.write_text(content, encoding="ascii")
    print(out_path)


if __name__ == "__main__":
    main()
