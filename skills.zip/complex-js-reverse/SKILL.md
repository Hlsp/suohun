---
name: complex-js-reverse
description: "Focused frontend JavaScript reverse-engineering skill. Use when browser/runtime evidence shows request or response encryption, obfuscated bundles, CryptoJS/WebCrypto/RSA/AES flows, signatures, encrypted fields such as data/key/result/sign, websocket transforms, or browser-side decrypt logic; produce a reproducible Node.js, Python, or HTML PoC after tracing initiators and runtime state."
role: specialist
domain: browser-frontend-reverse
---

#
> Reference vault: when this lane needs more public writeup-derived payload or PoC patterns, load `../web-writeup-payload-vault/references/payloads/frontend_js.md` via `web-writeup-payload-vault`.

 Complex Js Reverse

Use this skill for browser-side reverse engineering where static reading alone is not enough and the task needs a disciplined mix of capture, tracing, hooking, runtime inspection, and reconstruction.

## Workflow Decision

Use this order to choose the path quickly:

1. If the blocker is browser startup, read `references/js-reverse-mcp-sop.md` first and fix isolation or stale browser state before touching the target site.
2. If the target is an HTTP request with encrypted params or body, follow the request/response flow in `references/js-reverse-mcp-sop.md`.
3. If the target is a websocket or live stream protocol, use `references/websocket-binary.md` before reading individual frames.
4. If the flow might be signature-only rather than reversible encryption, read `references/crypto-patterns.md` before promising decryption.
5. If the user asks for a deliverable, use `references/report-template.md` plus the scripts in `scripts/` to scaffold the report or PoC.

## Core Workflow

1. Stabilize the browser session.
   Prefer `mcp__js_reverse_mcp__check_browser_health`, `list_pages`, and an isolated browser instance. If the task mentions profile conflicts or "browser already running", fix the MCP launch mode before deeper analysis.
2. Capture representative encrypted traffic.
   Navigate to the target page, trigger the relevant action, and collect at least two full request/response pairs when possible. Preserve raw encrypted fields, headers, host, method, and timing.
3. Trace the request initiator before searching broadly.
   Use network tools to identify the target request, then use the initiator or call stack to locate the wrapper that assembles encrypted params or unwraps encrypted responses.
4. Combine static search with targeted hooks.
   Search loaded sources and collected bundles for crypto primitives and app-specific wrappers. Hook the narrowest useful function first: business wrapper before generic library primitive. Read `references/hook-strategy.md` when choosing between hooks, traces, and breakpoints.
5. Reconstruct request and response paths separately.
   Do not assume symmetry. Verify how request payloads are serialized, encrypted, encoded, and transmitted, then verify how the response is decoded and decrypted.
6. Build the PoC only after the evidence chain is coherent.
   Match serialization order, encoding, IV or nonce source, wrapper behavior, and transport encoding exactly.
7. If one encrypted response is successfully decoded, immediately build a small bulk decoder for captured responses and feed decoded JSON into the object/API workflow. Do not keep manually decrypting one sample at a time.
8. Materialize the deliverable.
   Use `scripts/scaffold_report.py` for a markdown report skeleton and `scripts/materialize_poc.py` to emit an HTML, Node.js, or Python starter from the bundled templates.
9. Deliver evidence-backed conclusions.
   Report what is observed, what is inferred, and what remains unverified. Only claim an algorithm, key source, IV source, or decryptability when there is direct evidence.

## Operating Rules

- Distinguish encoding from encryption. Base64, URL encoding, JSON stringify, protobuf, and gzip are not encryption.
- Prefer real runtime evidence over guessing from ciphertext length.
- Treat hybrid encryption as the default hypothesis, not the conclusion.
- If the response is encrypted and successfully rendered by the page, prioritize the response decrypt path. It often exposes the reusable AES key schedule or wrapper logic faster than the request path.
- When the site uses a wrapper like `encryptRequest`, `handleEncrypt`, `paramsSecure`, `decryptResult`, or an axios interceptor, hook that wrapper first.
- When a library primitive is used directly, hook likely targets such as `CryptoJS.AES.encrypt`, `CryptoJS.AES.decrypt`, `window.crypto.subtle.encrypt`, `window.crypto.subtle.decrypt`, `JSEncrypt.prototype.encrypt`, `JSEncrypt.prototype.decrypt`, `fetch`, and `XMLHttpRequest.prototype.send`.
- Inspect `localStorage`, `sessionStorage`, cookies, and global objects for public keys, salts, tenant ids, timestamps, device fingerprints, and nonce sources.
- If the crypto path is too noisy, search for the object construction around encrypted fields such as `data`, `key`, `result`, `sign`, `ciphertext`, `payload`, `encryptData`, or `bizContent`.
- When the flow looks like sorted params plus digest fields such as `timestamp`, `nonce`, `appId`, `token`, and `sign`, consider the possibility that it is a signature or MAC rather than a decryptable ciphertext.
- Prefer hooks over breakpoints unless local variables inside a function are essential.
- Separate observed facts from inference in every report.
- For encrypted API testing, the reverse deliverable is not finished until it helps the security loop: decoded `list/detail/action` responses, object IDs, business fields, and error semantics must be available for replay comparison.
- When a private key, client secret, or decrypt helper is found in a public bundle, treat it as a replay enabler first; report cryptographic exposure only if it causes data disclosure, authorization bypass, or offline access beyond the current authenticated view.

## Evidence Checklist

- Request URL, method, host, and encrypted fields
- Response body fields and encrypted blobs
- Initiator stack or source location of the request
- The exact wrapper or library function that performs encryption or decryption
- Plaintext before encryption
- Key material, IV, nonce, salt, or public key source
- Serialization order: stringify, sort, concat, sign, encrypt, encode
- Decrypt path for encrypted responses
- Storage, globals, or runtime artifacts used by the crypto flow
- WebSocket message groups and binary framing when relevant
- A standalone PoC that reproduces the observed behavior
- Bulk-decoded response corpus or decoder command when object/authorization testing depends on encrypted responses

## Resource Map

Read these files only when needed:

- `references/js-reverse-mcp-sop.md`: exact `js_reverse_mcp` workflow and tool ordering
- `references/websocket-binary.md`: websocket and binary stream workflow
- `references/crypto-patterns.md`: pattern recognition for AES, RSA, WebCrypto, signatures, and wrapper-based schemes
- `references/hook-strategy.md`: when to use hook, trace, or breakpoint
- `references/playbook.md`: concise search terms, hook targets, and PoC checklist
- `references/report-template.md`: output structure for final reports and PoC sections
- `scripts/scaffold_report.py`: create a markdown report skeleton
- `scripts/materialize_poc.py`: emit HTML, Node.js, or Python PoC starter files
- `assets/html-poc-template.html`: browser demo template
- `assets/node-poc-template.js`: Node.js PoC template
- `assets/python-poc-template.py`: Python PoC template
