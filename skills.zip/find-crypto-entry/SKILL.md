---
name: find-crypto-entry
description: Locate JavaScript request signing or encryption entrypoints. Use when analyzing protected parameters, token generation, encrypted fields, signed headers, URL or body values, and you need function locations plus call chains.
role: specialist
domain: browser-frontend-reverse
---

# Find Crypto Entry

Locate the function that generates or transforms the protected parameter named in the task.

## Goal

Return parameter/header/body field name, script URL or local bundle path, line/module location, function name or call site, call chain, and transform type.

## Strategy Selection

### Static Search First

Search parameter names, header names, API path fragments, and business method names. Include minified files when needed.

### XHR/Fetch Breakpoint When Static Search Fails

Set a breakpoint on the request URL or wrapper, trigger the UI once, then inspect the call stack. Focus on business frames above axios/fetch/XHR internals.

### Combine Both

Static search -> candidate assignment -> runtime breakpoint at assignment -> inspect inputs and outputs.

## Common Architectures

1. Business code assigns directly: `headers['x-sign'] = sign(data)`.
2. Request interceptor adds all auth/sign fields.
3. External security SDK exposes a global object such as `window.h5sign`.
4. Obfuscated bundle hides strings; search the non-obfuscated caller or hook the runtime function.

## Anti-Patterns

- Do not step repeatedly into framework internals.
- Do not assume absence because plaintext search fails in obfuscated code.
- Do not refresh repeatedly after setting script IDs unless necessary.
- Do not start environment patching before you know the entrypoint.

## Completion Format

```text
ENTRYPOINT:
  parameter:
  request/path:
  script/module:
  location:
  function:
  call_chain:
  transform_type:
  sample_input:
  sample_output_shape:
NEXT:
```

Use [env-patch](../env-patch/SKILL.md) or [browser-crypto-helper-builder](../browser-crypto-helper-builder/SKILL.md) for standalone reproduction.
