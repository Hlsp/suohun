#!/usr/bin/env python3
"""Storage API for Pentest Results."""
import argparse
import json
import logging
import sqlite3
from typing import Dict, List, Optional, Any

try:
    from .db_manager import ResultsDatabase
except ImportError:
    from db_manager import ResultsDatabase

logger = logging.getLogger(__name__)


class StorageAPI:
    SEVERITY_LEVELS = ["Critical", "High", "Medium", "Low", "Info"]

    def __init__(self, db_path: str = "./data/results.db"):
        self.db = ResultsDatabase(db_path)

    def create_subsystem(self, name: str, description: str = "", subnet_range: str = "") -> int:
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO subsystems (name, description, subnet_range) VALUES (?, ?, ?)",
                (name, description, subnet_range),
            )
            conn.commit()
            return int(cur.lastrowid)

    def get_or_create_subsystem(self, name: str) -> int:
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT id FROM subsystems WHERE name = ?", (name,))
            row = cur.fetchone()
            if row:
                return int(row[0])
            cur.execute("INSERT INTO subsystems (name) VALUES (?)", (name,))
            conn.commit()
            return int(cur.lastrowid)

    def list_subsystems(self) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                SELECT s.id, s.name, s.description, s.subnet_range, s.created_at,
                       COUNT(DISTINCT h.id) AS host_count,
                       COUNT(DISTINCT v.id) AS vuln_count
                FROM subsystems s
                LEFT JOIN hosts h ON s.id = h.subsystem_id
                LEFT JOIN vulnerabilities v ON h.id = v.host_id
                GROUP BY s.id
                ORDER BY s.name
                """
            )
            return [
                {
                    "id": r[0], "name": r[1], "description": r[2], "subnet_range": r[3],
                    "created_at": r[4], "host_count": r[5], "vuln_count": r[6],
                }
                for r in cur.fetchall()
            ]

    def _get_or_create_host(self, ip_address: str, subsystem_id: Optional[int] = None,
                            hostname: Optional[str] = None, os_fingerprint: Optional[str] = None) -> int:
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT id FROM hosts WHERE ip_address = ? AND (subsystem_id IS ? OR subsystem_id = ?)",
                (ip_address, subsystem_id, subsystem_id),
            )
            row = cur.fetchone()
            if row:
                return int(row[0])
            cur.execute(
                """
                INSERT INTO hosts (subsystem_id, ip_address, hostname, os_fingerprint)
                VALUES (?, ?, ?, ?)
                """,
                (subsystem_id, ip_address, hostname, os_fingerprint),
            )
            conn.commit()
            return int(cur.lastrowid)

    def store_vulnerability(self, host_ip: str, vuln_type: str, severity: str, title: str,
                            subsystem: Optional[str] = None, **details) -> int:
        subsystem_id = self.get_or_create_subsystem(subsystem) if subsystem else None
        host_id = self._get_or_create_host(host_ip, subsystem_id)
        web_finding = {
            "url": details.get("url"),
            "parameter": details.get("parameter"),
            "http_method": details.get("http_method", "GET"),
            "payload": details.get("payload"),
            "response_evidence": details.get("response_evidence"),
            "context": details.get("context"),
            "request_headers": json.dumps(details.get("request_headers", {}), ensure_ascii=False),
        }
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO vulnerabilities (
                    host_id, vulnerability_type, severity, title, description,
                    affected_component, proof_of_concept, cvss_score, cwe_id, cve_id,
                    discovered_by_skill
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    host_id, vuln_type, severity, title, details.get("description"),
                    details.get("affected_component"), details.get("proof_of_concept"),
                    details.get("cvss_score"), details.get("cwe_id"), details.get("cve_id"),
                    details.get("discovered_by_skill", "manual"),
                ),
            )
            vuln_id = int(cur.lastrowid)
            if web_finding["url"]:
                cur.execute(
                    """
                    INSERT INTO web_findings (
                        vulnerability_id, url, parameter, http_method, payload,
                        response_evidence, context, request_headers
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        vuln_id, web_finding["url"], web_finding["parameter"],
                        web_finding["http_method"], web_finding["payload"],
                        web_finding["response_evidence"], web_finding["context"],
                        web_finding["request_headers"],
                    ),
                )
            conn.commit()
            return vuln_id

    def store_sqli_vulnerability(self, host_ip: str, url: str, parameter: str, payload: str,
                                 subsystem: Optional[str] = None, **details) -> int:
        return self.store_vulnerability(
            host_ip, "sqli", details.pop("severity", "High"),
            details.pop("title", f"SQL Injection in {parameter}"), subsystem,
            url=url, parameter=parameter, payload=payload, http_method="GET",
            cwe_id=details.pop("cwe_id", "CWE-89"),
            discovered_by_skill=details.pop("discovered_by_skill", "exploit-sqli"),
            **details,
        )

    def store_xss_vulnerability(self, host_ip: str, url: str, xss_type: str, payload: str,
                                subsystem: Optional[str] = None, **details) -> int:
        return self.store_vulnerability(
            host_ip, "xss", details.pop("severity", "Medium"),
            details.pop("title", f"{xss_type.capitalize()} XSS"), subsystem,
            url=url, payload=payload, context=details.pop("context", "html_body"),
            cwe_id=details.pop("cwe_id", "CWE-79"),
            discovered_by_skill=details.pop("discovered_by_skill", "exploit-xss"),
            **details,
        )

    def store_lfi_vulnerability(self, host_ip: str, url: str, payload: str, file_read: str = "",
                                subsystem: Optional[str] = None, **details) -> int:
        return self.store_vulnerability(
            host_ip, "lfi", details.pop("severity", "High"),
            details.pop("title", "Local File Inclusion"), subsystem,
            url=url, payload=payload, response_evidence=file_read,
            proof_of_concept=details.pop("proof_of_concept", file_read or payload),
            cwe_id=details.pop("cwe_id", "CWE-98"),
            discovered_by_skill=details.pop("discovered_by_skill", "exploit-lfi"),
            **details,
        )

    def store_port_scan(self, host_ip: str, ports: List[Dict[str, Any]], scan_tool: str = "nmap",
                        subsystem: Optional[str] = None) -> None:
        subsystem_id = self.get_or_create_subsystem(subsystem) if subsystem else None
        host_id = self._get_or_create_host(host_ip, subsystem_id)
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            for p in ports:
                cur.execute(
                    """
                    INSERT OR REPLACE INTO port_scan_results
                    (host_id, port, protocol, state, service, version, product, extra_info, scan_tool)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (host_id, p.get("port"), p.get("protocol", "tcp"), p.get("state"),
                     p.get("service"), p.get("version"), p.get("product"),
                     p.get("extra_info"), scan_tool),
                )
            conn.commit()

    def get_vulnerabilities(self, subsystem: Optional[str] = None, severity: Optional[str] = None,
                            vuln_type: Optional[str] = None, host_ip: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            query = """
                SELECT v.*, h.ip_address AS host_ip, h.hostname, s.name AS subsystem_name,
                       wf.url, wf.parameter, wf.http_method, wf.payload, wf.response_evidence,
                       wf.context, wf.request_headers
                FROM vulnerabilities v
                JOIN hosts h ON v.host_id = h.id
                LEFT JOIN subsystems s ON h.subsystem_id = s.id
                LEFT JOIN web_findings wf ON v.id = wf.vulnerability_id
                WHERE 1=1
            """
            params: List[Any] = []
            if subsystem:
                query += " AND s.name = ?"; params.append(subsystem)
            if severity:
                query += " AND v.severity = ?"; params.append(severity)
            if vuln_type:
                query += " AND v.vulnerability_type = ?"; params.append(vuln_type)
            if host_ip:
                query += " AND h.ip_address = ?"; params.append(host_ip)
            query += " ORDER BY v.cvss_score DESC, v.discovered_at DESC"
            cur.execute(query, params)
            rows = [dict(r) for r in cur.fetchall()]
            for r in rows:
                if r.get("request_headers"):
                    try: r["request_headers"] = json.loads(r["request_headers"])
                    except Exception: pass
            return rows

    def get_host_summary(self, host_ip: str, subsystem: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self.db.get_connection() as conn:
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            subsystem_id = None
            if subsystem:
                cur.execute("SELECT id FROM subsystems WHERE name = ?", (subsystem,))
                row = cur.fetchone()
                if not row: return None
                subsystem_id = row[0]
            cur.execute(
                """
                SELECT h.*, s.name AS subsystem_name FROM hosts h
                LEFT JOIN subsystems s ON h.subsystem_id = s.id
                WHERE h.ip_address = ? AND (h.subsystem_id IS ? OR h.subsystem_id = ?)
                """,
                (host_ip, subsystem_id, subsystem_id),
            )
            host = cur.fetchone()
            if not host: return None
            summary = dict(host)
            cur.execute("SELECT * FROM port_scan_results WHERE host_id = ? ORDER BY port", (summary["id"],))
            summary["ports"] = [dict(r) for r in cur.fetchall()]
            cur.execute("SELECT * FROM vulnerabilities WHERE host_id = ? ORDER BY cvss_score DESC", (summary["id"],))
            summary["vulnerabilities"] = [dict(r) for r in cur.fetchall()]
            summary["open_ports_count"] = len([p for p in summary["ports"] if p.get("state") == "open"])
            summary["vuln_count"] = len(summary["vulnerabilities"])
            return summary

    def get_subsystem_statistics(self, subsystem: Optional[str] = None) -> Dict[str, Any]:
        vulns = self.get_vulnerabilities(subsystem=subsystem)
        severity = {s: 0 for s in self.SEVERITY_LEVELS}
        types: Dict[str, int] = {}
        for v in vulns:
            severity[v.get("severity", "Info")] = severity.get(v.get("severity", "Info"), 0) + 1
            t = v.get("vulnerability_type", "other")
            types[t] = types.get(t, 0) + 1
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            if subsystem:
                cur.execute("SELECT COUNT(*) FROM hosts h JOIN subsystems s ON h.subsystem_id=s.id WHERE s.name=?", (subsystem,))
            else:
                cur.execute("SELECT COUNT(*) FROM hosts")
            total_hosts = cur.fetchone()[0]
        return {"subsystem": subsystem or "all", "total_hosts": total_hosts,
                "total_vulnerabilities": len(vulns), "severity_breakdown": severity,
                "type_breakdown": types}

    def close(self):
        self.db.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def main():
    parser = argparse.ArgumentParser(description="Storage API CLI")
    parser.add_argument("--db-path", default="./data/results.db")
    parser.add_argument("--list-subsystems", action="store_true")
    parser.add_argument("--stats", nargs="?", const="all")
    parser.add_argument("--vulns")
    parser.add_argument("--host-summary")
    args = parser.parse_args()
    api = StorageAPI(args.db_path)
    try:
        if args.list_subsystems:
            print(json.dumps(api.list_subsystems(), ensure_ascii=False, indent=2))
        elif args.stats:
            print(json.dumps(api.get_subsystem_statistics(None if args.stats == "all" else args.stats), ensure_ascii=False, indent=2))
        elif args.vulns:
            print(json.dumps(api.get_vulnerabilities(severity=args.vulns), ensure_ascii=False, indent=2))
        elif args.host_summary:
            print(json.dumps(api.get_host_summary(args.host_summary), ensure_ascii=False, indent=2))
    finally:
        api.close()


if __name__ == "__main__":
    main()
