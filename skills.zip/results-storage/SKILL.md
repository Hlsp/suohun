---
name: results-storage
description: "SQLite-based persistent storage and reporting for pentest results. Use when storing findings, scan outputs, hosts, ports, web evidence, business logic cases, replay steps, or generating Markdown/JSON reports across sessions."
role: governance
domain: reporting-governance
---

# Results Storage

Use this skill when findings or recon data must persist beyond the current conversation.

## Core Model

Store evidence as structured records, not loose notes:

1. Host or subsystem context.
2. Vulnerability or lead metadata.
3. Request/response or scan evidence.
4. Severity, status, owner skill, and replay notes.
5. Report export when needed.

## Local Resources

- API details: `references/api_reference.md`
- Database schema: `references/database_schema.md`
- Integration examples: `references/integration_examples.md`
- Legacy full guide: `references/legacy-full-guide.md`
- Scripts: `scripts/storage_api.py`, `scripts/db_manager.py`, `scripts/query_builder.py`, `scripts/report_generator.py`
- Report templates: `assets/report_templates/`

## Standard Workflow

1. Choose a workspace database path before storing data.
2. Store hosts, ports, findings, and web evidence as separate records.
3. Link raw outputs by path instead of pasting large logs into records.
4. Query by severity, host, subsystem, type, status, or skill.
5. Export Markdown/JSON for handoff or reporting.

## Minimal Usage Pattern

```python
from scripts.storage_api import StorageAPI
api = StorageAPI(db_path="data/results.db")
# Store findings through the typed helper methods exposed by storage_api.py.
```

If import paths differ in the current workspace, inspect `scripts/storage_api.py` and run from the skill directory or add the script directory to `PYTHONPATH`.

## Evidence Fields to Preserve

- target, host, subsystem, endpoint, method
- account/role/tenant context
- baseline request and mutated request path
- response or state-diff proof
- severity and impact
- reproduction and cleanup notes

## Pivots

- Evidence packaging: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
- Report generation: [pentest-report](../pentest-report/SKILL.md)
- Full black-box run state: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
