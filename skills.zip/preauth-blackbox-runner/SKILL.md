---
name: preauth-blackbox-runner
description: "Second-stage no-login black-box Web/API runner for authorized targets. Use after the P0 runner selects pre-authentication testing, or when the user explicitly says 无登录黑盒, 没有账号, 只看到登录页, 未登录测试, 匿名接口测试, or 接口没结果看 JS; covers public surface mapping, anonymous APIs, frontend config exposure, JS hidden logic fallback, docs/source leaks, unauthenticated object access, registration/reset/invite flows, and login-wall bypass triage."
role: runner
domain: entry-routing
---

# Preauth Blackbox Runner

Use this as the second-stage entrypoint for black-box targets before login or when no account exists after the P0 runner selects preauth coverage. The goal is not broad scanning; it is to quickly find anonymous surfaces that can lead to data access, account takeover setup, or login-wall bypass.

## Operating Loop

1. Scope Gate: record allowed domains, paths, rate limits, exclusions, and non-destructive constraints.
2. Passive Map: open the target with MCP browser first, then collect landing pages, JS bundles, robots/sitemap, public docs, app config, static routes, and Burp/browser history.
3. Public Endpoint Inventory: normalize URLs or Burp history into workflow artifacts.
4. Preauth Triage: run the bundled triage script to rank public endpoints and candidate hypotheses.
5. JS Hidden Logic Fallback: if public endpoint probing is low-yield, switch to [preauth-js-hidden-logic-hunter](../preauth-js-hidden-logic-hunter/SKILL.md) before abandoning no-login coverage.
6. Object/Identity Extraction: when JS or traffic exposes IDs, file keys, tenant markers, or tokens, run [object-identity-extractor](../object-identity-extractor/SKILL.md) to prepare controlled follow-up tests.
7. Verify One Lead: test only one anonymous access or workflow variable at a time.
8. Pivot: if login is required, preserve the preauth baseline and switch to [auth-role-matrix-runner](../auth-role-matrix-runner/SKILL.md) after credentials exist.
9. Package: save raw evidence, derived artifacts, and replay steps.

## High-Value Preauth Targets

Prioritize:

- exposed API docs, OpenAPI, GraphQL introspection, source maps, build manifests, env files
- anonymous list/detail/export/download/preview/share endpoints
- registration, password reset, invite, SSO, OAuth callback, device binding, SMS/email code flows
- object IDs, tenant IDs, file keys, token parameters, callback URLs, redirect/return parameters
- CORS, Host header, cache, path traversal, upload preview, SSRF-like import/preview endpoints

Deprioritize:

- static marketing pages with no API or token bridge
- scanner-only findings with no reachable preauth state change
- destructive tests, brute force, or high-rate enumeration without explicit approval

## No-Login Escalation Ladder

When visible anonymous APIs do not move forward, do not keep fuzzing the same surface. Escalate in this order:

1. Re-check capture quality: make sure MCP browser has a real selected page and dynamic requests exist in browser/Burp history, not only static files.
2. Dump scoped traffic with [burp-scope-traffic-dumper](../burp-scope-traffic-dumper/SKILL.md) and dedupe endpoint shapes.
3. Mine public JS with [preauth-js-hidden-logic-hunter](../preauth-js-hidden-logic-hunter/SKILL.md): hidden routes, lazy chunks, feature flags, disabled UI, request wrappers, auth guards, source maps.
4. Compare JS endpoint candidates against Burp traffic; prioritize endpoints that are app-specific and unseen in history.
5. Extract object, tenant, user, file, share, invite, and token handles with [object-identity-extractor](../object-identity-extractor/SKILL.md).
6. Validate one lead with a baseline request plus one changed variable. If the backend cleanly requires login, keep it as an authenticated follow-up instead of expanding noisy probes.

## Scripted Triage

Use when you have URLs, raw traffic, HAR-derived JSON, or a workflow map:

```bash
python scripts/preauth_triage.py --input runs/T/raw/preauth_urls.txt --out runs/T/preauth
```

Outputs:

- `preauth_surface.json`
- `preauth_hypotheses.json`
- `preauth_surface.md`

## Routing

- Capture readiness: [capture-bootstrap-check](../capture-bootstrap-check/SKILL.md)
- Burp evidence: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Burp traffic dump: [burp-scope-traffic-dumper](../burp-scope-traffic-dumper/SKILL.md)
- Traffic mapping: [traffic-to-workflow-mapper](../traffic-to-workflow-mapper/SKILL.md)
- Dedupe/ranking: [traffic-dedupe-prioritizer](../traffic-dedupe-prioritizer/SKILL.md)
- JS hidden logic fallback: [preauth-js-hidden-logic-hunter](../preauth-js-hidden-logic-hunter/SKILL.md)
- Frontend secrets: [extract-frontend-sensitive-info](../extract-frontend-sensitive-info/SKILL.md)
- Bundled frontend map: [webpack-runtime-extractor](../webpack-runtime-extractor/SKILL.md)
- API docs: [api-recon-and-docs](../api-recon-and-docs/SKILL.md)
- Auth flows: [authbypass-authentication-flaws](../authbypass-authentication-flaws/SKILL.md)
- File/download/share: [export-preview-sharing-logic-abuse](../export-preview-sharing-logic-abuse/SKILL.md)
- Object/identity extraction: [object-identity-extractor](../object-identity-extractor/SKILL.md)
- A/B object pairs: [ab-object-pair-builder](../ab-object-pair-builder/SKILL.md)
- Evidence: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)

## Output Format

Report:

1. public surface summary
2. top anonymous endpoints or flows
3. one selected hypothesis
4. baseline anonymous request and response
5. mutation or replay performed
6. impact, confidence, and evidence paths
7. pivot: continue preauth, request credentials, or report

