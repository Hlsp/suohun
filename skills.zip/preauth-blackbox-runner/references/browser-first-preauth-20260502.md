# Browser-First Preauth 2026-05-02

For no-login black-box starts:

- browser MCP open is mandatory
- use network requests, scripts, console, and DOM before broad shell probes
- if shell and browser disagree, trust browser runtime first
