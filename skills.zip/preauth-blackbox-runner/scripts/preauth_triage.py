#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path
from urllib.parse import urlparse, parse_qsl

URL_RE = re.compile(r'https?://[^\s"\'<>]+|/(?:api|auth|login|register|reset|invite|oauth|sso|file|download|preview|export|share|graphql)[^\s"\'<>]*', re.I)
STATIC_RE = re.compile(r'\.(?:js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|map)(?:$|[?#])', re.I)
HIGH = {
    'docs': re.compile(r'swagger|openapi|api-doc|graphql|graphiql|schema|doc', re.I),
    'auth_flow': re.compile(r'login|register|signup|reset|password|invite|oauth|sso|callback|captcha|sms|email|verify|bind|device', re.I),
    'object_data': re.compile(r'user|uid|account|member|tenant|org|dept|order|invoice|task|ticket|file|doc|message|profile|admin', re.I),
    'file_flow': re.compile(r'file|upload|download|preview|export|share|attachment|oss|cos|s3|bucket', re.I),
    'bridge': re.compile(r'redirect|return|next|callback|url|uri|target|origin|host|webhook', re.I),
    'state': re.compile(r'status|state|step|stage|approve|enabled|public|delete', re.I),
    'value': re.compile(r'price|amount|fee|quota|limit|coupon|point|balance|reward', re.I),
}


def load_text(path):
    return Path(path).read_text(encoding='utf-8-sig', errors='replace')


def extract_from_json(obj):
    urls = []
    if isinstance(obj, dict):
        if 'workflows' in obj and isinstance(obj['workflows'], list):
            for w in obj['workflows']:
                if isinstance(w, dict):
                    urls.append(w.get('url') or w.get('path_template') or '')
        for k, v in obj.items():
            if k in ('url', 'href', 'requestUrl', 'path', 'path_template') and isinstance(v, str):
                urls.append(v)
            elif isinstance(v, (dict, list)):
                urls.extend(extract_from_json(v))
            elif isinstance(v, str):
                urls.extend(URL_RE.findall(v))
    elif isinstance(obj, list):
        for x in obj:
            urls.extend(extract_from_json(x))
    elif isinstance(obj, str):
        urls.extend(URL_RE.findall(obj))
    return urls


def load_urls(path):
    text = load_text(path)
    try:
        data = json.loads(text)
        urls = extract_from_json(data)
    except Exception:
        urls = URL_RE.findall(text)
        if not urls:
            urls = [x.strip() for x in text.splitlines() if x.strip() and not x.strip().startswith('#')]
    out = []
    seen = set()
    for u in urls:
        if not u:
            continue
        u = str(u).strip().strip(' ,;')
        key = u.split('#', 1)[0]
        if key not in seen:
            seen.add(key)
            out.append(u)
    return out


def score_url(u):
    parsed = urlparse(u if '://' in u else 'http://placeholder' + (u if u.startswith('/') else '/' + u))
    text = (parsed.path + '?' + parsed.query).lower()
    score = 0
    signals = []
    if STATIC_RE.search(text):
        score -= 4
        signals.append('static')
    if parsed.query:
        score += 2
        signals.append('has_query')
    params = [k for k, _ in parse_qsl(parsed.query, keep_blank_values=True)]
    for name, rx in HIGH.items():
        if rx.search(text) or any(rx.search(p) for p in params):
            score += 5 if name in ('auth_flow', 'object_data', 'file_flow') else 3
            signals.append(name)
    if re.search(r'/api/|/rest/|/graphql|/gateway|/openapi|/swagger', text):
        score += 4
        signals.append('api_surface')
    if re.search(r'\b(id|uuid|token|key|code|tenant|org|user)\b', text):
        score += 3
        signals.append('sensitive_param')
    return score, sorted(set(signals))


def hypothesis(signals):
    if 'docs' in signals:
        return 'check public API documentation, hidden operations, and anonymous access boundaries'
    if 'auth_flow' in signals:
        return 'test account recovery, invite, callback, token replay, and identity binding assumptions'
    if 'object_data' in signals:
        return 'test anonymous object ID, tenant ID, and user ID access control'
    if 'file_flow' in signals:
        return 'test anonymous file preview/download/export/share object access'
    if 'bridge' in signals:
        return 'test redirect/callback/host trust before authentication'
    if 'api_surface' in signals:
        return 'verify anonymous API access, hidden methods, and login-wall behavior'
    return 'verify whether endpoint is truly public, half-authenticated, or static noise'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    rows = []
    for u in load_urls(args.input):
        s, sig = score_url(u)
        rows.append({'url': u, 'score': s, 'signals': sig, 'hypothesis': hypothesis(sig)})
    rows.sort(key=lambda x: x['score'], reverse=True)
    hyps = [{'id': f'PREAUTH-{i:03d}', 'url': r['url'], 'score': r['score'], 'signals': r['signals'], 'hypothesis': r['hypothesis'], 'status': 'new'} for i, r in enumerate(rows, 1) if r['score'] > 0]
    (out / 'preauth_surface.json').write_text(json.dumps({'items': rows}, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'preauth_hypotheses.json').write_text(json.dumps({'items': hyps}, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Preauth Surface', '', '| Rank | Score | URL | Signals | Hypothesis |', '|---:|---:|---|---|---|']
    for i, r in enumerate(rows[:100], 1):
        lines.append(f"| {i} | {r['score']} | `{r['url']}` | {', '.join(r['signals'])} | {r['hypothesis']} |")
    (out / 'preauth_surface.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'input': args.input, 'urls': len(rows), 'hypotheses': len(hyps), 'out': str(out), 'top': rows[:5]}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
