---
name: csrf-cross-site-request-forgery
description: "CSRF testing playbook. Use when reviewing state-changing browser flows, anti-CSRF token binding, SameSite behavior, JSON or multipart CSRF, login CSRF, and OAuth state handling."
role: specialist
domain: auth-api
---

# CSRF Cross-Site Request Forgery

Use this skill when a browser-authenticated action may be triggered from another origin through ambient cookies, implicit credentials, or weak request binding.

## Core Model

CSRF requires three conditions:

1. The victim browser automatically supplies authentication.
2. The tester can construct a state-changing request.
3. The server does not require an unforgeable, action-bound, session-bound proof.

Modern CSRF hunting is mostly about broken binding: token not checked, token reusable, token not tied to action, SameSite gaps, method overrides, or content-type confusion.

## Recon Questions

- Which endpoints change state: account, payment, role, webhook, API key, device, OAuth, notification, deletion?
- Is authentication cookie-based, bearer-token-based, or mixed?
- Which cookies have `SameSite`, `Secure`, `HttpOnly`, and domain attributes?
- Are anti-CSRF tokens per request, per session, per action, or just decorative?
- Does the endpoint accept simple request content types: form, text/plain, multipart?
- Does a JSON endpoint also accept URL-encoded, multipart, GET, or method override?

## Test Families

### Missing or Decorative Token

Replay the state-changing request without the token, with a blank token, with a token from another action, and with a token from another account. The key question is whether the server checks the token, not whether the UI sends one.

### Token Binding Failure

Test whether tokens are bound to session, user, action, method, target object, and freshness. Cross-account token reuse is high signal.

### SameSite and Cookie Scope Gaps

Evaluate whether cookies are sent in top-level navigation, form POST, iframe, redirect, subdomain, or legacy-browser contexts. Do not assume SameSite protects OAuth and login flows.

### JSON and Multipart CSRF

Check whether JSON endpoints accept alternate encodings or simple content types. Multipart upload, profile update, webhook configuration, and API key creation are common high-value targets.

### Login, Logout, and Account Linking CSRF

Login CSRF and OAuth account-linking CSRF can bind the victim to the tester's identity, add a tester-controlled provider, or poison future sessions.

## Validation Ladder

1. Use two self-controlled accounts and a clean browser profile.
2. Capture a successful baseline state change.
3. Remove or mutate the CSRF proof while keeping all other fields identical.
4. Recreate the request from a separate origin or local harness.
5. Confirm state change in the victim account, not just a 200 response.
6. Test token binding only after basic absence/mutation checks.
7. Revert the state change.

## Evidence Standard

Capture:

- baseline request and successful state delta
- forged cross-origin request or harness
- cookie attributes and SameSite behavior
- token mutation matrix and server results
- before/after state proof in the victim account
- cleanup or rollback result

## Pivots

- OAuth state/account linking: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- CORS read impact: [cors-cross-origin-misconfiguration](../cors-cross-origin-misconfiguration/SKILL.md)
- XSS-assisted CSRF: [xss-cross-site-scripting](../xss-cross-site-scripting/SKILL.md)
- Business workflow impact: [business-logic-vulnerabilities](../business-logic-vulnerabilities/SKILL.md)
