﻿# SRC high-value pattern bank 2026

This is the cross-skill pattern bank for Zhang's Web/SRC workflow. It distills high-value ideas from public SRC writeups, bug-bounty methodology, API security guidance, and black-box access-control research into executable rules.

Use this file as shared operating intent for the runner and its topic skills. Do not treat it as a link collection or a generic checklist.

## Operating principle

High-value SRC work is not broad payload spraying. It is:

1. Choose a business-heavy entry.
2. Capture a clean baseline.
3. Extract identity, object, state, amount, token, and request-order variables.
4. Mutate exactly one variable.
5. Verify backend data/state impact.
6. Package a replayable evidence chain.

## Priority pattern families

### 1. Login page 0-to-1 breakthrough

When a target only shows a login page, do not stay on weak password, login wording, or generic SQLi.

Default pivot order:

1. Load runtime assets and JS chunks.
2. Extract API base paths, route tables, wrappers, tenant headers, storage keys, feature flags, and disabled actions.
3. Check reset, register, invite, magic-link, SSO callback, and account-binding endpoints.
4. Look for Swagger/OpenAPI/GraphQL/schema docs and versioned base paths.
5. Expand to edge assets only after the main app gives no useful flow.

Reportable outcomes require live backend behavior: anonymous data, hidden API access, token/session issuance, account binding impact, or sensitive docs/config exposure.

### 2. JS hidden API and parameter mining

Frontend code is a hypothesis generator. It is useful only when it leads to replayable requests.

Extract:

- unseen endpoint strings and lazy routes
- request wrapper call sites
- permission arrays, menu metadata, role guards, gray/beta switches
- body builders and serializer methods
- enum names, status fields, hidden writable properties
- storage/token/header/signature lineage

Use discoveries in this order:

1. endpoint existence and auth boundary
2. BOLA object swap
3. BOPLA/mass-assignment property injection
4. workflow state mutation
5. file/export/share pivots

### 3. BOLA and BOPLA separation

Never collapse everything into IDOR.

- BOLA: can this identity access or mutate this object?
  - keys: `id`, `userId`, `uid`, `ownerId`, `tenantId`, `orgId`, `fileId`, `orderId`, `taskId`, `entry`, `nodeId`
- BOPLA / mass assignment: can this identity read or set a protected property?
  - keys: `role`, `roles`, `isAdmin`, `status`, `state`, `auditStatus`, `price`, `amount`, `quota`, `plan`, `balance`, `discount`, `ownerId`, `tenantId`
- BFLA: can this identity call a function that its role should not have?
  - actions: `approve`, `export`, `delete`, `refund`, `bind`, `invite`, `admin`, `impersonate`, `callback`

Always verify with a re-read or visible state/data proof.

### 4. Business response-field diff

HTTP status code is not enough. Compare business fields after normalization:

- `code`, `msg`, `success`, `status`, `state`, `result`, `errorCode`
- `userId`, `uid`, `openid`, `unionid`, `tenantId`, `orgId`, `role`, `permissions`
- `token`, `ticket`, `sid`, `session`, `csrf`, `nonce`, `traceId`
- `amount`, `price`, `qty`, `discount`, `balance`, `points`, `quota`, `plan`
- `auditStatus`, `approvalStatus`, `step`, `workflowId`, `taskId`, `entry`

Strong findings usually show one of:

- more data than baseline
- different object ownership
- state transition
- session/token issuance
- quota/amount/reward change
- generated file/link/token usable outside expected boundary

### 5. Payment, promo, membership, and finance chains

Default chain model:

1. eligibility / KYC / account state
2. quote / price / discount / coupon calculation
3. order creation
4. payment or callback confirmation
5. delivery / membership / quota / reward issuance
6. cancel / refund / revoke
7. reuse / race / replay

High-value tests:

- client-trusted amount or discount
- coupon/giftcard/points stacking
- repeated claim/redeem/callback
- cancel/refund does not revoke benefit
- trial/member downgrade keeps quota
- parallel order or reward issuance
- currency/rounding/negative/zero/overflow boundaries

### 6. Password reset, invite, binding, and delegation

Model tokens by binding and lifecycle:

- bound to which user, tenant, device, email/phone, action, and session?
- usable before/after verification?
- single-use or reusable?
- expires on password/email/phone/account-state changes?
- works across app, H5, miniapp, admin, or API endpoints?

High-value pivots:

- reset token swapped to another account
- invite accepts a higher role or different tenant
- binding flow changes someone else's email/phone/social account
- act-as/delegation token not scoped to target user/object
- partial-login session accesses APIs before MFA completion

### 7. Enterprise/OA/portal/supplier workflow

Prioritize:

- org/department/role/user boundary
- approval/task/process/form objects
- attachments, exports, contract/invoice/report files
- supplier/customer separation
- search/recent/favorite/recycle-bin hidden writes
- iframe/jumpLink/thirdUrl/token bridge handoffs

Evidence should show the business object owner, the acting identity, and the exact workflow or file state crossed.

### 8. Upload and import as multi-stage pipelines

Do not stop at extension/MIME.

Map:

1. accept: extension, MIME, magic, client rules
2. store: filename, object key, tenant isolation, overwrite
3. process: converter, OCR, archive, AV, thumbnail, async job
4. retrieve: preview, download, share, content-type, public URL
5. post-process: generated reports, parsed rows, imported records, callbacks

High-value paths:

- async parser reads sensitive file or triggers SSRF/XXE/CMDi
- archive slip or object key overwrite
- stored active content from preview/download
- imported rows create unauthorized objects
- race window between upload, validation, processing, and retrieval

### 9. Miniapp/APP/API convergence

Miniapp or APP reverse engineering is only valuable when it produces replayable API knowledge:

- wrapper, signature, encryption, token, device, appid/openid/unionid lineage
- page method -> request mapping
- object/tenant/status/amount variables
- hidden routes and disabled actions

After reconstruction, use the same A/B object, BOPLA, workflow, payment, and file/export tests as Web.

### 10. Cache, gateway, parser, and framework discrepancy

Only enter this lane when a cache/proxy/gateway/framework signal exists.

Test one discrepancy at a time:

- path normalization, delimiter, encoded slash/dot, static extension, route suffix
- duplicate parameters and mixed JSON/form/multipart
- content-type switch
- Host/X-Forwarded-* trust
- Unicode/charset normalization
- framework middleware bypass headers
- Java low-byte / Ghost Bits variants on Java/JVM targets

Do not report parser-diff alone. Require auth/data/state impact or cache leakage.

## Daily runner decision bias

When multiple paths are possible, choose in this order:

1. anonymous data/object/file exposure
2. authenticated BOLA/cross-tenant read/write
3. BOPLA/mass assignment/property mutation
4. workflow/payment/account recovery state abuse
5. file/export/share/token bridge exposure
6. upload/import/report job to read/write/RCE/SSRF
7. frontend/miniapp crypto reconstruction enabling replay
8. cache/parser/framework discrepancy with proven impact
9. classic injection only when a realistic sink and impact path exists

## Evidence minimum

Every high-value candidate needs:

- baseline request and baseline state
- mutated request with exactly one changed variable
- response diff after volatile-field normalization
- backend data/state/session/token/file proof
- identity/object ownership context
- cleanup/rollback note when state was changed
- concise reproduction path
