# High-imagination hypothesis bank

Use this only after the standard baseline exists. The goal is not more payloads; it is better hypotheses from observed primitives.

## Rule

Every creative idea must be grounded in at least one observed primitive and must define a cheap decisive probe.

```text
OBSERVED_PRIMITIVES:
CHAIN_IDEA:
ONE_PROBE:
EXPECTED_HIGH_SIGNAL:
ABANDON_IF:
```

## Primitive mixer

Combine primitives across boundaries:

- encrypted response decryptor + list endpoint -> offline object corpus -> targeted BOLA
- signed file URL + upload token -> file-key swap -> cross-user file read
- object-existence oracle + sequential/numeric ids -> targeted discovery -> detail/action replay
- route chunk + hidden method -> backend endpoint not exposed in UI -> BFLA
- tenant id in storage + list filter -> cross-tenant read/write check
- role name in storage + backend action endpoint -> frontend gate bypass vs real auth
- status field + action endpoint -> out-of-order approval/cancel/urge/revoke
- refresh token/captcha key/device id + OAuth endpoint -> token lifecycle or session confusion
- upload response + later form submit -> stored object attached to privileged workflow
- error route/upstream host leak + gateway auth -> direct backend replay
- timestamp/signature/signed URL + replay window -> stale link reuse or expiry bypass
- file retrieval endpoint + content-disposition/type -> active-content downgrade/upgrade or same-origin confusion

## Weird-but-cheap probes

### 1. Decrypted list corpus before ID guessing

- Probe: bulk-decode the latest list/search responses and extract all `id`, `status`, `owner`, `tenant`, `phone`, `file`, `url`, and `token` fields.
- High signal: real object IDs, hidden statuses, other-person data, reusable file links, or fields absent from UI.
- Abandon if: list is empty and no search/filter/history endpoint exists.

### 2. Object id to action endpoint

- Probe: take a real owned object ID from list and replay safe action endpoints (`detail`, `urge`, `cancel`, `delete`, `export`, `share`) one at a time.
- High signal: action succeeds despite state/UI restriction, or endpoint returns sensitive fields not shown by UI.
- Abandon if: all actions require matching state and return structured deny without side effect.

### 3. File token swap

- Probe: replace a file URL/key/name returned by upload with another observed file key or with the same key minus/altered signature in exactly one retrieval or form-submit request.
- High signal: file content readable across object/user boundary, signature not bound to key/user, or accepted attachment to another workflow.
- Abandon if: signature is strongly bound and unsigned access returns stable deny.

### 4. Tenant/role storage mismatch

- Probe: change only tenant/role/org request field if it is sent by client, not localStorage display-only values.
- High signal: list/detail/action crosses tenant/org/role boundary or response fields reveal backend accepted the client-controlled identity.
- Abandon if: field is ignored or server derives identity from token.

### 5. Hidden route backend truth

- Probe: from route chunks, call the method behind a hidden page with current token, even if UI gate is false.
- High signal: backend accepts visitor token for admin/approval/export/import endpoint.
- Abandon if: backend returns real `401/403` and no alternate action route exists.

### 6. State machine out-of-order

- Probe: replay a state action with a real ID whose status should not allow that action, changing no other field.
- High signal: status changes, notification fires, approval/urge/cancel succeeds, or readback shows state drift.
- Abandon if: structured business error names the exact invalid state and readback is unchanged.

### 7. Expiry and replay windows

- Probe: replay an old signed URL/token/action after logout/expiry, then vary only timestamp/expire if client-controlled.
- High signal: stale link still works, signature is not bound to user/session/time, or expiry is trusted from client.
- Abandon if: server rejects stale and tampered timestamps consistently.

### 8. Rejected upload residue

- Probe: after a rejected upload, search Burp history/response for generated object keys, temporary paths, thumbnails, or parser errors; try only the returned path/key.
- High signal: rejected file leaves retrievable temporary object, metadata, or processor output.
- Abandon if: no server-side key/path is emitted and no async processor endpoint exists.

### 9. OAuth/token side door

- Probe: compare token, refresh, captcha, tenant, clientSecret, and grant_type flows; mutate only grant_type or tenant when the UI already sends those fields.
- High signal: token issued for wrong tenant/role, refresh works without session binding, or clientSecret enables unintended grant.
- Abandon if: structured auth errors are stable and no alternate grant endpoint exists.

### 10. Error-as-routing-oracle

- Probe: cause one malformed object/file/path value and inspect decrypted business error for backend route/class/upstream hints.
- High signal: upstream URL, internal route, token, SQL/table/entity name, or object type leak that enables targeted endpoint replay.
- Abandon if: generic error only and no difference across controlled malformed values.

## Visitor-appointment style ideas

For a visitor/appointment app with `visitor/list`, `detail`, `urgeApproval`, `saveVisitorInfo`, upload, encrypted responses, tenant id, and role `visitor`:

- Decode `visitor/list` first, then test whether `detail` returns more PII than the list.
- Search JS for approval/admin/export endpoints not visible to visitor role, then call with visitor token.
- Use real uploaded `visitorPhoto` URL/key in `saveVisitorInfo` and test whether attachment belongs to current user or only URL string is trusted.
- If a real `visitedPerson + visitedPhone` appears in any decoded response, use it to test unauthorized appointment creation.
- Treat `urgeApproval` as a notification/write primitive: first prove self-object side effect, then test cross-object only with real IDs.
- Test signed image URL replay after token logout/expiry; if it still works, assess whether signature is file-bound, user-bound, and time-bound.

