# Default skill chains

## Default skill chains

### No-login black-box single URL

Use when only a URL/login page is provided.

```text
zhang-web-src-default-runner
-> java-third-party-component-hunter when Java/component clues exist
-> security-test-dispatcher
-> blackbox-pentest-runner
-> browser-pentest-orchestrator
-> java-component-poc-router when a component family is plausible and local PoCs can sharpen the route
-> preauth-js-hidden-logic-hunter when endpoint probing is low-yield
-> extract-frontend-sensitive-info / webpack-runtime-extractor / request-chain-tracer as needed
```

High-value first pass:

- public list/detail/download chains
- exposed docs/source/config/routes
- API docs/base-path/version/schema clues, including Swagger/OpenAPI/GraphQL-like metadata
- hidden anonymous APIs in JS bundles
- file preview/export/download endpoints
- registration/reset/invite/token bridge flows
- login-page 0-to-1 pivot: JS/API -> reset/register/invite -> docs/config -> edge assets, instead of staying on weak password or generic SQLi
- CORS/open redirect only if it leads to auth/data impact

### Logged-in black-box / A-B accounts

Use when credentials, cookies, roles, tenants, or multiple accounts exist.

```text
zhang-web-src-default-runner
-> blackbox-pentest-runner
-> auth-role-matrix-runner
-> object-identity-extractor
-> ab-object-pair-builder
-> traffic-to-workflow-mapper
-> single-variable-replay-harness
-> logic-evidence-pack
```

Default tests:

- object ID swap, tenant/org/department swap, role downgrade/upgrade boundaries
- BOLA and BOPLA separately: object access first, then property/mass-assignment mutation
- business response-field diff: compare `code`, `msg`, `status`, `state`, `role`, `ownerId`, `openid`, `token`, `auditStatus`, and not only HTTP status
- workflow state mutation, replay, stale link/token reuse
- export/share/recycle-bin/recent/favorite hidden actions
- payment/coupon/membership/approval/admin control-plane logic when present

If only one account is available, run a **single-account object-chain mode** before asking for A/B fixtures:

1. Dump the latest authenticated traffic from browser/Burp.
2. Decode/decrypt responses if the frontend can render them.
3. Extract real owned object IDs from list/search endpoints.
4. Replay `list -> detail -> action/write` with the same account to prove baseline.
5. Only then test sibling IDs, historical IDs, tenant/org fields, or state-action endpoints.

Do not report `500` on guessed IDs as BOLA. Treat it only as an object-chain candidate until a real existing object shows cross-owner data or unauthorized state change.

### Java/JVM website default

Use when Java clues appear: `JSESSIONID`, Spring/Tomcat/Struts/Shiro/JSP errors, `.do`, `.action`, `/actuator`, Java stack traces, GeoServer-like endpoints, Maven/Gradle artifacts, or obvious Java API naming.

```text
zhang-web-src-default-runner
-> ghost-bits-java-truncation
-> relevant impact skill: upload-insecure-files / path-traversal-lfi / crlf-injection / request-smuggling / deserialization-insecure / sqli-sql-injection / cmdi-command-injection / ssti-server-side-template-injection
-> single-variable-replay-harness
```

Rule: generate 1-3 Ghost Bits variants for each high-value candidate payload, but only report when backend semantics or byte-view divergence is proven.

### Frontend crypto/signature/reverse

Use when requests include `data`, `key`, `result`, `sign`, encrypted body, anti-debugging, request wrappers, or login encryption.

```text
zhang-web-src-default-runner
-> browser-pentest-orchestrator
-> complex-js-reverse
-> request-chain-tracer
-> find-crypto-entry
-> webpack-runtime-extractor
-> protocol-diff-lab
-> browser-crypto-helper-builder
```

Default path: capture real request -> get initiator/wrapper -> recover sign/encrypt/decrypt path -> produce runnable artifact: single HTML, interactive script, or offline raw HTTP generator.

For response-encrypted apps, prioritize a **bulk response decoder** as soon as one response is proven decryptable. Feed decoded `list`, `detail`, and business-action responses into `object-identity-extractor`; this is usually higher value than continuing UI probing or blind ID fuzzing.

### Mini-program

Use when user provides WeChat remote-debugging CDP ws/devtools URL, wxapkg, or decompiled source.

```text
zhang-web-src-default-runner
-> miniapp-dynamic-static-runner
-> wechat-miniapp-cdp-debug
-> request-chain-tracer
-> object-identity-extractor
-> auth-role-matrix-runner if accounts/roles exist
```

Correlate runtime network traffic with static page methods, storage, tokens, wrappers, routes, and object IDs.

### Burp/Yak/MCP traffic-driven testing

Use traffic as source of truth when available.

```text
zhang-web-src-default-runner
-> capture-bootstrap-check
-> burp-mcp-playbook / yak-mcp-playbook
-> burp-scope-traffic-dumper / traffic-to-workflow-mapper
-> traffic-dedupe-prioritizer
-> blackbox-business-logic-hunter
-> single-variable-replay-harness
```

If MCP health is questioned, do a minimal live probe first; empty resource lists do not prove failure.

When browser MCP page selection is unstable, use Burp history as the authoritative request log and use browser runtime only for storage, route, and crypto helper extraction. Do not lose time debating whether the browser page can be rediscovered if the authenticated traffic already exists.
