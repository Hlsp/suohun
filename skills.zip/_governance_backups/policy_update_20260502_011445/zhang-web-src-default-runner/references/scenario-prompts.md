﻿# Scenario prompt templates

这些模板用于把你的日常任务快速落到 `zhang-web-src-default-runner`。不要合并成一个大而泛的提示；按场景复制后补齐目标、账号、流量或路径。

默认要求：执行时自动应用 `src-high-value-pattern-bank-2026.md` 中的高价值模式，不需要向用户展示文章列表。

如果是真实目标且会持续测试，请先创建或复用运行目录，并在每轮输出中带上 `RUN_DIR / BASELINE / VARIABLE / DIFF / NEXT`。

## 1. 黑盒不可登录：只有一个 URL

```text
目标：<URL>
场景：黑盒不可登录，只有一个 URL / 登录页。
请使用 $zhang-web-src-default-runner，按我的默认 Web/SRC 策略推进：优先浏览器/运行时证据和真实请求链，不要停留在低危配置噪声。
重点找匿名对象读取、公开 list-detail-download 链、隐藏 API、前端 bundle 中的接口/签名/密钥/调试信息、文件下载/预览/导出、注册/找回/邀请等高价值入口。
如果目标疑似 Java/JVM，默认启用 $ghost-bits-java-truncation 作为 payload 绕过分支。
每轮输出：当前证据、单变量变更、响应/状态差异、下一步和可复现请求。
```

## 2. 黑盒可登录 / 有账号

```text
目标：<URL>
账号/角色/租户：<账号 A/B、角色、租户、cookie/token 说明>
场景：黑盒可登录。
请使用 $zhang-web-src-default-runner，优先构建 A/B 账号与对象矩阵，提取 userId/orgId/tenantId/fileId/orderId/taskId 等对象标识。
按单变量方式测试 BOLA/IDOR、跨租户、越权写、对象属性/批量赋值、流程状态篡改、导出/分享/下载、审批/任务中心/管理后台等高价值逻辑漏洞。
保留 baseline、mutated request、响应 diff、前后状态和清理步骤。只把有服务端影响的结果进入报告。
```

## 3. 小程序远程调试 + 反编译目录

```text
目标：微信小程序
远程调试 CDP/ws 地址：<ws/devtools URL>
反编译目录：<path>
账号/角色：<如有>
请使用 $zhang-web-src-default-runner，走 miniapp 动静结合：先抓运行时网络、storage、token、页面方法，再和反编译源码中的 request wrapper、签名/加密、路由、对象 ID 对齐。
优先找越权、隐藏 API、文件/图片/附件、订单/钱包/积分/审批/任务流等高价值业务逻辑问题。
输出真实请求链、关键对象/身份边界、单变量 replay 模板和证据包。
```

## 4. Java 网站专项

```text
目标：<URL 或 raw HTTP>
场景：疑似 Java/JVM 网站。
请使用 $zhang-web-src-default-runner，并默认启用 $ghost-bits-java-truncation。
对上传、路径穿越、CRLF/Header、SQLi/CMDi/SSTI/EL、反序列化/JNDI 等高价值候选 payload 生成 1-3 个 Ghost Bits 变体，单变量验证。
只把有后端语义证据、低 8 位视图差异、状态变化、文件/命令/数据读取影响的结果纳入报告；不要报告纯 WAF 绕过。
```

## 5. 前端加密/签名逆向

```text
目标：<URL / bundle / raw request>
场景：前端请求存在加密、签名、data/key/result/sign、验证码/登录封装或响应加密。
请使用 $zhang-web-src-default-runner，优先动态运行时 tracing：抓真实请求 -> 找 request initiator -> 定位 interceptor/wrapper/crypto entry -> 差分协议字段 -> 产出可运行工具（单文件 HTML、交互式脚本或离线 raw HTTP 生成器）。
不要只做静态解释；最终要能复现生成签名/密文/请求体。
```

## 6. API 文档 / OpenAPI / Swagger 暴露

```text
目标：<URL 或文档地址>
场景：发现 Swagger/OpenAPI/GraphQL/schema/API docs。
请使用 $zhang-web-src-default-runner，把文档当作攻击面地图而不是结论：提取 base path、版本、模型字段、方法、content-type、鉴权要求和废弃接口。
优先测试 BOLA（对象级）、BOPLA/批量赋值（属性级）、BFLA（功能级）和版本/租户边界。
对读写接口做单字段回灌：从响应字段和 schema 中选择 role/isAdmin/ownerId/tenantId/status/price/quota/plan 等候选字段，每次只加一个字段，最后重新 GET 验证服务端状态。
```

## 7. Burp/Yak 流量驱动

```text
目标：<范围说明>
流量来源：<Burp/Yak/MCP/导出的 HTTP history>
场景：已有真实流量。
请使用 $zhang-web-src-default-runner，先去重和归类：list/detail/create/update/delete/export/share/approve/bind/invite/pay/refund/admin。
按业务对象和身份边界建立 replay 队列，不要盲目扫 payload。
每次只变更一个维度：对象、租户、角色、状态、token、金额、时间、header、content-type、path 或请求顺序。
```

## 8. 缓存 / 解析差异专项

```text
目标：<URL 或 raw HTTP>
场景：怀疑 CDN/cache/proxy/WAF/origin 存在解析差异，或 GET/HEAD 接口返回私有数据。
请使用 $zhang-web-src-default-runner，走缓存/解析差异专线：先证明 cache 信号和动态敏感响应，再测试静态扩展、静态目录、文件名、分隔符、编码、路径规范化、重复参数、content-type 切换等单变量差异。
不要报告纯差异；必须证明缓存泄露、鉴权绕过、后端语义变化或可复现的数据/状态影响。
```
