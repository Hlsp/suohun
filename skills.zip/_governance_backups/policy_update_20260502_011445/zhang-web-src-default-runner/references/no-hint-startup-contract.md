# No-hint URL startup contract

## No-hint URL startup contract

When the user gives **only a URL** or says “自己找”“没有提示”“黑盒网站”，do not jump straight into payload guessing.

Mandatory order:

1. **Business shape first**
   - identify whether the site looks like:
     - portal / OA / admin
     - API shell
     - file platform
     - upload/preview/export workflow
     - shop/order/payment flow
     - third-party component/admin console
     - login shell with hidden JS routes
2. **Runtime truth second**
   - open with browser MCP when possible
   - inspect:
     - page snapshot
     - network requests
     - console
     - same-origin `fetch` probes for likely endpoints
3. **Component inference third**
   - if Java clues exist, route through:
     - `java-third-party-component-hunter`
     - then `java-component-poc-router`
   - do not broad-spray PoCs before a component family is plausible
4. **One narrow PoC lane fourth**
   - choose the best-fitting detector/verify/exploit lane
   - prove one path before expanding

If the first turn after a bare URL does not produce either:

- business model clues,
- component clues,
- or a concrete endpoint/method/content-type matrix,

then the run is off track.

### No-hint first-turn minimum outputs

After a bare URL, the answer must include:

```text
SITE_SHAPE:
RUNTIME_CLUES:
LIKELY_COMPONENTS:
HIGH_VALUE_FEATURES:
FIRST_DETECTOR_OR_POC_LANE:
NEXT_DECISIVE_PROBE:
```

### No-hint anti-patterns

Do not do these first:

- CVE spraying without component evidence
- generic SQLi/XSS payload dumping
- huge dir brute-force before route/business clues
- treating a Whitelabel 404 shell as “nothing there”
- ignoring JS/runtime and only using curl guesses

### Java component + local PoC rule

If Java clues and component hints appear, the default sequence is:

```text
runtime clue
-> java-third-party-component-hunter
-> shortlist component family
-> java-component-poc-router
-> detect-only PoC
-> behavioral verify PoC
-> exploit PoC
```

This is mandatory for:

- Fastjson
- Shiro
- Struts
- Druid
- Nacos
- GeoServer
- Solr
- Jolokia
- Swagger/Knife4j
- Spring management/module families
