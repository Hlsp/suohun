# Legacy Full Entry Router 2026-05-01

This preserves the pre-optimization detailed router body for lookup. Prefer `SKILL.md` plus focused references for normal use.

﻿---
name: zhang-web-src-default-runner
description: Personal high-priority Web/SRC vulnerability hunting entry skill for Zhang. Use when the user says 开始测试, 开始挖, 挖洞, 漏洞挖掘, Web安全, SRC, 逻辑漏洞, 黑盒测试, 帮我测一下, 自己选择skills, 按我的默认策略, 不要低危, Java站, 前端逆向, 小程序远程调试, Burp/Yak/MCP 流量, or provides a target URL/app and wants Codex to choose the right skills and drive the assessment. Routes to black-box no-login, logged-in A/B role testing, frontend JS reverse, Java Ghost Bits bypass, API/auth/business logic, file/upload/RCE, mini-program, evidence packaging, and reporting workflows.
metadata:
  short-description: Zhang Web/SRC default entry router
---

# Zhang Web/SRC Default Runner

This is the user's personal top-level entry skill for authorized Web/SRC, logic-vulnerability, frontend-reverse, Java-bypass, CTF/web-lab, and browser/Burp/Yak-assisted work.

## Non-negotiable defaults

- Reply in Simplified Chinese. Be direct, technical, and evidence-first.
- Pick the relevant skills yourself; do not ask the user to manually choose when the scene is inferable.
- Treat an authorized target as a mission to understand the business and drive the test autonomously. Do not wait for the user to issue every next step after login, upload, navigation, or a single failed probe.
- Prioritize high-impact findings: anonymous object/data access, file download/preview/export leaks, upload/import/report/job-to-RCE chains, auth/BOLA/tenant boundary breaks, workflow state abuse, token bridge misuse, hidden high-risk APIs, and Java parser/WAF bypass routes.
- Avoid spending time on low-value noise: generic login error wording, banner/header trivia, clickjacking without sensitive action, scanner-only results, or unproven WAF bypass.
- Prefer live runtime evidence over static guesses: browser/Burp/Yak traffic, request initiators, storage/cookies, real request bodies, and response diffs.
- Test one variable at a time. Keep baseline request, mutated request, response diff, state change, and cleanup step.
- If the user says “继续”, continue the current evidence chain; do not restart methodology.
- If the target is Java/JVM or likely Java, enable `ghost-bits-java-truncation` as a bounded payload-bypass lane by default.
- If the target is Java/JVM or likely Java and the exact component is unknown, run `java-third-party-component-hunter` before deep exploit attempts, then use `java-component-poc-router` to map confirmed clues to local PoCs under `Z:\pocs`.
- If request signing/encryption exists, recover the request wrapper dynamically before replaying.
- For logged-in encrypted SPAs, do not blind-fuzz IDs before extracting real object IDs from decrypted list/detail responses. First build: traffic slice -> decrypt helper -> object map -> one-variable replay.
- Apply the cross-suite high-value pattern bank from `references/src-high-value-pattern-bank-2026.md`: login-page 0-to-1 pivot, JS hidden API mining, BOLA/BOPLA separation, business response-field diff, payment/reset/portal/upload pipeline modeling, and cache/parser discrepancy only with impact.
- Before abandoning a target as "no high risk", force one creativity pass from `references/high-imagination-hypothesis-bank.md`. Pick 3 weird-but-plausible chains that connect observed features across boundaries, then test only the cheapest decisive probe for each.

## Immediate startup behavior

When triggered:

1. Infer the scene: no-login black-box, logged-in black-box, mini-program, frontend crypto/reverse, Java/JVM target, Burp/Yak traffic-driven, source/code-audit, or report/evidence.
2. Announce one short skill chain, not a long checklist.
3. Establish the first live baseline: browser page, Burp/Yak history, raw request, source entrypoint, or mini-program CDP page.
4. Select one high-value hypothesis and one decisive next action.
5. Create or reuse a run directory when the work will last more than one turn or produce replay evidence.
6. Save artifacts when replay/evidence will matter.

Use `references/live-run-protocol.md` as the execution contract. Do not stay in theory mode when a target, account, traffic sample, browser page, raw request, miniapp CDP target, or source entrypoint is available.

If a previous run drifted or stalled, read `references/postmortem-encrypted-logged-in-spa-20260430.md` before resuming. It captures the failure modes from the visitor-appointment target: missing early run directory, late bulk response decryption, blind ID guessing before real object extraction, over-investing in upload after negative validation, and underusing Burp history as the traffic source of truth.
If the target is no-hint black-box or the first lane fails, read `references/pivot-rules-no-hint-blackbox.md` and pivot by evidence instead of repeating weaker guesses.

## No-hint URL startup contract

When the user gives **only a URL** or says “自己找”“没有提示”“黑盒网站”，do not jump straight into payload guessing.

Mandatory order:

1. **Business shape first**
   - identify whether the site looks like:
     - portal / OA / admin
     - API shell
     - file platform
     - upload/preview/export workflow
     - shop/order/payment flow
     - third-party component/admin console
     - login shell with hidden JS routes
2. **Runtime truth second**
   - open with browser MCP when possible
   - inspect:
     - page snapshot
     - network requests
     - console
     - same-origin `fetch` probes for likely endpoints
3. **Component inference third**
   - if Java clues exist, route through:
     - `java-third-party-component-hunter`
     - then `java-component-poc-router`
   - do not broad-spray PoCs before a component family is plausible
4. **One narrow PoC lane fourth**
   - choose the best-fitting detector/verify/exploit lane
   - prove one path before expanding

If the first turn after a bare URL does not produce either:

- business model clues,
- component clues,
- or a concrete endpoint/method/content-type matrix,

then the run is off track.

### No-hint first-turn minimum outputs

After a bare URL, the answer must include:

```text
SITE_SHAPE:
RUNTIME_CLUES:
LIKELY_COMPONENTS:
HIGH_VALUE_FEATURES:
FIRST_DETECTOR_OR_POC_LANE:
NEXT_DECISIVE_PROBE:
```

### No-hint anti-patterns

Do not do these first:

- CVE spraying without component evidence
- generic SQLi/XSS payload dumping
- huge dir brute-force before route/business clues
- treating a Whitelabel 404 shell as “nothing there”
- ignoring JS/runtime and only using curl guesses

### Java component + local PoC rule

If Java clues and component hints appear, the default sequence is:

```text
runtime clue
-> java-third-party-component-hunter
-> shortlist component family
-> java-component-poc-router
-> detect-only PoC
-> behavioral verify PoC
-> exploit PoC
```

This is mandatory for:

- Fastjson
- Shiro
- Struts
- Druid
- Nacos
- GeoServer
- Solr
- Jolokia
- Swagger/Knife4j
- Spring management/module families

## First-10-Minute Routing Contract

When the user gives a target, do not start with generic vulnerability classes. Spend the first cycle routing and collecting decisive runtime facts:

```text
0-2 min: classify target mode
  no-login | logged-in | encrypted SPA | upload/import | workflow/approval | Java/JVM | miniapp | source-audit | traffic-driven

2-5 min: choose exactly two lanes
  LANE_A = most likely high-impact chain from observed behavior
  LANE_B = weird/combinational chain from high-imagination bank

5-10 min: produce one hard artifact
  Burp/HAR traffic slice, route->endpoint map, decrypt helper, object map, upload pipeline map, token/tenant map, or one replay diff
```

If the first answer after a target is only a checklist, it is a failed start. It must contain:

```text
MODE:
WHY:
SKILLS:
LANE_A:
LANE_B:
FIRST_ARTIFACT:
DECISIVE_TEST:
```

## Lane selection rules

- If logged in and API exists: lane A is object/workflow authorization; lane B is hidden route/action or token/tenant confusion.
- If encrypted response exists: lane A is decrypt -> object corpus; lane B is exposed key -> offline data mining or cross-endpoint replay.
- If upload exists: lane A is upload pipeline; lane B is file token/key reuse in business forms, not extension fuzzing.
- If approval/workflow exists: lane A is state/action replay; lane B is out-of-order action, notification primitive, or hidden admin chunk.
- If Java/JVM clues exist: lane A is high-impact endpoint mapping; lane B is parser discrepancy/Ghost Bits only on a concrete sink.
- If only login page exists: lane A is JS/API hidden surface; lane B is reset/register/invite/docs/edge assets.

Every lane must name the exact signal that would make it high-impact. No lane may exist only because a vulnerability category is popular.

## Autonomous Business Understanding Contract

After a target is available, build and update a business model without waiting for user prompts:

```text
BUSINESS_MODEL:
  actors: visitor/user/admin/approver/operator/tenant/external person
  assets: records/files/tokens/appointments/approvals/messages/profiles
  workflows: create/list/detail/update/approve/cancel/urge/export/share/upload
  trust_boundaries: owner/tenant/role/status/file/session/time
  invariants: who may perform which action on which object in which state
```

The test is not done after one page or one endpoint. Continue moving through:

```text
route map -> workflow map -> object map -> trust-boundary map -> hypothesis queue -> replay evidence
```

Default autonomous progression:

1. If the user logs in, immediately inventory storage, routes, and recent traffic.
2. If the user navigates to a page, map the page's business purpose, actors, objects, and state transitions.
3. If the user performs an action, capture baseline traffic and identify object IDs, status fields, file keys, tenant/role fields, and tokens.
4. If one probe fails, pivot to the next recorded hypothesis; do not stop unless blocked by missing auth, destructive risk, or no remaining high-impact hypothesis.
5. If a workflow has list/detail/action, always try to close the full chain before switching feature areas.
6. If the user says nothing after providing the target, continue with the next safest high-signal action and report compact progress.

Stop only when:

- a high-impact finding is proven and packaged,
- all high-impact lanes have recorded negative evidence,
- credentials/session/user action is required,
- further testing would be destructive without approval.

When stopping, say exactly what blocks progress and the next single action needed.

## Cross-suite high-value defaults

These defaults should influence every downstream skill, not just this entry router:

- Login page stuck -> pivot to JS/API, reset/register/invite, docs/schema, and edge assets.
- API found -> separate BOLA object access, BOPLA property mutation, and BFLA function access.
- Business flow found -> model invariants: who can do what, to which object, in which state, at what amount/quota, and in what order.
- JS/miniapp/APP reverse -> produce replayable wrapper/signature/encryption knowledge, then return to object/property/workflow testing.
- Upload/import/export -> model full pipeline: accept, store, process, retrieve, share/export, async job.
- Payment/membership/reward -> test quote, order, callback, fulfillment, cancel/refund, reuse, race, and downgrade/revoke.
- Parser/cache/framework discrepancy -> report only when it crosses auth, data, state, or cache boundaries.

## Creativity pass before giving up

When standard tests produce only low/medium candidates, do not simply summarize failure. Run this pass:

1. List observed primitives, even if weak: encrypted response decrypt, signed file URL, upload token, route param, object id error, captcha, refresh token, tenant id, role name, hidden endpoint, timestamp, bridge URL, status code oracle.
2. Combine two or three primitives into cross-boundary hypotheses: token -> file, file -> object, object -> workflow action, JS key -> offline corpus, tenant -> list filter, status -> action replay, route -> hidden chunk, error -> upstream route.
3. Pick three "weird but cheap" probes. Each must have one request/action and one decisive expected signal.
4. Execute the cheapest probe first. If all three fail, record abandon reasons and only then report no high-risk finding.

Do not confuse creativity with noisy fuzzing. The pass should increase hypothesis quality, not request volume.

## Default skill chains

### No-login black-box single URL

Use when only a URL/login page is provided.

```text
zhang-web-src-default-runner
-> java-third-party-component-hunter when Java/component clues exist
-> security-test-dispatcher
-> blackbox-pentest-runner
-> browser-pentest-orchestrator
-> java-component-poc-router when a component family is plausible and local PoCs can sharpen the route
-> preauth-js-hidden-logic-hunter when endpoint probing is low-yield
-> extract-frontend-sensitive-info / webpack-runtime-extractor / request-chain-tracer as needed
```

High-value first pass:

- public list/detail/download chains
- exposed docs/source/config/routes
- API docs/base-path/version/schema clues, including Swagger/OpenAPI/GraphQL-like metadata
- hidden anonymous APIs in JS bundles
- file preview/export/download endpoints
- registration/reset/invite/token bridge flows
- login-page 0-to-1 pivot: JS/API -> reset/register/invite -> docs/config -> edge assets, instead of staying on weak password or generic SQLi
- CORS/open redirect only if it leads to auth/data impact

### Logged-in black-box / A-B accounts

Use when credentials, cookies, roles, tenants, or multiple accounts exist.

```text
zhang-web-src-default-runner
-> blackbox-pentest-runner
-> auth-role-matrix-runner
-> object-identity-extractor
-> ab-object-pair-builder
-> traffic-to-workflow-mapper
-> single-variable-replay-harness
-> logic-evidence-pack
```

Default tests:

- object ID swap, tenant/org/department swap, role downgrade/upgrade boundaries
- BOLA and BOPLA separately: object access first, then property/mass-assignment mutation
- business response-field diff: compare `code`, `msg`, `status`, `state`, `role`, `ownerId`, `openid`, `token`, `auditStatus`, and not only HTTP status
- workflow state mutation, replay, stale link/token reuse
- export/share/recycle-bin/recent/favorite hidden actions
- payment/coupon/membership/approval/admin control-plane logic when present

If only one account is available, run a **single-account object-chain mode** before asking for A/B fixtures:

1. Dump the latest authenticated traffic from browser/Burp.
2. Decode/decrypt responses if the frontend can render them.
3. Extract real owned object IDs from list/search endpoints.
4. Replay `list -> detail -> action/write` with the same account to prove baseline.
5. Only then test sibling IDs, historical IDs, tenant/org fields, or state-action endpoints.

Do not report `500` on guessed IDs as BOLA. Treat it only as an object-chain candidate until a real existing object shows cross-owner data or unauthorized state change.

### Java/JVM website default

Use when Java clues appear: `JSESSIONID`, Spring/Tomcat/Struts/Shiro/JSP errors, `.do`, `.action`, `/actuator`, Java stack traces, GeoServer-like endpoints, Maven/Gradle artifacts, or obvious Java API naming.

```text
zhang-web-src-default-runner
-> ghost-bits-java-truncation
-> relevant impact skill: upload-insecure-files / path-traversal-lfi / crlf-injection / request-smuggling / deserialization-insecure / sqli-sql-injection / cmdi-command-injection / ssti-server-side-template-injection
-> single-variable-replay-harness
```

Rule: generate 1-3 Ghost Bits variants for each high-value candidate payload, but only report when backend semantics or byte-view divergence is proven.

### Frontend crypto/signature/reverse

Use when requests include `data`, `key`, `result`, `sign`, encrypted body, anti-debugging, request wrappers, or login encryption.

```text
zhang-web-src-default-runner
-> browser-pentest-orchestrator
-> complex-js-reverse
-> request-chain-tracer
-> find-crypto-entry
-> webpack-runtime-extractor
-> protocol-diff-lab
-> browser-crypto-helper-builder
```

Default path: capture real request -> get initiator/wrapper -> recover sign/encrypt/decrypt path -> produce runnable artifact: single HTML, interactive script, or offline raw HTTP generator.

For response-encrypted apps, prioritize a **bulk response decoder** as soon as one response is proven decryptable. Feed decoded `list`, `detail`, and business-action responses into `object-identity-extractor`; this is usually higher value than continuing UI probing or blind ID fuzzing.

### Mini-program

Use when user provides WeChat remote-debugging CDP ws/devtools URL, wxapkg, or decompiled source.

```text
zhang-web-src-default-runner
-> miniapp-dynamic-static-runner
-> wechat-miniapp-cdp-debug
-> request-chain-tracer
-> object-identity-extractor
-> auth-role-matrix-runner if accounts/roles exist
```

Correlate runtime network traffic with static page methods, storage, tokens, wrappers, routes, and object IDs.

### Burp/Yak/MCP traffic-driven testing

Use traffic as source of truth when available.

```text
zhang-web-src-default-runner
-> capture-bootstrap-check
-> burp-mcp-playbook / yak-mcp-playbook
-> burp-scope-traffic-dumper / traffic-to-workflow-mapper
-> traffic-dedupe-prioritizer
-> blackbox-business-logic-hunter
-> single-variable-replay-harness
```

If MCP health is questioned, do a minimal live probe first; empty resource lists do not prove failure.

When browser MCP page selection is unstable, use Burp history as the authoritative request log and use browser runtime only for storage, route, and crypto helper extraction. Do not lose time debating whether the browser page can be rediscovered if the authenticated traffic already exists.

## Decision loop

For each cycle:

1. Pick one high-value feature or endpoint.
2. Capture clean baseline and object/state identifiers.
3. Choose one mutation dimension: object, tenant, role, status, file key, token, amount, timestamp, nonce, header, path, or request order.
4. Replay exactly one mutation.
5. Compare server-side state/data, not only status code.
6. Decide: confirm, pivot, retry one new variable, abandon with reason, or package report evidence.

## Anti-theory execution gate

Every real assessment must quickly produce one of these artifacts:

- a run directory from `scripts/init_src_run.py`
- a baseline browser action or raw HTTP request
- a Burp/Yak/HAR traffic slice
- an object/identity/tenant map
- a single-variable mutation queue
- a replay result, response diff, state diff, or abandon reason

If the answer contains only vulnerability categories, payload lists, or high-level methodology after a target is available, it is considered a failed execution loop.

## Required per-run status shape

At the start of a real target run, keep the status compact:

```text
SCENE: <inferred scene>
SKILL_CHAIN: <3-5 skills>
RUN_DIR: <path or not-created-yet>
BASELINE_TO_CAPTURE: <one concrete action>
FIRST_HYPOTHESIS: <one high-value hypothesis>
DECISION_EVIDENCE: <what proves or rejects it>
```

After baseline, every test cycle should include:

```text
BASELINE: <request/action>
VARIABLE: <exactly one variable>
MUTATION: <old -> new>
DIFF: <HTTP/business/state diff>
DECISION: <confirm | pivot | retry | abandon | package>
NEXT: <one concrete action>
```

## Evidence standard

A candidate becomes reportable only when there is:

- baseline and mutated request/response
- exact changed variable
- server-side impact or sensitive data/state proof
- account/object ownership context when auth is involved
- cleanup or rollback note
- confidence and reproducibility from a clean or reset baseline

Use `references/live-run-protocol.md`, `references/scenario-prompts.md`, `references/routing-matrix.md`, `references/evidence-standard.md`, `references/src-high-value-pattern-bank-2026.md`, `references/high-imagination-hypothesis-bank.md`, `references/external-blackbox-methodology-2026.md`, `references/selected-src-article-digest-2026.md`, and `templates/target-run/README.md` when a prompt, report handoff, run setup, or methodology refresh needs a fixed format.
