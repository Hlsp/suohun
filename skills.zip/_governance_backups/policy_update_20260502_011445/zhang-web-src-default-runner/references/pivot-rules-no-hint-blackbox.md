# Pivot rules for no-hint black-box runs

Use this file when the first hypothesis stalls. The goal is to **pivot by evidence**, not by frustration.

## Core rule

After every failed first probe, ask:

1. what did this failure prove?
2. which trust boundary remains untested?
3. which adjacent lane is now cheaper and higher-signal?

Do not repeat the same category with lower-quality guesses.

## Common stall -> pivot map

### Homepage only / generic 404 shell

If:

- `/` is generic
- no visible routes

Pivot to:

1. browser MCP snapshot + network
2. same-origin fetch probes
3. JS route/API extraction
4. Java component family detection if the shell looks Spring/Tomcat/Struts/Shiro-like

Do not:

- jump straight to huge dir brute-force
- call it “empty”

## Login page but no immediate API clues

If:

- login page exists
- obvious endpoints are weak

Pivot to:

1. reset/register/invite flow
2. hidden JS routes
3. docs/schema/static asset clues
4. auth/session state boundary checks

Do not:

- keep replaying login with random payloads

## Component root returns 404

If:

- one expected component path is 404

Pivot to:

1. confirm component family through other clues
2. search alternate roots/versioned roots/API roots
3. use local PoC routing, not path guessing only

Do not:

- discard the component family after one path miss

## Fastjson `@type` works but dangerous classes are blocked

If:

- harmless types instantiate
- dangerous classes return `autoType is not support`

Pivot to:

1. nested string JSON + `$ref`
2. class family around allowed runtime classes
3. challenge/version-specific chains
4. JDK-version-aware routes

Do not:

- keep retrying the same blocked classic gadget classes

## Shiro clue exists but exploit chain not ready

If:

- `rememberMe` clue exists
- direct exploit not yet justified

Pivot to:

1. rememberMe oracle
2. default key verify
3. route/filter boundary checks

Do not:

- jump to gadget execution before key/oracle proof

## Struts clue exists but no OGNL proof yet

If:

- `.action` or parser clue exists
- exploit payload not yet proven

Pivot to:

1. parser/error-based verify
2. upload/multipart lane
3. debug/problem-report exposures

Do not:

- start with the loudest command payload first

## File workflow exists but upload seems uninteresting

If:

- upload did not give quick extension bypass

Pivot to:

1. preview
2. download
3. share token
4. export
5. async processing / report jobs

Do not:

- over-invest in extension fuzzing after clear negative evidence

## BOLA guess is weak

If:

- you do not have real object IDs yet

Pivot to:

1. list endpoint
2. detail endpoint
3. export/share/recent/history views
4. response decryption/helper if needed

Do not:

- brute-force object IDs from thin air and call 500/404 “evidence”

## OAuth/SSO clue exists but route is sparse

Pivot to:

1. redirect URI/state/nonce behavior
2. account binding
3. invite/register/reset cross-flow reuse

## Detector PoC says “not found”

Pivot to:

1. path family alternatives
2. method/content-type changes
3. route shape from runtime
4. next family in the component shortlist

Do not:

- mark the whole component family dead on one detector miss

## Output discipline

When pivoting, explicitly note:

```text
FAILED_LANE:
WHAT_IT_PROVED:
NEXT_BOUNDARY:
NEXT_LANE:
DECISIVE_SIGNAL:
```
