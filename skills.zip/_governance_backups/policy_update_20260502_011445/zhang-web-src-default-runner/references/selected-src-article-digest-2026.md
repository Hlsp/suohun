﻿# 20篇精选 SRC / 黑盒漏洞挖掘文章阅读摘要（2026-04-29）

用途：给 `zhang-web-src-default-runner` 做日常 Web/SRC 黑盒挖洞方法论补充。重点不是收藏链接，而是沉淀可执行的测试分支：入口选择、证据链、单变量 replay、业务场景优先级。

当前沉淀状态：本文件中的文章经验已进一步抽象到 `src-high-value-pattern-bank-2026.md`，并注入总入口、dispatcher、JS 隐藏接口、API 越权、业务逻辑、支付会员、账号恢复、上传/导出/流量优先级等关键 skill。日常执行优先使用 pattern bank 和各 skill 的内置规则，不需要先阅读文章列表。

## 筛选标准

- 优先真实 SRC / 众测 / 攻防项目复盘，而不是纯漏洞原理搬运。
- 优先能转化为黑盒动作的文章：A/B 账号、JS 接口、登录框突破、金融/支付、密码重置、小程序/APP、边缘资产、组合链。
- 保留经典文章：即使年代较早，只要方法论仍能迁移到今天的系统，就纳入。
- 不把“工具命令”当核心，抽象成可复用测试思路。

## 20篇文章与可落地点

| # | 文章 | 来源 | 核心价值 | 应落入的 runner 分支 |
|---|---|---|---|---|
| 1 | JSRC小课堂：认证缺失和认证缺陷漏洞 | https://developer.jdcloud.com/article/986 | 将逻辑漏洞拆成认证缺失、功能级访问控制缺失、响应特征识别；强调域名收集、动态站点爬取、规则提取、批量结果展示。 | no-login black-box、auth-role-matrix、traffic-dedupe |
| 2 | JSRC小课堂：逻辑漏洞的 BurpSuite 插件开发 | https://developer.jdcloud.com/article/987 | 通用工具不够时，要按业务模型定制检测；同类 URL 可能存在同类越权；通过请求/响应长度、cookie 有效性等特征批量定位。 | burp-history-to-workflow、single-variable-replay |
| 3 | JSRC小课堂：SRC漏洞挖掘技巧——三步走收集高质量信息 | https://developer.jdcloud.com/article/990 | 组织架构、证书透明度、备案、公众号、APP 历史版本、JS 链接、三级/四级域名是高质量资产来源。 | recon、edge asset、preauth-js-hidden-logic-hunter |
| 4 | JSRC小课堂：命令执行漏洞挖掘技术 | https://developer.jdcloud.com/article/991 | 命令执行类漏洞要解决无回显、不能写文件、不能出网、路径未知等验证问题；报告应关注最小化证明。 | cmdi-command-injection、logic-evidence-pack |
| 5 | 安全小课堂：业务逻辑漏洞挖掘 | https://cloud.tencent.cn/developer/article/1540970 | 业务逻辑的高价值在于“奇葩但可复用”的场景：支付、会员、优惠、评论、社交、订单、付费下载。 | blackbox-business-logic-hunter、payment-promo-rewards-abuse |
| 6 | 业务视角下的金融SRC快速挖掘思路 | https://forum.butian.net/share/4671 | 金融场景要按开户/KYC、状态查询、提现/转账、优惠券、敏感资料、三方厂商、SSRF/云存储拆链路。 | payment、subscription、export-preview、ssrf、auth |
| 7 | 渗透测试JS接口Fuzz场景研究 | https://forum.butian.net/share/4163 | 登录框无突破时，JS 二层/三层接口提取、接口拼接、响应大小差异、未授权下载/上传是高 ROI。 | preauth-js-hidden-logic-hunter、webpack-runtime-extractor |
| 8 | 手把手拆解：小程序/Web端加密鉴权绕过案例全复现 | https://forum.butian.net/share/4664 | 加密鉴权不是终点；反编译、动态调试、JS 逆向、脚本复现后，仍要回到越权/遍历/接管证据。 | miniapp、request-chain-tracer、browser-crypto-helper-builder |
| 9 | 记一次登录框0-1渗透突破 | https://forum.butian.net/share/4644 | 登录框不是只能弱口令/注入；应先做边缘接口、重置/注册、前端资源、第三方回调、隐藏 API 联动。 | no-login startup、authbypass、preauth-js |
| 10 | 实战-SRC从入门到精通超详细分析 | https://forum.butian.net/share/4589 | SRC 常见困境是“99%登录框”；方法上应从资产、接口、JS、低频功能、边界系统逐步收缩。 | default runner startup、scenario prompts |
| 11 | 手把手 JS 逆向断点调试/前端加密对抗/企业 SRC 实战 | https://forum.butian.net/share/4520 | 前端加密要动态断点定位 wrapper/sign/encrypt，而不是静态猜算法；最后产出可复现请求生成器。 | complex-js-reverse、request-chain-tracer |
| 12 | 漏洞挖掘：业务响应状态码攻击面新思路 | https://forum.butian.net/share/4542 | 不只看 HTTP 状态码；业务 code、msg、openid/token 缺失、状态字段异常常暴露后端校验不完整。 | workflow-state-diff-lab、single-variable-replay |
| 13 | 攻防渗透集锦：JS泄露突破多个后台 | https://forum.butian.net/share/4538 | 前后端分离场景下，JS 泄露的接口、Swagger、账号/工号/配置可能串成后台突破链；先证据化泄露，再验证授权边界。 | extract-frontend-sensitive-info、api-recon-and-docs |
| 14 | 信息搜集之边缘资产和隐形资产的发掘 | https://forum.butian.net/share/4675 | 漏洞不一定在主站；边缘资产、隐形资产、新上线业务、历史系统、低维护系统往往更高产。 | recon-subdomain、httpx-url-dashboard、feature-priority-scorer |
| 15 | 企业管理类系统常见漏洞挖掘指北 | https://forum.butian.net/share/4647 | ERP/供应商/采购/管理系统要关注组织、角色、审批、导入导出、供应商隔离、附件、任务流。 | portal-workflow、tenant-admin、export-preview |
| 16 | 密码重置漏洞挖掘指南 | https://forum.butian.net/share/4634 | 重置链要逐步验证：身份绑定、验证码、token 生命周期、回调、找回入口、跨账号复用、前后端字段差异。 | authbypass、account-binding-invite-delegation-abuse |
| 17 | 众测环境下被忽视的“水洞”攻击面 | https://forum.butian.net/share/4640 | 低关注功能、短周期活动、临时入口、运营页面、水位较低的边缘功能，常有低成本漏洞。 | feature-priority-scorer、preauth-js-hidden-logic-hunter |
| 18 | 业务安全漏洞挖掘归纳总结 | https://tttang.com/archive/1259/ | 经典业务安全分类：密码找回、支付、应用程序逻辑、金融平台常见风险，适合作为业务 invariant 字典。 | blackbox-business-logic-hunter |
| 19 | 代码审计之逻辑上传漏洞挖掘 | https://tttang.com/archive/419/ | 上传漏洞不只 MIME/扩展名；函数误用、编码截断、条件竞争、保存链路二阶段处理更关键。 | upload-insecure-files、arbitrary-write-to-rce、race-condition |
| 20 | 浅析 SRC 的 APP 漏洞挖掘 | https://www.anquanke.com/post/id/187948 | APP SRC 要从抓包、反编译、Manifest、暴露组件、Activity/Provider/Service、深链/本地权限提升建模。 | miniapp/app dynamic-static、object-identity-extractor |

## 提炼出的 10 条新规则

1. **登录框优先切换到“隐藏接口/边缘资产/重置注册”三线并行**：不要只测弱口令、SQLi。
2. **JS 提取必须做二层/三层追踪**：入口 HTML 里的接口不全，必须追踪被 JS 引入的 JS、配置文件、路由表、wrapper。
3. **业务响应字段是攻击面**：`code/msg/status/openid/token/role/uid/auditStatus` 的缺失、默认值和异常分支要进入 replay。
4. **金融/支付按链路测**：开户/KYC -> 充值/提现/转账 -> 优惠券/会员 -> 发票/合同/流水 -> 风控/三方服务。
5. **密码重置按 token 生命周期测**：生成、发送、校验、消费、复用、失效、跨账号、跨端、回调。
6. **企业管理系统按组织边界测**：部门、角色、供应商、审批状态、附件、导入导出、任务流、数据权限。
7. **APP/小程序不是单独方向，本质仍是 API 和身份边界**：反编译/动态调试只为拿到真实 wrapper、token、对象 ID。
8. **上传要看保存链路而不是只看上传点**：临时文件、转码、重命名、回显 URL、二次处理、异步任务、竞争窗口。
9. **边缘资产是高产但要降噪**：先截图/标题/技术栈/登录态分类，再选业务含金量高的入口，别无差别扫描。
10. **报告必须落到最小证据**：baseline、单变量、mutated request、响应 diff、服务端状态/数据影响、清理说明。

## 对总入口的具体增强建议

- 在 no-login 场景下增加“登录框 0-1”微流程：`登录页 -> JS/API -> 重置/注册/邀请 -> Swagger/docs -> 边缘资产`。
- 在 logged-in 场景下增加“业务响应字段 diff”：不仅 diff HTTP body，还抽取业务 code/status/token/role/owner 字段。
- 在金融/支付/优惠券场景下默认调用 `payment-promo-rewards-abuse` 和 `logic-race-harness`。
- 在企业管理/Portal/OA 场景下默认调用 `portal-workflow-task-abuse`、`tenant-admin-control-plane-abuse`、`export-preview-sharing-logic-abuse`。
- 在前端加密/小程序场景下强制产出可运行 replay helper，不接受“只解释算法”。
- 在文件上传场景下把“二阶段处理/异步任务/编码截断/条件竞争”加入默认检查。
