﻿# External black-box Web/SRC methodology notes 2026

These notes summarize high-value ideas collected from public black-box Web/API/bug-bounty methodology sources. Use them to refine hunting loops, not as a generic checklist.

## Key source-backed improvements

### 0. 2026 refresh: keep access-control and API property testing at the center

OWASP Top 10:2025 keeps Broken Access Control as A01, and the API Top 10 still places object/property authorization failures near the top. This reinforces that the default Web/SRC runner should treat authorization, object ownership, tenant boundary, and mass-assignment style property mutation as the main hunting lane, not as a late checklist item.

Operational addition:
- If accounts/tokens/roles exist, build the A/B account-object matrix before scanning broad injection payloads.
- For every sensitive API, test both "can this user touch this object?" and "can this user set/read this property?".
- For no-login targets, first mine anonymous object/file/API exposure; once credentials appear, immediately convert to A/B replay.

### 1. Keep the runner evidence-first, not checklist-first

OWASP WSTG frames web testing as active validation of application controls and notes that its methodology is black-box oriented. Keep using the current loop: establish baseline -> mutate one variable -> verify control failure -> package evidence.

Operational addition:
- At startup, avoid dumping all tests. Build one clean baseline flow first.
- Treat each test as a security-control validation: auth, object ownership, workflow state, parser boundary, cache boundary, or business rule.

### 2. Business logic requires domain modeling

PortSwigger emphasizes that logic flaws are often unique to the application and hard for scanners because they require understanding business assumptions and unusual states.

Operational addition:
- For each target, create a small "business invariant" list: who may access what, when, after which prior step, at what quantity/price/state.
- Test violations of the invariant rather than random payloads.
- Prioritize features where business impact is inherent: money, identity, files, private messages, approvals, admin/control plane, quotas, rewards, exports.

### 3. API recon should include documentation, base paths, methods, content types, and error-shaped hints

PortSwigger API testing stresses API documentation discovery, base path exploration, supported methods, media types, hidden endpoints, and response/error review.

Operational addition:
- When an endpoint like `/api/swagger/v1/users/123` is found, also check `/api/swagger/v1`, `/api/swagger`, `/api`.
- For high-value endpoints, test method and content-type variants before payload spraying.
- Watch error bodies for required parameters, enum values, internal object names, and hidden fields.

### 4. BOLA/BOPLA should be explicit dimensions, not lumped as IDOR

OWASP API1 distinguishes object-level authorization failures; OWASP API3 covers property-level exposure and mass assignment.

Operational addition:
- Separate tests into object access (`orderId`, `fileId`, `tenantId`) and property access (`role`, `isAdmin`, `price`, `status`, `ownerId`, `plan`, `quota`).
- Build A/B owner-object pairs first, then test read, write, delete, export, share, favorite/recent, and status-changing actions.
- For mass assignment, compare response fields and send candidate read-only fields back in PATCH/PUT/POST, then verify by re-reading state.

### 5. Manual depth beats broad automated farming for high-impact findings

Bugcrowd's systemic-vs-manual article highlights that automation creates noise, while manual business-context work more often finds high/critical logic flaws and chains.

Operational addition:
- Use automation for collection/dedupe, not final proof.
- If a route is high-value, spend more time modeling its workflow and object/state transitions instead of moving to the next endpoint.
- Preserve abandoned leads with reason, so follow-up does not repeat shallow probes.

### 6. Hidden parameters and JS are still high ROI

Intigriti's hidden-parameter guide highlights JavaScript files as a strong source for endpoints, routes, and input parameters.

Operational addition:
- When anonymous probing is weak, immediately switch to JS bundle mining.
- Search for body builders, request wrapper calls, enum names, disabled UI actions, role checks, and endpoint constants.
- Feed discovered parameters into BOPLA/mass-assignment and single-variable replay.

### 7. Cache/path parser discrepancies deserve a specialist lane

PortSwigger's web cache deception guidance emphasizes finding dynamic sensitive endpoints and discrepancies in URL/path parsing between cache and origin.

Operational addition:
- Add a cache/parser lane for GET/HEAD endpoints returning private data.
- Test static extension, static directory, filename, delimiter, and normalization mismatches only when a cache signal exists.
- Combine with auth/object tests only when safe and reversible.

### 8. Parser discrepancy is a broad modern theme

PortSwigger Top 10 Web Hacking Techniques of 2024 and WAFFLED both point to hidden semantic ambiguity and parser discrepancies across web layers, WAFs, caches, content-types, and gateways.

Operational addition:
- Keep Ghost Bits, content-type switch, duplicated params, mixed JSON/form/multipart, path normalization, and cache key tests as controlled parser-diff lanes.
- Do not report parser-diff alone; require backend semantic proof or security boundary impact.

### 9. Chinese SRC logic-vuln writeups reinforce three-step authorization validation

Chinese logic-vulnerability articles commonly emphasize horizontal/vertical auth testing, context verification, and impact assessment.

Operational addition:
- For every auth finding, classify: horizontal, vertical, anonymous-vs-authenticated, cross-tenant, object-property, or workflow-state.
- Verify not just status code, but returned data, backend state, logs/audit if observable, and sensitivity/scale.

### 10. Access-control testing should be feedback-driven, not parameter-name driven

Recent black-box access-control research such as BACScan/BACFuzz points to a useful practical idea: do not only mutate parameters that "look like IDs". Use runtime feedback to infer actions, roles, object relationships, and state transitions, then replay equivalent actions across identities.

Operational addition:
- Classify captured requests by action type: list, detail, create, update, delete, export, share, approve, bind, invite, pay, refund, admin.
- For each action class, map required pre-state and post-state: object owner, object status, tenant/org, role, and generated tokens/links.
- Mutate the smallest identity or state variable first; avoid mixing objectId + role + status in one replay.
- If the first replay is blocked, try the same object boundary through sibling functions such as preview/export/recent/favorite/recycle/share.

### 11. OpenAPI/spec-aware mass assignment is stronger than guessing fields

Black-box mass-assignment research shows a strong pattern: documentation/schema plus response fields can reveal read-only or confidential properties that should not be client-writable.

Operational addition:
- When Swagger/OpenAPI/GraphQL/schema-like docs exist, extract models and mark fields seen in responses but absent from create/update docs.
- Candidate fields: `role`, `roles`, `isAdmin`, `admin`, `ownerId`, `userId`, `tenantId`, `orgId`, `status`, `state`, `price`, `amount`, `quota`, `plan`, `balance`, `discount`, `auditStatus`.
- Replay by adding one field at a time to POST/PUT/PATCH; verify by re-reading state, not by status code alone.
- If schemas are missing, infer candidate fields from JS bundles, error messages, list/detail responses, and disabled UI actions.

### 12. Component/version exposure is useful only when tied to reachability

Recent automated exploit-generation work on black-box web apps reinforces a practical distinction: component names and versions are leads, not findings. They become valuable only when a reachable route, exact version clue, and exploitability/impact path line up.

Operational addition:
- Keep component/version findings in a "lead" bucket until a live route and version-specific behavior is proven.
- Prefer app-specific high-impact chains over generic CVE noise.
- For Java stacks, combine component leads with Ghost Bits/parser lanes only when the affected parser/sink is reachable.

## Source list

- OWASP Top 10:2025 A01 Broken Access Control: https://owasp.org/Top10/2025/A01_2025-Broken_Access_Control/
- OWASP Top 10:2025 introduction: https://owasp.org/Top10/2025/0x00_2025-Introduction/
- OWASP WSTG latest: https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/00-Introduction_and_Objectives/README
- OWASP WSTG IDOR testing: https://owasp.org/www-project-web-security-testing-guide/v41/4-Web_Application_Security_Testing/05-Authorization_Testing/04-Testing_for_Insecure_Direct_Object_References
- OWASP WSTG authorization bypass testing: https://owasp.org/www-project-web-security-testing-guide/v42/4-Web_Application_Security_Testing/05-Authorization_Testing/02-Testing_for_Bypassing_Authorization_Schema
- OWASP API1 BOLA: https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/
- OWASP API3 BOPLA / mass assignment: https://owasp.org/API-Security/editions/2023/en/0xa3-broken-object-property-level-authorization/
- PortSwigger business logic vulnerabilities: https://portswigger.net/web-security/logic-flaws
- PortSwigger API testing: https://portswigger.net/web-security/api-testing
- PortSwigger web cache deception: https://portswigger.net/web-security/web-cache-deception
- PortSwigger Top 10 Web Hacking Techniques 2024: https://portswigger.net/research/top-10-web-hacking-techniques-of-2024
- Intigriti bug bounty methodology: https://www.intigriti.com/researchers/blog/hacking-tools/crafting-your-bug-bounty-methodology-a-complete-guide-for-beginners
- Intigriti hidden parameters guide: https://www.intigriti.com/researchers/blog/hacking-tools/finding-hidden-input-parameters
- HackerOne business logic example: https://www.hackerone.com/blog/how-business-logic-vulnerability-led-unlimited-discount-redemption
- Bugcrowd systemic vs manual approaches: https://www.bugcrowd.com/blog/the-two-faces-of-bug-bounty-hunting-systemic-vs-manual-approaches/
- Bugcrowd VRT: https://bugcrowd.com/vulnerability-rating-taxonomy/1.6.pdf
- WAFFLED WAF/parser discrepancy paper: https://arxiv.org/abs/2503.10846
- Automated black-box testing of mass assignment in REST APIs: https://arxiv.org/abs/2301.01261
- BACScan black-box broken-access-control detection: https://yuanxzhang.github.io/paper/bacscan-ccs25.pdf
- BACFuzz broken access control fuzzing: https://arxiv.org/abs/2507.15984
- AutoEG black-box third-party vulnerability exploit generation: https://arxiv.org/abs/2604.00704
- Foxfire 越权测试方法论: https://www.foxfire.com.cn/article/1138.html
- 火山引擎业务逻辑漏洞挖掘: https://developer.volcengine.com/articles/7381507535301247027
