# First-10-Minute Routing Contract

## First-10-Minute Routing Contract

When the user gives a target, do not start with generic vulnerability classes. Spend the first cycle routing and collecting decisive runtime facts:

```text
0-2 min: classify target mode
  no-login | logged-in | encrypted SPA | upload/import | workflow/approval | Java/JVM | miniapp | source-audit | traffic-driven

2-5 min: choose exactly two lanes
  LANE_A = most likely high-impact chain from observed behavior
  LANE_B = weird/combinational chain from high-imagination bank

5-10 min: produce one hard artifact
  Burp/HAR traffic slice, route->endpoint map, decrypt helper, object map, upload pipeline map, token/tenant map, or one replay diff
```

If the first answer after a target is only a checklist, it is a failed start. It must contain:

```text
MODE:
WHY:
SKILLS:
LANE_A:
LANE_B:
FIRST_ARTIFACT:
DECISIVE_TEST:
```

## Lane selection rules

- If logged in and API exists: lane A is object/workflow authorization; lane B is hidden route/action or token/tenant confusion.
- If encrypted response exists: lane A is decrypt -> object corpus; lane B is exposed key -> offline data mining or cross-endpoint replay.
- If upload exists: lane A is upload pipeline; lane B is file token/key reuse in business forms, not extension fuzzing.
- If approval/workflow exists: lane A is state/action replay; lane B is out-of-order action, notification primitive, or hidden admin chunk.
- If Java/JVM clues exist: lane A is high-impact endpoint mapping; lane B is parser discrepancy/Ghost Bits only on a concrete sink.
- If only login page exists: lane A is JS/API hidden surface; lane B is reset/register/invite/docs/edge assets.

Every lane must name the exact signal that would make it high-impact. No lane may exist only because a vulnerability category is popular.
