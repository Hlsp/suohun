# Evidence standard for Zhang Web/SRC runs

## Minimum evidence for a confirmed finding

- Target and scope context.
- Active run directory and artifact paths.
- Baseline request/response and baseline server-side state.
- Mutated request/response with exactly one changed variable.
- Object/account/tenant ownership proof when authorization is involved.
- Sensitive data, unauthorized state transition, file artifact, command output, backend parser branch, or other server-side impact.
- Reproduction steps from clean or reset state.
- Cleanup or rollback step.
- Confidence and limits: what was proven, what was not tested.

## Negative evidence worth keeping

- Java Ghost Bits variant attempted but no backend semantic change.
- Neighbor ID or object swap tested but no cross-owner hit.
- Direct guessed paths returned SPA fallback/401/403/404, then pivoted to JS wrapper.
- Browser context succeeded while raw curl failed, proving same-origin/runtime wrapping matters.
- Hidden JS/API candidate turned out to be static residue, with route/function checked.
- Parser/cache/framework discrepancy changed only error wording or generic `500`, with no data/state/cache impact.

## Artifact naming convention

- raw baseline: `artifacts/raw/B<id>_<action>.txt`
- mutated request: `artifacts/raw/M<id>_<variable>.txt`
- response snapshot: `artifacts/responses/R<id>_<baseline-or-mutated>.txt`
- state snapshot: `artifacts/responses/S<id>_<before-or-after>.json`
- helper script: `artifacts/scripts/<purpose>.py|js|html`

## Reporting tone

Outcome first, then decisive evidence, verification, impact, and fix suggestion. Avoid large raw logs; surface the exact lines or response fields that prove the issue.
