# Postmortem: encrypted logged-in SPA visitor target, 2026-04-30

Use this note when a logged-in SPA uses encrypted responses, object IDs, upload, and Burp/browser MCP together.

## What worked

- JS reverse found the real response decrypt chain: `key/result`, SM2-wrapped AES key, AES-CBC response body, and a reusable offline Node.js decoder.
- Frontend route and endpoint mapping identified the real workflow: `visitor/list -> visitor/detail -> urgeApproval -> saveVisitorInfo -> put-image-file`.
- Single-variable replay showed that guessed `detail.id` reaches backend object handling and that `urgeApproval.id` has an object-existence boundary.
- Upload pipeline was tested across accept/store/retrieve with signed URL, content-disposition, content-type, extension, MIME, and content mismatch checks.

## Main misses

1. **Run directory too late**
   - The run produced useful artifacts, but object maps, mutation logs, and abandoned leads were not written early enough.
   - Fix: create/reuse `runs/<target>/` as soon as the target needs more than one turn.

2. **Real object extraction too late**
   - Too much time went into guessed IDs (`1`, `123456`) before decoding `visitor/list` in bulk.
   - Fix: once response decryption works, immediately decode list responses and extract real `id`, owner, status, phone, tenant, and visited-person fields.

3. **Candidate 500 was over-weighted**
   - `detail?id=<guess>` returning `500` proves a reachable object chain, not BOLA.
   - Fix: never promote generic `500` without an existing object, ownership boundary, and sensitive data/state proof.

4. **Upload chain stayed too long after negative evidence**
   - SVG and MIME mismatch were rejected, signed retrieval used `attachment` and `application/octet-stream`, and unsigned retrieval failed.
   - Fix: after accept/retrieve negative evidence, pivot to object authorization or second-stage processors only if a processor/preview/import/export step is observed.

5. **Burp was used for tabs but not as the main extractor**
   - Repeater tabs existed, but Proxy history should have been dumped, normalized, decrypted, and fed to object extraction earlier.
   - Fix: for authenticated SPAs, Burp history is the traffic source of truth; browser MCP is supplementary for storage and runtime crypto.

6. **Single-account limitation was not handled explicitly**
   - A/B BOLA needs another owner account, but even one account can prove baseline object chains and extract owned object fixtures.
   - Fix: run single-account object-chain mode first, then ask for or create A/B fixtures only when the owned-object baseline is complete.

## Improved next-time loop

```text
1. Create run dir and scope file.
2. Dump authenticated Burp history for the current workflow.
3. Recover/deploy response decoder if encrypted.
4. Bulk-decode list/detail/action responses.
5. Extract real object/identity/tenant/token inventory.
6. Prove baseline chain with owned object: list -> detail -> safe action/readback.
7. Select one mutation: object id, tenant, status, token, file key, or action state.
8. Replay once, compare decrypted business fields and server state.
9. Promote only sensitive data disclosure or unauthorized state change; otherwise log abandon reason.
```

## Visitor-target-specific priority queue

- Decode latest `POST /api/sm-visitor/visitor/list` response and extract real record IDs.
- Replay `POST /api/sm-visitor/visitor/detail` only with an existing ID first.
- If another account/object owner is available, swap only `id` in `detail` and `urgeApproval`.
- Re-test `saveVisitorInfo` only after a real `visitedPerson + visitedPhone` pair is observed from valid data.
- Keep upload lower priority unless a preview/converter/import/export endpoint appears.

