﻿# Live run protocol for Zhang Web/SRC skills

This protocol prevents the skill suite from drifting into theory. Use it whenever a real target, raw request, Burp/Yak history, browser session, account, miniapp CDP endpoint, or source entrypoint is available.

## Anti-theory rule

Do not spend more than one short paragraph on methodology before producing or requesting one of these concrete artifacts:

- target URL or scoped host
- browser page or runtime state
- raw HTTP baseline request
- Burp/Yak/HAR traffic slice
- account/role/tenant/object pair
- JS bundle or request initiator
- miniapp page/action and captured request
- source route/controller entrypoint

If none exists, the next action is to obtain a baseline, not to list more vulnerability classes.

## Required first cycle

Every run starts with this compact status:

```text
SCENE: <no-login | logged-in | traffic-driven | miniapp | frontend-crypto | Java | code-audit>
SKILL_CHAIN: <3-5 skills max>
RUN_DIR: <path or not-created-yet>
BASELINE_TO_CAPTURE: <browser/raw/Burp/source/CDP action>
FIRST_HYPOTHESIS: <one high-value guess>
DECISION_EVIDENCE: <what response/state proves or rejects it>
```

## Required mutation cycle

After a baseline exists, every test cycle must fit this shape:

```text
BASELINE: <request/file/action id>
VARIABLE: <exactly one path/query/header/body/state/order variable>
MUTATION: <old -> new>
REPLAY: <tool or command, or browser action>
DIFF: <HTTP + business field + state/data/file/session diff>
DECISION: <confirm | pivot | retry one variable | abandon with reason | package evidence>
NEXT: <one concrete next action>
```

## Run directory contract

Prefer creating a run directory for any target that will last more than one or two turns:

```text
runs/<timestamp>_<target_slug>/
  README.md
  00_scope.md
  01_baseline.md
  02_traffic_inventory.md
  03_object_identity_map.md
  04_hypothesis_queue.md
  05_mutation_log.md
  06_evidence_log.md
  07_abandoned_leads.md
  artifacts/
    raw/
    responses/
    screenshots/
    scripts/
```

The run directory is not bureaucracy. It is the memory that stops repeated shallow probing.

## Evidence gates

A result is not reportable until it passes all applicable gates:

- baseline and mutated request are preserved
- exactly one variable changed
- diff includes business fields, not only HTTP status
- backend state/data/session/file effect is proven
- identity/object/tenant ownership is recorded when auth is involved
- cleanup or rollback is recorded when state changed
- false leads are saved with abandon reason

## Pivot rules

- Only login page -> JS/API/reset/register/invite/docs/edge assets.
- JS reveals wrapper/sign/encryption -> reconstruct enough to replay, then return to API/object tests.
- API object found -> BOLA first, then BOPLA, then BFLA.
- Payment/member/reward -> state-machine + race only after baseline.
- Upload/import/report -> map accept/store/process/retrieve/post-process.
- Java/JVM -> add Ghost Bits variants only as one-variable parser-diff tests.
- Parser/cache/framework discrepancy -> continue only with auth/data/state/cache impact.

## Stop conditions

Stop or pivot when:

- two adjacent object IDs and one sibling endpoint produce no ownership delta
- JS candidate is static residue and no runtime request can be triggered
- endpoint requires unavailable credentials and no auth bypass path exists
- mutation changes only error wording or generic `500` with no controllable semantic proof
- active probing would change state without safe cleanup
## Local-tool usage bias

When a relevant local tool is already classified and wrapper-ready, prefer it over ad hoc command reconstruction.

Current practical examples:

- Fastjson / Jackson parser family checks -> `local-tool-arsenal-router` -> `run_jsonexp.py`
- broad host/service/web mixed recon -> `local-tool-arsenal-router` -> `run_fscan.py`
- Spring shell / Whitelabel / actuator-family route checks -> `local-tool-arsenal-router` -> `run_springboot_scan.py` in safe modes (`--url`, `--url-file`, `--dump`)

Do not force local GUI jars into automation until their headless contract is understood.
