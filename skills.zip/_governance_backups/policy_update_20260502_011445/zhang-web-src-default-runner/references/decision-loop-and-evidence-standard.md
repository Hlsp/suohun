# Decision loop

## Decision loop

For each cycle:

1. Pick one high-value feature or endpoint.
2. Capture clean baseline and object/state identifiers.
3. Choose one mutation dimension: object, tenant, role, status, file key, token, amount, timestamp, nonce, header, path, or request order.
4. Replay exactly one mutation.
5. Compare server-side state/data, not only status code.
6. Decide: confirm, pivot, retry one new variable, abandon with reason, or package report evidence.

## Anti-theory execution gate

Every real assessment must quickly produce one of these artifacts:

- a run directory from `scripts/init_src_run.py`
- a baseline browser action or raw HTTP request
- a Burp/Yak/HAR traffic slice
- an object/identity/tenant map
- a single-variable mutation queue
- a replay result, response diff, state diff, or abandon reason

If the answer contains only vulnerability categories, payload lists, or high-level methodology after a target is available, it is considered a failed execution loop.

## Required per-run status shape

At the start of a real target run, keep the status compact:

```text
SCENE: <inferred scene>
SKILL_CHAIN: <3-5 skills>
RUN_DIR: <path or not-created-yet>
BASELINE_TO_CAPTURE: <one concrete action>
FIRST_HYPOTHESIS: <one high-value hypothesis>
DECISION_EVIDENCE: <what proves or rejects it>
```

After baseline, every test cycle should include:

```text
BASELINE: <request/action>
VARIABLE: <exactly one variable>
MUTATION: <old -> new>
DIFF: <HTTP/business/state diff>
DECISION: <confirm | pivot | retry | abandon | package>
NEXT: <one concrete action>
```

## Evidence standard

A candidate becomes reportable only when there is:

- baseline and mutated request/response
- exact changed variable
- server-side impact or sensitive data/state proof
- account/object ownership context when auth is involved
- cleanup or rollback note
- confidence and reproducibility from a clean or reset baseline

Use `references/live-run-protocol.md`, `references/scenario-prompts.md`, `references/routing-matrix.md`, `references/evidence-standard.md`, `references/src-high-value-pattern-bank-2026.md`, `references/high-imagination-hypothesis-bank.md`, `references/external-blackbox-methodology-2026.md`, `references/selected-src-article-digest-2026.md`, and `templates/target-run/README.md` when a prompt, report handoff, run setup, or methodology refresh needs a fixed format.
