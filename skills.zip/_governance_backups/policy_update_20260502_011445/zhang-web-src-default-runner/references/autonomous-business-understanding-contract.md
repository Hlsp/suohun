# Autonomous Business Understanding Contract

## Autonomous Business Understanding Contract

After a target is available, build and update a business model without waiting for user prompts:

```text
BUSINESS_MODEL:
  actors: visitor/user/admin/approver/operator/tenant/external person
  assets: records/files/tokens/appointments/approvals/messages/profiles
  workflows: create/list/detail/update/approve/cancel/urge/export/share/upload
  trust_boundaries: owner/tenant/role/status/file/session/time
  invariants: who may perform which action on which object in which state
```

The test is not done after one page or one endpoint. Continue moving through:

```text
route map -> workflow map -> object map -> trust-boundary map -> hypothesis queue -> replay evidence
```

Default autonomous progression:

1. If the user logs in, immediately inventory storage, routes, and recent traffic.
2. If the user navigates to a page, map the page's business purpose, actors, objects, and state transitions.
3. If the user performs an action, capture baseline traffic and identify object IDs, status fields, file keys, tenant/role fields, and tokens.
4. If one probe fails, pivot to the next recorded hypothesis; do not stop unless blocked by missing auth, destructive risk, or no remaining high-impact hypothesis.
5. If a workflow has list/detail/action, always try to close the full chain before switching feature areas.
6. If the user says nothing after providing the target, continue with the next safest high-signal action and report compact progress.

Stop only when:

- a high-impact finding is proven and packaged,
- all high-impact lanes have recorded negative evidence,
- credentials/session/user action is required,
- further testing would be destructive without approval.

When stopping, say exactly what blocks progress and the next single action needed.

## Cross-suite high-value defaults

These defaults should influence every downstream skill, not just this entry router:

- Login page stuck -> pivot to JS/API, reset/register/invite, docs/schema, and edge assets.
- API found -> separate BOLA object access, BOPLA property mutation, and BFLA function access.
- Business flow found -> model invariants: who can do what, to which object, in which state, at what amount/quota, and in what order.
- JS/miniapp/APP reverse -> produce replayable wrapper/signature/encryption knowledge, then return to object/property/workflow testing.
- Upload/import/export -> model full pipeline: accept, store, process, retrieve, share/export, async job.
- Payment/membership/reward -> test quote, order, callback, fulfillment, cancel/refund, reuse, race, and downgrade/revoke.
- Parser/cache/framework discrepancy -> report only when it crosses auth, data, state, or cache boundaries.

## Creativity pass before giving up

When standard tests produce only low/medium candidates, do not simply summarize failure. Run this pass:

1. List observed primitives, even if weak: encrypted response decrypt, signed file URL, upload token, route param, object id error, captcha, refresh token, tenant id, role name, hidden endpoint, timestamp, bridge URL, status code oracle.
2. Combine two or three primitives into cross-boundary hypotheses: token -> file, file -> object, object -> workflow action, JS key -> offline corpus, tenant -> list filter, status -> action replay, route -> hidden chunk, error -> upstream route.
3. Pick three "weird but cheap" probes. Each must have one request/action and one decisive expected signal.
4. Execute the cheapest probe first. If all three fail, record abandon reasons and only then report no high-risk finding.

Do not confuse creativity with noisy fuzzing. The pass should increase hypothesis quality, not request volume.
