# Zhang Entry Priority

Generated: 2026-04-29 11:29:18 +0800

This file is a compact companion for `zhang-web-src-default-runner`.

## One-Line Default

When the user asks for Web/SRC/CTF-style testing and does not name a narrower workflow, start with:

```text
zhang-web-src-default-runner -> security-test-dispatcher -> matching execution lane
```

## Priority Order

1. `zhang-web-src-default-runner` ? personal P0 entry and high-value bias.
2. `security-test-dispatcher` ? scene classifier.
3. `blackbox-pentest-runner` ? Web/API execution orchestrator.
4. `auth-role-matrix-runner` ? logged-in A/B/tenant/role matrix.
5. `complex-js-reverse` ? frontend signing/encryption/replay recovery.
6. `miniapp-dynamic-static-runner` ? miniapp static+dynamic correlation.
7. `logic-evidence-pack` + `results-storage` + `pentest-report` ? packaging and report.

## Default High-Impact Bias

Prefer:

- anonymous object/data/file exposure
- authenticated BOLA/cross-tenant read/write
- BOPLA/mass assignment/property mutation
- workflow/payment/reset/approval state abuse
- file/export/share/token bridge exposure
- upload/import/report job to file read/write/RCE/SSRF
- frontend/miniapp crypto reconstruction only when it enables replay or business testing

Avoid spending time on low-impact banner/header trivia or scanner-only findings without state/data impact.
