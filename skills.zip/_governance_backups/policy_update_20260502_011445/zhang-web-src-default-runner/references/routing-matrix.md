# Zhang Web/SRC routing matrix

Use this matrix after `zhang-web-src-default-runner` triggers.

For any real target that will continue beyond one turn, initialize a run directory first:

```bash
python scripts/init_src_run.py --target <url-or-scope> --scene <scene> --out runs
```

Then route using the matrix below and write baseline/object/mutation/evidence artifacts into that run directory.

| Scene / clue | Primary chain | First decisive evidence |
|---|---|---|
| Only URL / login page | `security-test-dispatcher` -> `blackbox-pentest-runner` -> `browser-pentest-orchestrator` -> `preauth-js-hidden-logic-hunter` when needed | public route/API/file/config or JS-discovered hidden endpoint |
| Login page stuck / 0-to-1 breakthrough | `preauth-js-hidden-logic-hunter` -> `authbypass-authentication-flaws` -> `account-binding-invite-delegation-abuse` -> `api-recon-and-docs` | reset/register/invite/token/docs/API pivot rather than login-form noise |
| No endpoints from guessing | `preauth-js-hidden-logic-hunter` -> `webpack-runtime-extractor` -> `request-chain-tracer` | API wrapper, route table, disabled UI, anonymous request body |
| Credentials/cookies/tokens | `auth-role-matrix-runner` -> `object-identity-extractor` -> `ab-object-pair-builder` | owner object, cross-account/tenant pair, role boundary |
| API docs / Swagger / OpenAPI / schema | `api-recon-and-docs` -> `api-authorization-and-bola` -> `single-variable-replay-harness` | base path, model fields, method/content-type map, BOLA/BOPLA candidate |
| GraphQL / batched JSON / schema-like API | `api-sec` -> `graphql-and-hidden-parameters` -> `api-authorization-and-bola` | introspection/schema, node/object swap, mutation/property candidate |
| BOPLA / mass assignment suspected | `api-sec` -> `api-authorization-and-bola` -> `single-variable-replay-harness` -> `workflow-state-diff-lab` | one added property changes server-side state after re-read |
| Business workflow | `blackbox-business-logic-hunter` -> matching domain abuse skill -> `workflow-state-diff-lab` | state transition or hidden action with one variable changed |
| Payment / coupon / membership / finance | `payment-promo-rewards-abuse` -> `subscription-trial-membership-abuse` -> `logic-race-harness` -> `workflow-state-diff-lab` | amount, quota, reward, plan, order, refund, or risk-control state impact |
| Password reset / account recovery | `authbypass-authentication-flaws` -> `account-binding-invite-delegation-abuse` -> `single-variable-replay-harness` | token lifecycle, cross-account reuse, callback, or binding impact |
| Enterprise / OA / portal / supplier system | `portal-workflow-task-abuse` -> `tenant-admin-control-plane-abuse` -> `export-preview-sharing-logic-abuse` | org/role/workflow/file boundary violation |
| File/export/share/download | `file-access-vuln` -> `exploit-file-download` -> `export-preview-sharing-logic-abuse` | unauthorized file/object or reusable link/token |
| Upload/import/report/job | `upload-insecure-files` -> `arbitrary-write-to-rce` -> `race-condition` -> `cmdi-command-injection` if processing sink exists | write primitive, parser execution, generated artifact, worker/job/timing effect |
| Java/JVM target | `ghost-bits-java-truncation` plus relevant impact skill | low-byte view difference or backend semantic proof |
| Cache/proxy/parser discrepancy | `web-cache-deception` -> `waf-bypass-techniques` / `request-smuggling` only if indicated -> `single-variable-replay-harness` | cache signal or backend semantic split with data/state impact |
| Framework/middleware auth bypass clue | `authbypass-authentication-flaws` -> `api-authorization-and-bola` -> `single-variable-replay-harness` | middleware header/path/version behavior changes auth or data boundary |
| Encrypted/signed frontend requests | `complex-js-reverse` -> `request-chain-tracer` -> `find-crypto-entry` -> `browser-crypto-helper-builder` | recovered wrapper and runnable reproduction helper |
| Mini-program/CDP/wxapkg | `miniapp-dynamic-static-runner` -> `wechat-miniapp-cdp-debug` | runtime request linked to static page method/storage/token |
| Burp history available | `burp-mcp-playbook` -> `burp-scope-traffic-dumper` -> `traffic-to-workflow-mapper` | deduped endpoint/workflow map |
| Yak available | `yak-mcp-playbook` -> `traffic-dedupe-prioritizer` | scoped flows or fuzz/replay surface |
| Need final report | `logic-evidence-pack` -> `results-storage` -> `runner-results-bridge` -> `pentest-report` | concise evidence pack and finding status |

## Default high-value priority order

1. Anonymous data/object/file exposure.
2. Authenticated BOLA/IDOR/cross-tenant read or write.
3. BOPLA / mass assignment / property-level authorization leading to role, owner, tenant, price, quota, status, or plan mutation.
4. Export/download/share/recycle/recent/favorite hidden chains.
5. Upload/import/report/job parser chains leading to file write, command execution, SSRF, or sensitive read.
6. Admin/control-plane, invite/delegation/account binding, workflow approval/task center abuse.
7. Java Ghost Bits / parser view-difference bypass when target is Java/JVM.
8. Frontend secret/signature/encryption recovery that enables replay or hidden API access.
9. Cache/proxy/parser discrepancy only when it creates auth, data, or state impact.
10. Injection only when a realistic sink and impact path exists.

## Low-value deprioritization

Do not spend much time on login error wording, generic missing headers, scanner-only findings, or pure WAF bypass without backend semantic proof.
