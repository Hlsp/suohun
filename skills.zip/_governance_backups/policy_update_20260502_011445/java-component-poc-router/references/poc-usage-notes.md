# Local PoC usage notes

## Treat YAML PoCs as hypotheses

The local corpus under `Z:\pocs` compresses:

- likely paths
- likely methods
- payload placement
- common success markers

But it also contains:

- duplicates
- stale filenames
- detector-only entries
- community-authored payloads that fit only some versions

## Read these fields first

- `id`
- `info.name`
- `info.description`
- `reference`
- `tags`
- `http.raw` / `path`
- `matchers`
- `extractors`

## Good transformations

### YAML -> browser MCP fetch

Use when:

- cookies/session matter
- same-origin state matters
- the target is SPA-like

### YAML -> raw HTTP replay

Use when:

- exact header syntax matters
- the payload bytes matter
- a browser would normalize the request

### YAML -> reduced manual PoC

Use when:

- one field or header is decisive
- the nuclei template has extra scaffolding you do not need

## Common mistakes

- executing an exploit PoC before proving the component exists
- treating a detector as a vuln proof
- copying an OOB PoC without matching parser family
- trusting the PoC filename more than runtime behavior
