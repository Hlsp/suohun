# Component clue -> PoC family map

## `rememberMe`

- `shiro-default-key-*`
- product-specific shiro default-key PoCs

## `@type`, `autoType is not support`, `com.alibaba.fastjson`

- `fastjson-*`
- vendor fastjson RCE chains
- product fastjson chains

## `.action`, OGNL, multipart parser

- `Apache Struts*`
- `Struts2*`
- product-specific `struts2-rce`

## `/druid/index.html`, SQL monitor clues

- `Alibaba-druid-*`
- `apache-druid-*`
- product-specific druid unauth/default-login

## `/nacos/` or `/nacos/v1/`

- `Alibaba-nacos-*`
- `nacos-*`

## `/geoserver/`, WFS/WPS/WMS/REST

- `GeoServer*`
- `geoserver-*`

## `/solr/`, `/solr/admin/`

- `Apache Solr*`
- `apache-solr-*`

## `/jolokia/`

- `jolokia-*`
- `Jolokia*`

## `/swagger-ui*`, `/doc.html`

- `swagger-ui-*`
- `swagger*`
- `knife4j*`

## Spring Boot 404 shell + mgmt roots

- `springboot-*`
- `Spring Boot Actuator*`
- `Spring Cloud*`
- `Spring-*`
