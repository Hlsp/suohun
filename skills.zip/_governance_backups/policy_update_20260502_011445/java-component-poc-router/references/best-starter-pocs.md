# Best starter PoCs by Java component family

These are **starter** PoCs, not always final exploit choices.

The goal is to pick the shortest high-signal path:

1. detect component
2. verify risky behavior
3. only then try the exploit-class PoC

## Fastjson

### First detector

- there is no single best filename-based detector in the corpus; use runtime `@type` canaries first

### First verify

- `fastjson-1-2-67-rce.yaml`
- `fastjson-1-2-68-rce.yaml`

Use these to study payload family, not to spray blindly.

### Product pivots

- `hikvision-fastjson-rce.yaml`
- `dahua-icc-fastjson-rce.yaml`
- `davinci-fastjson-rce.yaml`

## Shiro

### First detector / verify

- `shiro-default-key-cbc.yaml`
- `若依-ruoyi-shiro-default-key-cbc.yaml`
- `若依-ruoyi-shiro-default-key-gcm.yaml`

These are excellent first checks when `rememberMe` is present.

## Struts

### First detector

- `Apache-struts-problem-report.yaml`
- `Apache-struts-debug-mode.yaml`

### First exploit-family verify

- `Apache Struts 2-Remote Command Execution-CVE-2017-5638.yaml`
- `Apache Struts2 S2-052-Remote Code Execution-CVE-2017-9805.yaml`
- `Apache Struts2 S2-057-Remote Code Execution-CVE-2018-11776.yaml`

Choose based on parser and route clues, not popularity.

## Spring

### First detector

- `springboot-env.yaml`
- `springboot-mappings.yaml`
- `springboot-heapdump.yaml`
- `springboot-jolokia.yaml`

These are route/feature detectors, not proof of deep exploit.

### First exploit-family verify

- `Spring Cloud Gateway Code Injection-CVE-2022-22947.yaml`
- `Spring Cloud-Remote Code Execution-CVE-2022-22963.yaml`
- `Spring-Remote Code Execution-CVE-2022-22965.yaml`

Use only when module clues match.

## Druid

### First detector

- `Alibaba-druid-monitor.yaml`
- `Alibaba-druid-default-login.yaml`
- `apache-druid-unauth.yaml`

### First exploit-family verify

- `Apache Druid-Remote Code Execution-CVE-2021-25646.yaml`
- `Apache Druid-Server-Side Request Forgery-CVE-2025-27888.yaml`

## Nacos

### First detector / verify

- `Alibaba-nacos-default-login.yaml`
- `Alibaba-nacos-authentication-bypass.yaml`
- `alibaba-nacos-default-token.yaml`
- `nacos-bypass-authentication_1.yaml`

### Later exploit

- `Alibaba-nacos-jraftserver-deserialization-rce.yaml`
- `Alibaba-nacos-derby-sql-rce.yaml`

## GeoServer

### First detector

- `geoserver-default-login.yaml`

### First verify / exploit-family

- `GeoServer and GeoTools-Remote Code Execution-CVE-2024-36404.yaml`
- `GeoServer 评估属性名称表达式RCE-CVE-2024-36401.yaml`
- `GeoServer WPS-Server Side Request Forgery-CVE-2023-43795.yaml`

## Solr

### First detector

- `APACHE-solr-query-dashboard.yaml`
- `Apache-solr-unauth.yaml`

### First verify / exploit-family

- `Apache Solr-Authentication Bypass-CVE-2024-45216.yaml`
- `apache-solr-file-read.yaml`
- `Apache Solr -=8.3.1-Remote Code Execution-CVE-2019-17558.yaml`

## Jolokia

### First detector

- `jolokia-list.yaml`
- `jolokia-info-disclosure.yaml`
- `jolokia-mbean-search.yaml`

### First exploit-family

- `jolokia-createstandardhost-rce.yaml`
- `jolokia-file-read-compilerdirectivesadd.yaml`
- `Jolokia Agent-JNDI Code Injection-CVE-2018-1000130.yaml`

## Swagger / Knife4j

### First detector

- use route and docs exposure first

The corpus is thin here:

- `swagger-ui-xss.yaml`

Treat as a specialized follow-up, not the first probe.
