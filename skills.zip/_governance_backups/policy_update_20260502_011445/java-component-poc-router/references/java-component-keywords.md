# Java component search keywords for `Z:\pocs`

## Fastjson

- `fastjson`
- `@type`
- `basicdatasource`

## Shiro

- `shiro`
- `rememberme`
- `default-key`
- `cbc`
- `gcm`

## Struts

- `struts`
- `s2-`
- `ognl`
- `.action`

## Spring

- `springboot`
- `actuator`
- `spring cloud`
- `spring security`
- `spring framework`

## Druid

- `druid`
- `statview`
- `monitor`

## Nacos

- `nacos`
- `auth bypass`
- `default token`
- `default identity`

## GeoServer

- `geoserver`
- `geotools`
- `wfs`
- `wps`
- `wms`

## Solr

- `solr`
- `cores`
- `admin`
- `query`

## Jolokia

- `jolokia`
- `mbean`
- `jndi`
- `list`

## Swagger / Knife4j

- `swagger`
- `swagger-ui`
- `knife4j`
- `doc.html`

## H2

- `h2console`
- `h2-console`
