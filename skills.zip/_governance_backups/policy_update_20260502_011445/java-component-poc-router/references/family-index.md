# Java family PoC index from `Z:\pocs`

This is a quick orientation map for the local corpus, based on filename clustering.

## Approximate family counts

- Fastjson: 17
- Shiro: 4
- Struts: 31
- Spring: 39
- Druid: 31
- Nacos: 15
- GeoServer / GeoTools: 11
- Solr: 14
- Jolokia: 14
- Swagger / Knife4j: 2
- H2: 1
- Log4j family: 48
- Jackson: 1
- XXL-Job: 2

## Important interpretation notes

### Fastjson

The local corpus contains both:

- generic version PoCs such as `fastjson-1-2-67-rce.yaml`
- product-specific fastjson chains

Use generic entries to learn payload family, and product-specific entries when the target product is known.

### Shiro

The corpus is small but high-value:

- default-key or rememberMe style checks

These are excellent early validators when the cookie clue exists.

### Struts

The corpus is rich and mixes:

- OGNL RCE
- parser/header exploit paths
- `.action` product-specific targets

Distinguish framework-level S2 bulletins from product-specific routes.

### Spring

Many entries are detector-style:

- env
- heapdump
- mappings
- trace
- gateway

Use them as route shortlists and behavior hints.

### Druid / Nacos / Solr / GeoServer / Jolokia

These families often include:

- default auth / unauth exposure
- information disclosure
- SSRF / deserialization / RCE variants

Presence-check entries are often the fastest discriminator.

### Log4j

Large count does not mean broad value.

Most are product-wrapped variants of the same JNDI family. Only use them when logging reachability and version clues justify it.
