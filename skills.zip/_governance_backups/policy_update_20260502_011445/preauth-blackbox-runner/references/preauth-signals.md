# Preauth Signals

## Strong anonymous leads

- API responds with user, order, invoice, file, tenant, task, message, or export data without auth.
- Login page exposes configuration with internal API base URLs, app IDs, tenant IDs, or feature flags.
- Public JS contains route tables, request wrappers, source maps, or hardcoded secrets.
- Password reset, invite, SSO, or device binding accepts user-controlled callback, account, tenant, or token fields.
- Download/preview/share accepts object keys, path-like values, or signed URL parameters.

## Half-auth smells

- Response status is 200 but body contains permission error alongside data fragments.
- Anonymous response differs only by object ID or tenant ID.
- Redirect chain sets a session, nonce, device ID, guest token, or CSRF token.
- Public endpoint accepts `userId`, `tenantId`, `role`, `orgId`, `fileId`, `orderId`, or `callback`.
