# Zhang Skill Suite Entry Routing

Generated: 2026-04-29 11:29:18 +0800

## Current Health Snapshot

- Canonical skills root: `C:\Users\zhang\.codex\skills`
- Total skills: **157**
- Duplicate skill names: **0**
- Broken relative skill references: **0**
- Missing `agents/openai.yaml`: **0**
- Python helper scripts checked: **106**, compile failures: **0**

## Top-Level Rule

For your usual Web/SRC/CTF/security work, default to this single top-level router first:

```text
zhang-web-src-default-runner
```

Only use narrower skills directly when the user names them or the scene is already specific.

## Main Entry Priority

| Priority | Entry skill | Use when | Then route to |
|---|---|---|---|
| P0 | `zhang-web-src-default-runner` | Zhang default: Web/SRC, ??, ???/????, ???, ????, Java ?, Burp/Yak/MCP, ???? | `security-test-dispatcher` plus the matching lane |
| P1 | `security-test-dispatcher` | Generic authorized security start prompt, target URL/app, ?????/??/????? | Selects smallest useful chain |
| P1 | `blackbox-pentest-runner` | Real Web/API black-box assessment that needs orchestration and evidence | preauth/auth/API/business/file lanes |
| P1 | `auth-role-matrix-runner` | Credentials, cookies, roles, tenants, A/B accounts, logged-in business logic | object extraction, AB pairs, replay harness |
| P1 | `complex-js-reverse` | `sign`/`data`/`key`/encrypted body/frontend wrapper/anti-debug | request tracing, crypto entry, env patch, helper generation |
| P1 | `miniapp-dynamic-static-runner` | WeChat miniapp, CDP websocket, wxapkg/decompiled source | runtime CDP + static correlation |
| P2 | `ctf-web` | CTF or challenge-style web task | narrow exploit family skill |
| P2 | `pentest-report` / `logic-evidence-pack` | Evidence packaging and report output | results storage/report bridge |

## Scenario Chains

### 1. ?????? / ???? URL

```text
zhang-web-src-default-runner
-> security-test-dispatcher
-> blackbox-pentest-runner
-> preauth-blackbox-runner
-> preauth-js-hidden-logic-hunter if login wall blocks progress
-> extract-frontend-sensitive-info / webpack-runtime-extractor / api-recon-and-docs as evidence demands
```

Default first hypothesis: anonymous list/detail/download/config/API-doc/hidden-JS endpoint with real data or object impact.

### 2. ????? / ? Cookie / ????

```text
zhang-web-src-default-runner
-> blackbox-pentest-runner
-> auth-role-matrix-runner
-> object-identity-extractor
-> ab-object-pair-builder
-> traffic-to-workflow-mapper
-> single-variable-replay-harness
-> logic-evidence-pack
```

Default first hypothesis: BOLA/BOPLA/BFLA, cross-tenant, workflow state, stale token/link, export/share boundary.

### 3. ???? / JS ??

```text
zhang-web-src-default-runner
-> browser-pentest-orchestrator
-> complex-js-reverse
-> request-chain-tracer
-> find-crypto-entry
-> webpack-runtime-extractor
-> protocol-diff-lab
-> browser-crypto-helper-builder / env-patch
```

Default deliverable: runnable HTML/Node/Python helper or raw HTTP generator, verified against one captured sample.

### 4. ???

```text
zhang-web-src-default-runner
-> miniapp-dynamic-static-runner
-> wechat-miniapp-cdp-debug
-> request-chain-tracer
-> object-identity-extractor
-> auth-role-matrix-runner if roles/accounts exist
```

Default first action: correlate runtime network request with page method/storage/token wrapper.

### 5. Java/JVM ??

```text
zhang-web-src-default-runner
-> ghost-bits-java-truncation
-> matching impact skill: upload/file/path/CRLF/deserialization/SQLi/CMDi/SSTI
-> single-variable-replay-harness
```

Use Ghost Bits only as a bounded parser-difference lane; report only when backend semantics diverge and impact is proven.

### 6. Burp/Yak/MCP ????

```text
zhang-web-src-default-runner
-> capture-bootstrap-check
-> burp-mcp-playbook / yak-mcp-playbook
-> burp-scope-traffic-dumper / traffic-to-workflow-mapper
-> traffic-dedupe-prioritizer
-> single-variable-replay-harness
```

Traffic is source of truth. Deduplicate endpoints before expanding tests.

### 7. ?????

```text
logic-evidence-pack
-> results-storage
-> runner-results-bridge
-> pentest-report
```

Report only after baseline, mutation, response/state diff, ownership context, and replay/cleanup notes are captured.

## Conflict Resolution

- If multiple broad routers match, prefer `zhang-web-src-default-runner` and let it dispatch.
- If the user says ????, continue current evidence chain, do not restart recon.
- If a target is available, avoid theory-only output; produce a baseline/action/artifact quickly.
- If endpoint probing is low-yield, switch to JS hidden logic instead of broad fuzzing.
- If signing/encryption appears, recover wrapper before replaying business mutations.
- If logged-in traffic exists, prioritize object/state/tenant variables over generic injection payloads.

## What To Keep As Library Skills

These should usually be loaded only after a concrete sink/hypothesis is found:

- Classic injection specialists: `sqli-sql-injection`, `ssti-server-side-template-injection`, `cmdi-command-injection`, `xxe-xml-external-entity`, `xslt-injection`, `nosql-injection`.
- Protocol/parser specialists: `request-smuggling`, `crlf-injection`, `http-parameter-pollution`, `web-cache-deception`.
- Native/reverse routers: `heap-exploitation`, `stack-overflow-and-rop`, `browser-exploitation-v8`, `kernel-exploitation`, `vm-and-bytecode-reverse`.
- OAuth/JWT/SAML specialists: direct-load only when token/SSO evidence exists.
