# Zhang Skill Suite Cleanup Plan

Generated: 2026-04-29 11:29:18 +0800

## Status

No structural cleanup is required right now.

Validated results:

- `duplicate_names=0`
- `missing_refs=0`
- `missing_openai_yaml=0`
- `content_quality_flagged=0`
- Python helper compile failures: `0` (`106` scripts checked)

## Done By This Batch

- Refreshed `skill-suite-governance/references/scan-summary.json`.
- Refreshed `skill-suite-governance/references/skill-map.generated.md`.
- Refreshed `skill-suite-governance/references/duplicates.generated.md`.
- Refreshed `skill-suite-governance/references/content-quality.generated.md`.
- Added this cleanup plan.
- Added `zhang-skill-suite-routing.generated.md` as the canonical entry/priority map.
- Added `zhang-entry-priority.generated.md` inside `zhang-web-src-default-runner/references/`.

## Do Not Delete These Even If They Overlap

Some overlap is intentional. Keep them as layered routers or specialist references:

- `zhang-web-src-default-runner`: personal P0 entry.
- `security-test-dispatcher`: P1 generic dispatcher.
- `blackbox-pentest-runner`: P1 execution orchestrator.
- `auth-role-matrix-runner`: logged-in A/B execution lane.
- `complex-js-reverse`: frontend crypto/reverse lane.
- `miniapp-dynamic-static-runner`: miniapp lane.
- `ctf-web`: CTF challenge router.

## Future Optional Consolidation

Only consider consolidation if context bloat becomes a real problem:

1. Auth/JWT/OAuth family: keep router + specialist split; do not merge until trigger conflicts are observed.
2. Business logic family: keep `business-logic-vuln` as router and domain-specific skills as references.
3. Web pentest broad routers: prefer priority ordering instead of deletion.
4. Native/pwn skills: keep as low-trigger library skills because they do not affect Web/SRC routing unless explicitly needed.

## Maintenance Command Set

Run these after installing or editing skills:

```powershell
python 'C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\scan_skill_suite.py' --write-reports
python 'C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\content_quality_scan.py' --write-report
python 'C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\compile_python_helpers.py' --write-report
```

## Reload Note

If a new or modified skill does not appear in the active Codex skill list, start a new thread or reload Codex. Files are healthy on disk, but the current thread may have loaded its skill list before the latest filesystem state.
