# Skill Map

Total skills: 161

## auth-api (45)

- `ab-object-pair-builder` - `C:\Users\zhang\.codex\skills\ab-object-pair-builder`
- `account-binding-invite-delegation-abuse` - `C:\Users\zhang\.codex\skills\account-binding-invite-delegation-abuse`
- `account-fixture-manager` - `C:\Users\zhang\.codex\skills\account-fixture-manager`
- `api-fuzzing-bug-bounty` - `C:\Users\zhang\.codex\skills\api-fuzzing-bug-bounty`
- `auth-role-matrix-runner` - `C:\Users\zhang\.codex\skills\auth-role-matrix-runner`
- `auth-sec` - `C:\Users\zhang\.codex\skills\auth-sec`
- `authbypass-authentication-flaws` - `C:\Users\zhang\.codex\skills\authbypass-authentication-flaws`
- `burp-history-to-workflow` - `C:\Users\zhang\.codex\skills\burp-history-to-workflow`
- `burp-mcp-playbook` - `C:\Users\zhang\.codex\skills\burp-mcp-playbook`
- `burp-scope-traffic-dumper` - `C:\Users\zhang\.codex\skills\burp-scope-traffic-dumper`
- `business-logic-vulnerabilities` - `C:\Users\zhang\.codex\skills\business-logic-vulnerabilities`
- `csrf-cross-site-request-forgery` - `C:\Users\zhang\.codex\skills\csrf-cross-site-request-forgery`
- `dangling-markup-injection` - `C:\Users\zhang\.codex\skills\dangling-markup-injection`
- `exploiting-jwt-algorithm-confusion-attack` - `C:\Users\zhang\.codex\skills\exploiting-jwt-algorithm-confusion-attack`
- `extract-frontend-sensitive-info` - `C:\Users\zhang\.codex\skills\extract-frontend-sensitive-info`
- `find-crypto-entry` - `C:\Users\zhang\.codex\skills\find-crypto-entry`
- `graphql-and-hidden-parameters` - `C:\Users\zhang\.codex\skills\graphql-and-hidden-parameters`
- `idor-broken-object-authorization` - `C:\Users\zhang\.codex\skills\idor-broken-object-authorization`
- `jwt-oauth-token-attacks` - `C:\Users\zhang\.codex\skills\jwt-oauth-token-attacks`
- `logic-fix-verification` - `C:\Users\zhang\.codex\skills\logic-fix-verification`
- `miniapp-dynamic-static-runner` - `C:\Users\zhang\.codex\skills\miniapp-dynamic-static-runner`
- `nosql-injection` - `C:\Users\zhang\.codex\skills\nosql-injection`
- `oauth-oidc-misconfiguration` - `C:\Users\zhang\.codex\skills\oauth-oidc-misconfiguration`
- `object-identity-extractor` - `C:\Users\zhang\.codex\skills\object-identity-extractor`
- `open-redirect` - `C:\Users\zhang\.codex\skills\open-redirect`
- `path-traversal-lfi` - `C:\Users\zhang\.codex\skills\path-traversal-lfi`
- `performing-graphql-depth-limit-attack` - `C:\Users\zhang\.codex\skills\performing-graphql-depth-limit-attack`
- `performing-graphql-introspection-attack` - `C:\Users\zhang\.codex\skills\performing-graphql-introspection-attack`
- `performing-graphql-security-assessment` - `C:\Users\zhang\.codex\skills\performing-graphql-security-assessment`
- `performing-jwt-none-algorithm-attack` - `C:\Users\zhang\.codex\skills\performing-jwt-none-algorithm-attack`
- `preauth-blackbox-runner` - `C:\Users\zhang\.codex\skills\preauth-blackbox-runner`
- `saml-sso-assertion-attacks` - `C:\Users\zhang\.codex\skills\saml-sso-assertion-attacks`
- `single-variable-replay-harness` - `C:\Users\zhang\.codex\skills\single-variable-replay-harness`
- `storage-and-key-lineage` - `C:\Users\zhang\.codex\skills\storage-and-key-lineage`
- `testing-api-authentication-weaknesses` - `C:\Users\zhang\.codex\skills\testing-api-authentication-weaknesses`
- `testing-api-for-broken-object-level-authorization` - `C:\Users\zhang\.codex\skills\testing-api-for-broken-object-level-authorization`
- `testing-for-business-logic-vulnerabilities` - `C:\Users\zhang\.codex\skills\testing-for-business-logic-vulnerabilities`
- `testing-for-json-web-token-vulnerabilities` - `C:\Users\zhang\.codex\skills\testing-for-json-web-token-vulnerabilities`
- `testing-jwt-token-security` - `C:\Users\zhang\.codex\skills\testing-jwt-token-security`
- `testing-oauth2-implementation-flaws` - `C:\Users\zhang\.codex\skills\testing-oauth2-implementation-flaws`
- `theluckyone-sec-skills` - `C:\Users\zhang\.codex\skills\theluckyone-sec-skills`
- `type-juggling` - `C:\Users\zhang\.codex\skills\type-juggling`
- `unauthorized-access-common-services` - `C:\Users\zhang\.codex\skills\unauthorized-access-common-services`
- `websocket-security` - `C:\Users\zhang\.codex\skills\websocket-security`
- `workflow-state-diff-lab` - `C:\Users\zhang\.codex\skills\workflow-state-diff-lab`

## business-logic (17)

- `ast-deobfuscate` - `C:\Users\zhang\.codex\skills\ast-deobfuscate`
- `business-logic-vuln` - `C:\Users\zhang\.codex\skills\business-logic-vuln`
- `complex-js-reverse` - `C:\Users\zhang\.codex\skills\complex-js-reverse`
- `exploit-lfi` - `C:\Users\zhang\.codex\skills\exploit-lfi`
- `exploit-sqli` - `C:\Users\zhang\.codex\skills\exploit-sqli`
- `expression-language-injection` - `C:\Users\zhang\.codex\skills\expression-language-injection`
- `feature-priority-scorer` - `C:\Users\zhang\.codex\skills\feature-priority-scorer`
- `http-host-header-attacks` - `C:\Users\zhang\.codex\skills\http-host-header-attacks`
- `logic-race-harness` - `C:\Users\zhang\.codex\skills\logic-race-harness`
- `payment-promo-rewards-abuse` - `C:\Users\zhang\.codex\skills\payment-promo-rewards-abuse`
- `race-condition` - `C:\Users\zhang\.codex\skills\race-condition`
- `request-chain-tracer` - `C:\Users\zhang\.codex\skills\request-chain-tracer`
- `subscription-trial-membership-abuse` - `C:\Users\zhang\.codex\skills\subscription-trial-membership-abuse`
- `tenant-admin-control-plane-abuse` - `C:\Users\zhang\.codex\skills\tenant-admin-control-plane-abuse`
- `traffic-dedupe-prioritizer` - `C:\Users\zhang\.codex\skills\traffic-dedupe-prioritizer`
- `upload-insecure-files` - `C:\Users\zhang\.codex\skills\upload-insecure-files`
- `wechat-miniapp-cdp-debug` - `C:\Users\zhang\.codex\skills\wechat-miniapp-cdp-debug`

## file (4)

- `arbitrary-write-to-rce` - `C:\Users\zhang\.codex\skills\arbitrary-write-to-rce`
- `csp-bypass-advanced` - `C:\Users\zhang\.codex\skills\csp-bypass-advanced`
- `file-access-vuln` - `C:\Users\zhang\.codex\skills\file-access-vuln`
- `xss-cross-site-scripting` - `C:\Users\zhang\.codex\skills\xss-cross-site-scripting`

## frontend-reverse (10)

- `anti-debug-frontend-bypass` - `C:\Users\zhang\.codex\skills\anti-debug-frontend-bypass`
- `browser-crypto-helper-builder` - `C:\Users\zhang\.codex\skills\browser-crypto-helper-builder`
- `capture-bootstrap-check` - `C:\Users\zhang\.codex\skills\capture-bootstrap-check`
- `clickjacking` - `C:\Users\zhang\.codex\skills\clickjacking`
- `code-obfuscation-deobfuscation` - `C:\Users\zhang\.codex\skills\code-obfuscation-deobfuscation`
- `crlf-injection` - `C:\Users\zhang\.codex\skills\crlf-injection`
- `env-patch` - `C:\Users\zhang\.codex\skills\env-patch`
- `exploit-xss` - `C:\Users\zhang\.codex\skills\exploit-xss`
- `protocol-diff-lab` - `C:\Users\zhang\.codex\skills\protocol-diff-lab`
- `signature-vs-encryption-triage` - `C:\Users\zhang\.codex\skills\signature-vs-encryption-triage`

## governance (17)

- `blackbox-pentest-runner` - `C:\Users\zhang\.codex\skills\blackbox-pentest-runner`
- `burp-finding-bridge` - `C:\Users\zhang\.codex\skills\burp-finding-bridge`
- `csv-formula-injection` - `C:\Users\zhang\.codex\skills\csv-formula-injection`
- `export-preview-sharing-logic-abuse` - `C:\Users\zhang\.codex\skills\export-preview-sharing-logic-abuse`
- `logic-evidence-pack` - `C:\Users\zhang\.codex\skills\logic-evidence-pack`
- `mcp-frontend-security-audit` - `C:\Users\zhang\.codex\skills\mcp-frontend-security-audit`
- `pentest-business-logic-abuse` - `C:\Users\zhang\.codex\skills\pentest-business-logic-abuse`
- `pentest-report` - `C:\Users\zhang\.codex\skills\pentest-report`
- `performing-web-application-penetration-test` - `C:\Users\zhang\.codex\skills\performing-web-application-penetration-test`
- `results-storage` - `C:\Users\zhang\.codex\skills\results-storage`
- `runner-results-bridge` - `C:\Users\zhang\.codex\skills\runner-results-bridge`
- `security-bounty-hunter` - `C:\Users\zhang\.codex\skills\security-bounty-hunter`
- `security-test-dispatcher` - `C:\Users\zhang\.codex\skills\security-test-dispatcher`
- `skill-suite-governance` - `C:\Users\zhang\.codex\skills\skill-suite-governance`
- `sqli-sql-injection` - `C:\Users\zhang\.codex\skills\sqli-sql-injection`
- `ssti-server-side-template-injection` - `C:\Users\zhang\.codex\skills\ssti-server-side-template-injection`
- `zhang-web-src-default-runner` - `C:\Users\zhang\.codex\skills\zhang-web-src-default-runner`

## injection-server (6)

- `exploiting-http-request-smuggling` - `C:\Users\zhang\.codex\skills\exploiting-http-request-smuggling`
- `jndi-injection` - `C:\Users\zhang\.codex\skills\jndi-injection`
- `performing-blind-ssrf-exploitation` - `C:\Users\zhang\.codex\skills\performing-blind-ssrf-exploitation`
- `prototype-pollution` - `C:\Users\zhang\.codex\skills\prototype-pollution`
- `prototype-pollution-advanced` - `C:\Users\zhang\.codex\skills\prototype-pollution-advanced`
- `request-smuggling` - `C:\Users\zhang\.codex\skills\request-smuggling`

## other (8)

- `api-sec` - `C:\Users\zhang\.codex\skills\api-sec`
- `dependency-confusion` - `C:\Users\zhang\.codex\skills\dependency-confusion`
- `email-header-injection` - `C:\Users\zhang\.codex\skills\email-header-injection`
- `http-parameter-pollution` - `C:\Users\zhang\.codex\skills\http-parameter-pollution`
- `insecure-source-code-management` - `C:\Users\zhang\.codex\skills\insecure-source-code-management`
- `performing-web-cache-poisoning-attack` - `C:\Users\zhang\.codex\skills\performing-web-cache-poisoning-attack`
- `src-high-value-logic-hunting` - `C:\Users\zhang\.codex\skills\src-high-value-logic-hunting`
- `web-cache-deception` - `C:\Users\zhang\.codex\skills\web-cache-deception`

## recon (21)

- `api-authorization-and-bola` - `C:\Users\zhang\.codex\skills\api-authorization-and-bola`
- `api-recon-and-docs` - `C:\Users\zhang\.codex\skills\api-recon-and-docs`
- `cmdi-command-injection` - `C:\Users\zhang\.codex\skills\cmdi-command-injection`
- `cors-cross-origin-misconfiguration` - `C:\Users\zhang\.codex\skills\cors-cross-origin-misconfiguration`
- `deserialization-insecure` - `C:\Users\zhang\.codex\skills\deserialization-insecure`
- `exploit-file-download` - `C:\Users\zhang\.codex\skills\exploit-file-download`
- `ghost-bits-java-truncation` - `C:\Users\zhang\.codex\skills\ghost-bits-java-truncation`
- `httpx-url-dashboard` - `C:\Users\zhang\.codex\skills\httpx-url-dashboard`
- `portal-workflow-task-abuse` - `C:\Users\zhang\.codex\skills\portal-workflow-task-abuse`
- `recon-dir-scan` - `C:\Users\zhang\.codex\skills\recon-dir-scan`
- `recon-fingerprint` - `C:\Users\zhang\.codex\skills\recon-fingerprint`
- `recon-for-sec` - `C:\Users\zhang\.codex\skills\recon-for-sec`
- `recon-port-scan` - `C:\Users\zhang\.codex\skills\recon-port-scan`
- `recon-subdomain` - `C:\Users\zhang\.codex\skills\recon-subdomain`
- `ssrf-server-side-request-forgery` - `C:\Users\zhang\.codex\skills\ssrf-server-side-request-forgery`
- `subdomain-takeover` - `C:\Users\zhang\.codex\skills\subdomain-takeover`
- `traffic-to-workflow-mapper` - `C:\Users\zhang\.codex\skills\traffic-to-workflow-mapper`
- `webpack-runtime-extractor` - `C:\Users\zhang\.codex\skills\webpack-runtime-extractor`
- `xslt-injection` - `C:\Users\zhang\.codex\skills\xslt-injection`
- `xxe-xml-external-entity` - `C:\Users\zhang\.codex\skills\xxe-xml-external-entity`
- `yak-mcp-playbook` - `C:\Users\zhang\.codex\skills\yak-mcp-playbook`

## routing-methodology (28)

- `anti-debugging-techniques` - `C:\Users\zhang\.codex\skills\anti-debugging-techniques`
- `api-auth-and-jwt-abuse` - `C:\Users\zhang\.codex\skills\api-auth-and-jwt-abuse`
- `binary-protection-bypass` - `C:\Users\zhang\.codex\skills\binary-protection-bypass`
- `blackbox-business-logic-hunter` - `C:\Users\zhang\.codex\skills\blackbox-business-logic-hunter`
- `blackbox-business-shape-router` - `C:\Users\zhang\.codex\skills\blackbox-business-shape-router`
- `bounty-hunter-pro` - `C:\Users\zhang\.codex\skills\bounty-hunter-pro`
- `browser-exploitation-v8` - `C:\Users\zhang\.codex\skills\browser-exploitation-v8`
- `browser-pentest-orchestrator` - `C:\Users\zhang\.codex\skills\browser-pentest-orchestrator`
- `bug-bounty-hunter` - `C:\Users\zhang\.codex\skills\bug-bounty`
- `ctf-web` - `C:\Users\zhang\.codex\skills\ctf-web`
- `format-string-exploitation` - `C:\Users\zhang\.codex\skills\format-string-exploitation`
- `hack` - `C:\Users\zhang\.codex\skills\hack`
- `heap-exploitation` - `C:\Users\zhang\.codex\skills\heap-exploitation`
- `injection-checking` - `C:\Users\zhang\.codex\skills\injection-checking`
- `java-component-poc-router` - `C:\Users\zhang\.codex\skills\java-component-poc-router`
- `java-third-party-component-hunter` - `C:\Users\zhang\.codex\skills\java-third-party-component-hunter`
- `kernel-exploitation` - `C:\Users\zhang\.codex\skills\kernel-exploitation`
- `local-tool-arsenal-router` - `C:\Users\zhang\.codex\skills\local-tool-arsenal-router`
- `pentest-redteam-master` - `C:\Users\zhang\.codex\skills\pentest-redteam-master`
- `pentest-workbench` - `C:\Users\zhang\.codex\skills\pentest-workbench`
- `preauth-js-hidden-logic-hunter` - `C:\Users\zhang\.codex\skills\preauth-js-hidden-logic-hunter`
- `recon-and-methodology` - `C:\Users\zhang\.codex\skills\recon-and-methodology`
- `sandbox-escape-techniques` - `C:\Users\zhang\.codex\skills\sandbox-escape-techniques`
- `secknowledge-skill` - `C:\Users\zhang\.codex\skills\secknowledge-skill`
- `stack-overflow-and-rop` - `C:\Users\zhang\.codex\skills\stack-overflow-and-rop`
- `symbolic-execution-tools` - `C:\Users\zhang\.codex\skills\symbolic-execution-tools`
- `vm-and-bytecode-reverse` - `C:\Users\zhang\.codex\skills\vm-and-bytecode-reverse`
- `waf-bypass-techniques` - `C:\Users\zhang\.codex\skills\waf-bypass-techniques`

## system (5)

- `imagegen` - `C:\Users\zhang\.codex\skills\.system\imagegen`
- `openai-docs` - `C:\Users\zhang\.codex\skills\.system\openai-docs`
- `plugin-creator` - `C:\Users\zhang\.codex\skills\.system\plugin-creator`
- `skill-creator` - `C:\Users\zhang\.codex\skills\.system\skill-creator`
- `skill-installer` - `C:\Users\zhang\.codex\skills\.system\skill-installer`
