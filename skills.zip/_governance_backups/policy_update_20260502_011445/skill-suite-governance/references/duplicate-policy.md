# Duplicate Skill Policy

## Canonical Preference

1. Prefer `C:\Users\zhang\.codex\skills\<skill>` as canonical.
2. Treat `C:\Users\zhang\.agents\skills\<skill>` copies as compatibility mirrors unless the user says otherwise.
3. Do not delete mirrors automatically; patch their relative links to point at canonical dependencies when needed.
4. If two copies diverge, keep the richer and newer one as canonical, then add a note in the duplicate report.

## Safe Cleanup Ladder

1. Detect duplicate names.
2. Compare frontmatter and headings.
3. Pick canonical path.
4. Patch inbound references to canonical path.
5. Only after repeated successful validation, consider archive/move rather than delete.
