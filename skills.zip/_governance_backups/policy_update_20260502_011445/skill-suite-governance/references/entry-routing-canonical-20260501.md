# Canonical Entry Routing 2026-05-01

Use this to avoid skill-suite noise after optimization.

## Default P0

For Zhang's usual Web/SRC/CTF/security work, start with:

```text
zhang-web-src-default-runner
```

Only load a narrower skill directly when the user names it or the scene is already specific.

## Stable Main Entries

1. `zhang-web-src-default-runner` - personal Web/SRC/CTF default and high-impact bias.
2. `security-test-dispatcher` - generic authorized security start prompt.
3. `blackbox-pentest-runner` - Web/API orchestration and evidence loop.
4. `complex-js-reverse` - frontend signing/encryption/replay recovery.
5. `ctf-web` - challenge-style Web exploitation.
6. `skill-suite-governance` - suite validation, reports, and cleanup.

## Direct-Load Specialists

Load specialists only after concrete evidence exists: injection, auth/API, business logic, frontend reverse, file/upload, or native/reverse primitives.

## Maintenance Rule

After editing skills, run:

```powershell
python C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\scan_skill_suite.py --root C:\Users\zhang\.codex\skills --write-reports
python C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\content_quality_scan.py --root C:\Users\zhang\.codex\skills --write-report
python C:\Users\zhang\.codex\skills\skill-suite-governance\scripts\mojibake_scan.py --root C:\Users\zhang\.codex\skills --write-report
```
