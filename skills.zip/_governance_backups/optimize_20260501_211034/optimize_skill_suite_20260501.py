from pathlib import Path
import textwrap

root = Path(r"C:\Users\zhang\.codex\skills")


def w(skill: str, text: str) -> None:
    p = root / skill / "SKILL.md"
    p.write_text(textwrap.dedent(text).strip() + "\n", encoding="utf-8")


def ref(skill: str, name: str, text: str) -> None:
    d = root / skill / "references"
    d.mkdir(parents=True, exist_ok=True)
    (d / name).write_text(textwrap.dedent(text).strip() + "\n", encoding="utf-8")


def preserve_and_split_long_entries() -> None:
    z = root / "zhang-web-src-default-runner" / "SKILL.md"
    old = z.read_text(encoding="utf-8")
    ref(
        "zhang-web-src-default-runner",
        "legacy-full-entry-router-20260501.md",
        "# Legacy Full Entry Router 2026-05-01\n\n"
        "This preserves the pre-optimization detailed router body for lookup. "
        "Prefer `SKILL.md` plus focused references for normal use.\n\n"
        + old,
    )
    sections = {
        "no-hint-startup-contract.md": "## No-hint URL startup contract",
        "first-10-minute-routing-contract.md": "## First-10-Minute Routing Contract",
        "autonomous-business-understanding-contract.md": "## Autonomous Business Understanding Contract",
        "default-skill-chains.md": "## Default skill chains",
        "decision-loop-and-evidence-standard.md": "## Decision loop",
    }
    positions = []
    for name, heading in sections.items():
        idx = old.find(heading)
        if idx != -1:
            positions.append((idx, name, heading))
    positions.sort()
    for i, (idx, name, heading) in enumerate(positions):
        end = positions[i + 1][0] if i + 1 < len(positions) else len(old)
        ref(
            "zhang-web-src-default-runner",
            name,
            "# " + heading.replace("## ", "") + "\n\n" + old[idx:end].strip(),
        )

    s = root / "src-high-value-logic-hunting" / "SKILL.md"
    old2 = s.read_text(encoding="utf-8")
    ref(
        "src-high-value-logic-hunting",
        "legacy-full-high-value-logic-20260501.md",
        "# Legacy Full High-Value Logic Playbook 2026-05-01\n\n"
        "This preserves the pre-optimization detailed playbook. "
        "Prefer `SKILL.md` plus focused references for normal use.\n\n"
        + old2,
    )
    idx = old2.find("## Proven Hunting Patterns")
    if idx != -1:
        ref(
            "src-high-value-logic-hunting",
            "proven-hunting-patterns.md",
            "# Proven Hunting Patterns\n\n" + old2[idx:].strip(),
        )
    idx2 = old2.find("## SPA Portal and Bridge Patterns")
    if idx2 != -1:
        ref(
            "src-high-value-logic-hunting",
            "spa-portal-bridge-patterns.md",
            "# SPA Portal and Bridge Patterns\n\n" + old2[idx2:].strip(),
        )


def write_core_routers() -> None:
    w("hack", """
---
name: hack
description: "Entry P0 primary router for HackSkills and authorized security testing. Use when the task involves 开始测试, 开始挖, 黑盒测试, 渗透测试, 漏洞挖掘, SRC, bug bounty, Web/API security assessment, recon, vulnerability triage, exploit path planning, or choosing the right next category skill before any deep topic skill."
---

# HackSkills Main Router

Use this as the broad security router when the task is authorized security testing but the exact category is not yet clear. Prefer [zhang-web-src-default-runner](../zhang-web-src-default-runner/SKILL.md) for Zhang's usual Web/SRC/CTF workflow and [security-test-dispatcher](../security-test-dispatcher/SKILL.md) for generic start prompts.

## Routing First

1. Identify the scene before loading deep skills:
   - no-login black-box
   - logged-in black-box
   - mini-program dynamic/static
   - API/auth/object authorization
   - business logic workflow
   - injection/file/upload/client-side class
2. Select the smallest skill chain that can produce evidence.
3. Establish baseline and capture quality before mutation.
4. Verify one variable at a time.
5. Package evidence and replay steps.

## Primary Entrypoints

- Zhang default Web/SRC/CTF workflow: [zhang-web-src-default-runner](../zhang-web-src-default-runner/SKILL.md)
- Start-test natural prompt: [security-test-dispatcher](../security-test-dispatcher/SKILL.md)
- End-to-end black-box Web/API: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- No-login black-box: [preauth-blackbox-runner](../preauth-blackbox-runner/SKILL.md)
- Logged-in role/tenant matrix: [auth-role-matrix-runner](../auth-role-matrix-runner/SKILL.md)
- Mini-program dynamic/static: [miniapp-dynamic-static-runner](../miniapp-dynamic-static-runner/SKILL.md)
- Burp MCP workflow: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- API security: [api-sec](../api-sec/SKILL.md)
- Recon: [recon-for-sec](../recon-for-sec/SKILL.md)
- Injection: [injection-checking](../injection-checking/SKILL.md)
- Auth/session: [auth-sec](../auth-sec/SKILL.md)
- File access: [file-access-vuln](../file-access-vuln/SKILL.md)

## Quick Category Map

| Evidence | Route |
|---|---|
| Only URL, no credentials | preauth-blackbox-runner |
| Login available, multiple accounts, roles, tenants | auth-role-matrix-runner |
| WeChat miniapp, remote debugging, wxapkg source | miniapp-dynamic-static-runner |
| Burp history / proxy / repeater | burp-mcp-playbook + traffic skills |
| Endpoint probing low-yield but JS is available | preauth-js-hidden-logic-hunter |
| Object IDs, tenant IDs, file keys | object-identity-extractor + ab-object-pair-builder |
| JWT/OAuth/session/token | api-auth-and-jwt-abuse / jwt-oauth-token-attacks |
| IDOR/BOLA/BFLA | api-authorization-and-bola / idor-broken-object-authorization |
| Payment/coupon/member/trial/reward/workflow | business logic domain skills |
| Reflected/stored input | xss-cross-site-scripting / ssti / injection skills |
| File upload/download/preview/export/share | upload/file/export skills |

## Startup Output

When this router is used, respond with inferred task scene, selected skill chain, first concrete step, and current blocker or pivot condition.
""")

    w("blackbox-pentest-runner", """
---
name: blackbox-pentest-runner
description: "End-to-end AI black-box pentest runner. Use when the user says 黑盒测试, 开始测试 this target, 帮我测一下, Web/API 渗透测试, SRC 挖洞, or when orchestrating an authorized Web/API assessment across no-login preauth discovery, logged-in role/tenant matrix testing, Burp/browser traffic capture, workflow mapping, high-value feature scoring, single-variable mutation, evidence packaging, finding scoring, storage, and report handoff."
---

# Blackbox Pentest Runner

Use this skill as the top-level loop for an authorized black-box web/API assessment. It coordinates other skills; it does not replace them.

## Source Preference

1. Burp MCP live history when available.
2. Browser MCP/runtime inspection when rendered state, storage, or frontend crypto matters.
3. HAR/raw HTTP exports when MCP tools are unavailable.
4. Source or static assets only to explain observed runtime behavior.

## Operating Loop

1. Scope Gate: capture target, allowed assets, accounts, roles, rate limits, exclusions, and cleanup constraints.
2. Capture Bootstrap: verify Burp/browser capture readiness before assuming traffic is missing.
3. Runtime Map: collect live routes, APIs, browser flows, storage, auth states, and high-value workflows.
4. Account Matrix: prepare A/B same-role accounts and tenant/role variants when available.
5. Traffic Mapping: convert Burp/HAR/raw/browser flows into workflow and hypothesis artifacts.
6. Dedupe/Prioritize: collapse noise and rank state-changing business workflows.
7. Hypothesis Selection: choose one narrow test hypothesis.
8. Single-Variable Test: change only one ID, role, tenant, status, token, amount, step, or timing dimension.
9. Evidence Pack: save baseline, mutation, before/after state, impact, and cleanup.
10. Results Bridge: export confirmed findings to storage/report formats.
11. Decision: confirm, pivot, retry with one new variable, or abandon with reason.

## Scenario Entrypoints

- No login / anonymous target: [preauth-blackbox-runner](../preauth-blackbox-runner/SKILL.md)
- Logged-in target with accounts, roles, tenants, objects, or workflow states: [auth-role-matrix-runner](../auth-role-matrix-runner/SKILL.md)
- WeChat mini-program with remote debugging and decompiled source: [miniapp-dynamic-static-runner](../miniapp-dynamic-static-runner/SKILL.md)

## Required Run Files

Initialize a run workspace when the assessment will last more than one turn:

```bash
python scripts/init_run_workspace.py --out runs/example --target example
```

The script creates target profile, account matrix, workflow map, hypothesis queue, findings, traffic sources, and raw/evidence/notes directories. Templates are under `references/`.

## Routing Rules

- Capture readiness: [capture-bootstrap-check](../capture-bootstrap-check/SKILL.md)
- Burp/Yak traffic: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md), [yak-mcp-playbook](../yak-mcp-playbook/SKILL.md), [traffic-to-workflow-mapper](../traffic-to-workflow-mapper/SKILL.md)
- Browser-heavy app: [browser-pentest-orchestrator](../browser-pentest-orchestrator/SKILL.md)
- API: [api-sec](../api-sec/SKILL.md), [api-fuzzing-bug-bounty](../api-fuzzing-bug-bounty/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- Auth/session/token: [api-auth-and-jwt-abuse](../api-auth-and-jwt-abuse/SKILL.md)
- BOLA/IDOR: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Files/export/share: [export-preview-sharing-logic-abuse](../export-preview-sharing-logic-abuse/SKILL.md)
- Single-variable replay: [single-variable-replay-harness](../single-variable-replay-harness/SKILL.md)
- Evidence packaging: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)

## Output Discipline

```text
SCENE:
SKILL_CHAIN:
BASELINE:
HYPOTHESIS:
VARIABLE:
EVIDENCE_OR_BLOCKER:
NEXT:
```

Do not answer with a generic vulnerability checklist after a target or traffic sample is available.
""")

    w("zhang-web-src-default-runner", """
---
name: zhang-web-src-default-runner
description: Personal high-priority Web/SRC vulnerability hunting entry skill for Zhang. Use when the user says 开始测试, 开始挖, 挖洞, 漏洞挖掘, Web安全, SRC, 逻辑漏洞, 黑盒测试, 帮我测一下, 自己选择skills, 按我的默认策略, 不要低危, Java站, 前端逆向, 小程序远程调试, Burp/Yak/MCP 流量, or provides a target URL/app and wants Codex to choose the right skills and drive the assessment. Routes to black-box no-login, logged-in A/B role testing, frontend JS reverse, Java Ghost Bits bypass, API/auth/business logic, file/upload/RCE, mini-program, evidence packaging, and reporting workflows.
metadata:
  short-description: Zhang Web/SRC default entry router
---

# Zhang Web/SRC Default Runner

This is the user's personal P0 entry skill for authorized Web/SRC, logic-vulnerability, frontend reverse, Java bypass, CTF/web-lab, and browser/Burp/Yak-assisted work.

## Non-Negotiable Defaults

- Reply in Simplified Chinese. Keep commands, identifiers, paths, and logs in original language.
- Pick the relevant skills yourself; do not ask the user to manually choose when the scene is inferable.
- Prioritize high-impact findings: anonymous object/data/file access, upload/import/report/job-to-RCE chains, auth/BOLA/tenant breaks, workflow state abuse, token bridge misuse, hidden high-risk APIs, and Java parser/WAF bypass routes.
- Avoid low-value noise: banner trivia, generic login wording, clickjacking without sensitive action, scanner-only results, and unproven WAF bypass.
- Prefer live runtime evidence: browser/Burp/Yak traffic, request initiators, storage/cookies, real request bodies, and response/state diffs.
- Test one variable at a time and keep baseline, mutation, response diff, state proof, and cleanup notes.
- If the user says “继续”, continue the current evidence chain instead of restarting methodology.
- If request signing/encryption exists, recover the wrapper before replaying business mutations.
- For logged-in encrypted SPAs: traffic slice -> decrypt helper -> object map -> one-variable replay. Do not blind-fuzz IDs first.

## Startup Contract

1. Infer the scene: no-login black-box, logged-in black-box, mini-program, frontend crypto/reverse, Java/JVM, Burp/Yak traffic-driven, source/code-audit, CTF, or report/evidence.
2. Announce one short skill chain, not a long checklist.
3. Establish the first live baseline: browser page, Burp/Yak history, raw request, source entrypoint, or mini-program CDP page.
4. Select one high-value hypothesis and one decisive next action.
5. Create or reuse a run directory when the work will last more than one turn or produce replay evidence.

Use `references/live-run-protocol.md` as the execution contract for live targets. If a previous run drifted or stalled, read `references/postmortem-encrypted-logged-in-spa-20260430.md` before resuming.

## Main Routing Matrix

| Scene / evidence | Skill chain |
|---|---|
| Only URL, no account, login page | `security-test-dispatcher` -> `blackbox-pentest-runner` -> `preauth-blackbox-runner` -> `browser-pentest-orchestrator` |
| Logged-in cookies/accounts/roles/tenants | `blackbox-pentest-runner` -> `auth-role-matrix-runner` -> `object-identity-extractor` -> `ab-object-pair-builder` -> `single-variable-replay-harness` |
| API/Swagger/OpenAPI/GraphQL/mobile backend | `api-sec` -> `api-recon-and-docs` -> `api-authorization-and-bola` -> `single-variable-replay-harness` |
| Payment/coupon/member/approval/workflow | `blackbox-business-logic-hunter` -> matching domain skill -> `workflow-state-diff-lab` |
| Upload/import/export/preview/share/file | `file-access-vuln` -> `upload-insecure-files` or `export-preview-sharing-logic-abuse` -> `arbitrary-write-to-rce` when a write primitive exists |
| Java/JVM clues | `java-third-party-component-hunter` -> `java-component-poc-router` -> `ghost-bits-java-truncation` only for a concrete sink |
| Frontend sign/encrypt/decrypt/anti-debug | `browser-pentest-orchestrator` -> `complex-js-reverse` -> `request-chain-tracer` -> `find-crypto-entry` -> `env-patch` or helper builder |
| WeChat mini-program/CDP/wxapkg | `miniapp-dynamic-static-runner` -> `wechat-miniapp-cdp-debug` -> `request-chain-tracer` -> `object-identity-extractor` |
| Burp/Yak/HAR traffic exists | `capture-bootstrap-check` -> `burp-mcp-playbook`/`yak-mcp-playbook` -> `traffic-to-workflow-mapper` -> `traffic-dedupe-prioritizer` |
| Need evidence/report | `logic-evidence-pack` -> `results-storage` -> `runner-results-bridge` -> `pentest-report` |
| CTF Web challenge | `ctf-web` -> narrow exploit family skill |

## First-Cycle Minimum Output

```text
MODE:
WHY:
SKILLS:
LANE_A:
LANE_B:
FIRST_ARTIFACT:
DECISIVE_TEST:
```

For bare URL / no-hint black-box, also include:

```text
SITE_SHAPE:
RUNTIME_CLUES:
LIKELY_COMPONENTS:
HIGH_VALUE_FEATURES:
FIRST_DETECTOR_OR_POC_LANE:
NEXT_DECISIVE_PROBE:
```

## Decision Loop

Each test cycle: pick one high-value feature, capture baseline, mutate exactly one variable, compare server-side data/state, then confirm, pivot, retry one new variable, abandon with reason, or package evidence.

## Focused References

- `references/no-hint-startup-contract.md`: bare URL / no-hint startup details.
- `references/first-10-minute-routing-contract.md`: early routing and lane discipline.
- `references/autonomous-business-understanding-contract.md`: business model and stop conditions.
- `references/default-skill-chains.md`: expanded scenario chains.
- `references/decision-loop-and-evidence-standard.md`: per-cycle output and evidence requirements.
- `references/src-high-value-pattern-bank-2026.md`: high-value SRC pattern bank.
- `references/high-imagination-hypothesis-bank.md`: creativity pass before giving up.
- `references/pivot-rules-no-hint-blackbox.md`: evidence-driven pivots.
- `references/routing-matrix.md`, `references/scenario-prompts.md`, `references/evidence-standard.md`: fixed formats.
- `templates/target-run/README.md`: run setup template.
""")

    w("src-high-value-logic-hunting", """
---
name: src-high-value-logic-hunting
description: >-
  Hunt top-tier SRC-grade business logic flaws in authorized Web, portal, eHall,
  workflow, and cross-system integration targets. Use when the goal is to find
  high-impact logic chains such as anonymous widget exposure, object-level task
  and profile leakage, reusable token leakage, cross-system API reuse,
  server-side expression execution, hidden read/write primitives, task-center or
  workflow data abuse, and cross-user state changes. Prefer this skill when
  scanner-style testing underperforms and the real opportunity is to prove one
  narrow end-to-end chain from portal entry to sensitive business object,
  workflow form, token reuse, or unauthorized write operation.
---

# SRC High-Value Logic Hunting

Use this skill to hunt reportable, high-signal business logic flaws in portal-style systems, workflow platforms, and cross-system integrations.

## High-Value Targets

- anonymous portal widgets and landing pages
- cross-system bridges from portal to eHall, OA, mail, card, asset, or internal apps
- hidden detail pages reached by `entry`, `taskId`, `sid`, `uid`, `gh`, `xh`, `bindid`, `ext1-5`, or similar keys
- server-side formula/expression endpoints such as `magicportal_expression`
- workflow/task APIs reachable with leaked/reflected tokens
- favorites, subscriptions, search history, recent-use, and task-center state changes
- identity switch, delegate, or multi-account entry points

## Core Rules

- Start with runtime behavior, not source guesses.
- Prove one narrow end-to-end chain over wide shallow probing.
- Model actors, assets, workflow states, trust boundaries, and invariants.
- Maintain one grounded weird-chain lane in parallel with the obvious list/detail/upload lane.
- Separate read scope and write scope; prove each independently.
- Treat malformed-object errors as chances to recover upstream URLs, tokens, or routing logic.
- For writes: self-write first, cross-user write second, rollback when possible.
- Do not burn time on public content, empty lists, login redirects, or speculative SQLi unless they unlock a stronger chain.

## Imagination Prompts

- Can a token from one subsystem be reused in another subsystem behind the same gateway?
- Can a low-risk object ID unlock a higher-risk action endpoint hidden from the UI?
- Can a signed file URL or upload result become a stable object key for another endpoint?
- Can frontend-only route guards hide admin, approval, or export endpoints that still accept visitor tokens?
- Can object-existence oracles guide a later BOLA proof?
- Can a response decryptor turn one UI view into an offline object corpus?
- Can status fields be replayed out of order or paired with a different action endpoint?

## Validation Ladder

1. Anonymous page or API access.
2. Cross-object read by changing one identifier.
3. Sensitive field disclosure.
4. Reusable token or bridge credential recovery.
5. Token reuse outside the original page/session.
6. Additional users/workflows with the same token.
7. Full workflow/process/form data.
8. Write primitive.
9. Cross-user write with the smallest safe action.

## Strong SRC Outcomes

Treat as top-tier: reusable cross-system token leakage, arbitrary cross-user task/process enumeration, full workflow form data disclosure, private records/credentials, cross-user state changes, and anonymous or under-authenticated object creation/update.

## Required Evidence

Capture entry page, exact trust-boundary request, changed object identifier, before/after behavior, leaked token/upstream route if present, browserless replay, sensitive fields or state changes, read/write classification, and rollback notes.

## Resource Map

- `references/proven-hunting-patterns.md`: portal widget, malformed ID token leak, task-center, expression, write-state, SPA/bridge patterns.
- `references/spa-portal-bridge-patterns.md`: route/chunk/component mapping, object-chain recovery, iframe/jumpLink bridge tests, client-side gate bypass, unstable response triage.
- `references/high-value-playbook.md`: full operating playbook.
- `references/portal-workflow-patterns.md`: portal/eHall-specific logic patterns.
- `references/evidence-and-severity.md`: evidence preservation and severity.
- `scripts/build_uishow_showval.py`: generate `showVal` for widget/object tests.
- `scripts/extract_token_from_error.py`: recover upstream tokens from error text.
- `scripts/ehall_token_reader.py`: replay leaked eHall tokens against task/process APIs.
""")


def write_mojibake_rewrites() -> None:
    w("secknowledge-skill", """
---
name: secknowledge-skill
description: "Web+AI security testing knowledge-base router. Use for authorized Web, API, Agent, MCP, RAG, LLM, and AI-application security assessments when you need scenario-specific references from the bundled knowledge base. Do not use for simple concept explanations or generic coding/debugging tasks."
---

# SecKnowledge Skill

Use this skill as a reference router, not as a replacement for live evidence. It is useful when an authorized Web or AI-security task needs methodology, risk taxonomy, or payload/reference lookup from the bundled `references/` files.

## Trigger Conditions

Use only when all are true:

1. The task intent is security assessment, audit, exploitation in a CTF/sandbox, or vulnerability validation.
2. A concrete target, codebase, API, model, agent, MCP server, RAG system, or traffic sample exists.
3. The question benefits from the bundled Web/AI references rather than normal reasoning alone.

Do not trigger for concept Q&A, ordinary code/debug work, deep source-sink code audit better handled by another workflow, or fresh CVE/doc lookup that needs current sources.

## Reference Navigation

| Scene | Reference |
|---|---|
| SQLi, XSS, command injection, XXE, deserialization | `references/web-injection.md` |
| Authorization, account, payment, reset, business logic | `references/web-logic-auth.md` |
| Upload, traversal, SSRF, information disclosure | `references/web-file-infra.md` |
| CORS, GraphQL, HTTP smuggling, WebSocket, OAuth | `references/web-modern-protocols.md` |
| Supply chain, deployment, cloud, CI/CD, framework clues | `references/web-deployment-security.md` |
| Prompt injection, MCP, agent, AI app risks | `references/ai-app-security.md` |
| Model, jailbreak, adversarial, model-theft risks | `references/ai-model-security.md` |
| RAG/data leakage, data poisoning, exfiltration | `references/ai-data-security.md` |
| Identity, permission, role, session, agent impersonation | `references/ai-identity-security.md` |
| Infra, sandbox, container, supply-chain risks | `references/ai-baseline-security.md` |
| GAARM risk lookup | `references/gaarm-risk-matrix.md` |
| Methodology and OWASP mappings | `references/testing-methodology.md` |
| Payload lookup | `references/payloads.md` |

## Operating Rules

- Start from live runtime behavior, captured traffic, or source evidence; use references to enrich hypotheses.
- Mark the difference between hypothesis and confirmed finding.
- Do not invent CVE IDs, GAARM IDs, OWASP mappings, or payload provenance.
- Keep outputs short: scenario, selected references, 3-5 hypotheses, and next decisive validation step.

## Output Shape

```text
SCENE:
REFERENCES_TO_LOAD:
HYPOTHESES:
NEXT_DECISIVE_TEST:
EVIDENCE_NEEDED:
```
""")

    w("env-patch", """
---
name: env-patch
description: "Run browser-oriented encryption or signing JavaScript inside Node.js by patching the environment. Use after a frontend crypto entrypoint is found and you need to extract webpack modules, simulate window/document/navigator/location, use env_core.js, or make a standalone sign/decrypt runner. Do not use for ordinary browser debugging, AST deobfuscation, or generic Node.js coding."
metadata:
  argument-hint: "[project-name] [optional scene description]"
---

# env-patch

Use this skill after the crypto/signing entrypoint is known. If the entrypoint is unknown, route first to [find-crypto-entry](../find-crypto-entry/SKILL.md) or [complex-js-reverse](../complex-js-reverse/SKILL.md).

## Core Model

- `scripts/env_core.js` is the stable engine: native-function camouflage, prototype helpers, proxies, monitors, and diagnostics.
- `run.js` is the strategy file: all browser stubs, loading order, hooks, and tests live there.
- Original downloaded JS is read-only. Work on copies under an `env/` directory.
- Verify output shape against one captured browser sample before trusting HTTP results.

## Project Layout

```text
<project>/
  source/       # original JS, read-only
  env/
    env_core.js
    main.js
    run.js
    sign.js
  docs/progress.md
```

## Execution Order

1. Copy `scripts/env_core.js` into `env/`; do not edit it unless fixing the shared engine itself.
2. Copy the target JS or extracted webpack module into `env/`.
3. Write the smallest `run.js`: require `env_core.js`, build minimal stubs, call `env.init(...)`, mirror globals, require target JS, and call the target function with a captured sample.
4. Run, inspect diagnostics, and add only the missing stubs shown by errors.
5. Compare signature/ciphertext length, prefix, deterministic fields, and decryptability against the browser sample.
6. Wrap the final function only after parity is proven.

## Reference Map

- `references/browser-stubs.md`: DOM/storage/crypto/browser stubs.
- `references/webpack.md`: webpack module extraction and runtime shims.
- `references/multi-file.md`: SDK plus bytecode or multi-script setups.
- `references/dynamic-loading.md`: lazy loaders and chunk fetches.
- `references/anti-debug.md`: anti-debug or self-defending JS.
- `references/node-detection.md`: hiding Node fingerprints.
- `references/storage-tracing.md`: storage/cookie lineage.
- `references/limitations.md`: when to switch back to browser runtime.

## Hard Rules

- Do not rewrite the original algorithm until environment parity is proven.
- Do not duplicate helpers already in `env_core.js`.
- Do not accept HTTP 200 as proof if generated format differs from the browser sample.
- Prefer one failing missing-stub error at a time.
""")

    w("pentest-report", """
---
name: pentest-report
description: "Generate a structured penetration test or security assessment report from confirmed findings. Use when the user asks for a 渗透测试报告, 安全测试报告, 漏洞报告, report template, or formatted finding write-up with project info, vulnerability summary, details, PoC, evidence, impact, remediation, appendix, and signature sections."
---

# Pentest Report

Use this skill only after findings or evidence have been captured. It formats results; it does not invent vulnerabilities.

## Inputs to Collect

- project/target name, scope, test dates, tester, report date
- confirmed finding list with IDs or titles
- affected URLs/endpoints/assets
- risk level and optional CVSS score
- baseline request, mutated request, response/state diff, screenshots or artifact paths
- impact and affected data/actions
- remediation advice
- retest or cleanup notes

## Required Report Sections

1. Title and project information table
2. Executive summary
3. Vulnerability summary table
4. Detailed findings
5. Remediation summary
6. Appendix: risk rating definitions, CVSS note, tools, glossary, references
7. Signature / handoff notes if requested

## Finding Detail Template

```markdown
### [VL-001] Finding title

| Field | Detail |
| :--- | :--- |
| Risk | High / Medium / Low / Info |
| Type | Authorization / Logic / Injection / File / ... |
| Affected URL | `...` |
| Parameter/Object | `...` |
| Status | Confirmed / Needs retest |

#### Description
#### Reproduction Steps
#### Evidence
#### Impact
#### Remediation
#### Retest Notes
```

## Assets

- Use `assets/pentest_report_template.md` for a full Markdown template.
- Use `references/example_report.md` only as formatting inspiration.

## Quality Rules

- Do not include unverified scanner noise as confirmed findings.
- Separate confirmed findings from hypotheses.
- Keep request/response snippets minimal and redact secrets unless asked otherwise.
- Use Chinese output by default, with English technical identifiers preserved.
""")

    w("find-crypto-entry", """
---
name: find-crypto-entry
description: Locate JavaScript request signing or encryption entrypoints. Use when analyzing protected parameters, token generation, encrypted fields, signed headers, URL or body values, and you need function locations plus call chains.
---

# Find Crypto Entry

Locate the function that generates or transforms the protected parameter named in the task.

## Goal

Return parameter/header/body field name, script URL or local bundle path, line/module location, function name or call site, call chain, and transform type.

## Strategy Selection

### Static Search First

Search parameter names, header names, API path fragments, and business method names. Include minified files when needed.

### XHR/Fetch Breakpoint When Static Search Fails

Set a breakpoint on the request URL or wrapper, trigger the UI once, then inspect the call stack. Focus on business frames above axios/fetch/XHR internals.

### Combine Both

Static search -> candidate assignment -> runtime breakpoint at assignment -> inspect inputs and outputs.

## Common Architectures

1. Business code assigns directly: `headers['x-sign'] = sign(data)`.
2. Request interceptor adds all auth/sign fields.
3. External security SDK exposes a global object such as `window.h5sign`.
4. Obfuscated bundle hides strings; search the non-obfuscated caller or hook the runtime function.

## Anti-Patterns

- Do not step repeatedly into framework internals.
- Do not assume absence because plaintext search fails in obfuscated code.
- Do not refresh repeatedly after setting script IDs unless necessary.
- Do not start environment patching before you know the entrypoint.

## Completion Format

```text
ENTRYPOINT:
  parameter:
  request/path:
  script/module:
  location:
  function:
  call_chain:
  transform_type:
  sample_input:
  sample_output_shape:
NEXT:
```

Use [env-patch](../env-patch/SKILL.md) or [browser-crypto-helper-builder](../browser-crypto-helper-builder/SKILL.md) for standalone reproduction.
""")

    w("auth-sec", """
---
name: auth-sec
description: >-
  Entry P1 category router for authentication and authorization. Use when
  testing login flows, sessions, object authorization, JWT, OAuth, CORS, CSRF,
  and enterprise SSO weaknesses before any deeper auth topic skill.
---

# Authentication and Authorization Router

Use this as the category entry for authentication, session, and authorization-boundary testing.

## When to Use

- Target includes login, registration, password reset, MFA, session cookies, JWT, OAuth, SSO, or enterprise identity.
- Traffic suggests object authorization, cross-tenant access, CORS trust, CSRF, or token scope issues.
- You need to decide whether to test authentication first or authorization first.

## Skill Map

- [Authentication Bypass](../authbypass-authentication-flaws/SKILL.md): login bypass, reset, MFA, enumeration, weak verification.
- [IDOR Broken Object Authorization](../idor-broken-object-authorization/SKILL.md): object ownership and nested authorization.
- [API Authorization and BOLA](../api-authorization-and-bola/SKILL.md): BOLA, BOPLA, BFLA across API endpoints.
- [JWT OAuth Token Attacks](../jwt-oauth-token-attacks/SKILL.md): JWT claims, algorithms, token scope and lifetime.
- [OAuth OIDC Misconfiguration](../oauth-oidc-misconfiguration/SKILL.md): redirect URI, state, nonce, PKCE, account linking.
- [CSRF Cross Site Request Forgery](../csrf-cross-site-request-forgery/SKILL.md): CSRF token, SameSite, JSON CSRF, login CSRF.
- [CORS Cross Origin Misconfiguration](../cors-cross-origin-misconfiguration/SKILL.md): reflected Origin, credentialed cross-origin reads, allowlist bypass.
- [SAML SSO Assertion Attacks](../saml-sso-assertion-attacks/SKILL.md): assertion wrapping, signature validation, audience and ACS boundaries.

## Recommended Flow

1. Identify the auth model and session boundary.
2. Extract object, tenant, role, token, and state identifiers from real traffic.
3. Test object/function/property authorization before deep token crypto unless token evidence is strong.
4. Move into OAuth/OIDC/SAML only when the protocol appears in real redirects, metadata, or tokens.

## Output

```text
AUTH_MODEL:
BOUNDARY_TO_TEST:
NEXT_SKILL:
BASELINE_NEEDED:
ONE_VARIABLE_MUTATION:
```
""")


def write_small_cleanups() -> None:
    small = {
        "idor-broken-object-authorization": """# IDOR Broken Object Authorization

Use this as the focused object-authorization playbook. Prefer [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md) when many API endpoints must be mapped first.

## When to Use

- Object IDs appear in path, query, body, header, cookie, multipart fields, or GraphQL variables.
- List/detail/update/delete/export/share/download actions depend on object keys.
- You suspect cross-user, cross-tenant, nested-object, or child-resource authorization failure.

## Core Loop

1. Build A/B account or tenant fixtures when possible.
2. Capture account A's normal baseline.
3. Change exactly one object key at a time.
4. Repeat for alternate methods, bulk APIs, export APIs, history/version APIs, and async job APIs.
5. Prove read before write; self-object before peer-object; cross-tenant last.

## Output Evidence

Record baseline object, target object, exact field changed, sensitive fields or state change, account/tenant context, and browserless replay result.""",
        "logic-race-harness": """# Logic Race Harness

Use this for authorized race validation after a safe baseline proves the action should only succeed once.

## High-Value Targets

Coupons, points, sign-in, claims, balance transfer, withdrawal, refund, inventory, reservation, approval, verification, reset, and task claim flows.

## Race Models

- Same request replay.
- Check + use.
- Multi-endpoint burst such as `apply-coupon + checkout`.
- Async drift where frontend success precedes backend finalization.

## Execution Ladder

1. Serial replay.
2. Small parallel test: 2-5 requests.
3. Medium parallel test: 10-20 requests if safe.
4. Escalate to [race-condition](../race-condition/SKILL.md) for H2 single-packet or last-byte sync.

## Evidence

Save pre-state, request group, success count, post-state, and impact.""",
        "feature-priority-scorer": """# Feature Priority Scorer

Use this to rank pages, APIs, or workflows before deep testing.

## Scoring Dimensions

Score each 0-3: Money, Write, Object Density, One-Time Constraint, Role Complexity, Bridge/Token, Replayability, Async/Race Potential, Hidden UI Signal.

## Interpretation

- `18+`: deep test first.
- `12-17`: second lane or targeted probe.
- `0-11`: deprioritize unless a strong signal appears.

## Output

For each feature return total score, why it is high, first three hypotheses, and recommended next skill.

## Script

- `scripts/score_features.py`: score JSON or CSV feature lists.""",
        "http-parameter-pollution": """# HTTP Parameter Pollution

## When to Use

Duplicate keys, array syntax, mixed separators, encoded names, or parser differences may alter parameter interpretation.

## High-Value Mutations

- `a=1&a=2`
- `a[]=1&a[]=2`
- `a=1;a=2`
- `a`, `%61`, `a%00`, case variants
- `role=user&role=admin`
- same semantic field in path/query/body

## Look For

Frontend/backend value mismatch, WAF/backend parser split, array fan-out, or polluted auth/tenant/object/price/status behavior.

## Pivots

- Role/org/tenant/object: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Amount/coupon/workflow: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- WAF parser differential: [waf-bypass-techniques](../waf-bypass-techniques/SKILL.md)""",
        "injection-checking": """# Injection Checking

Use this router to classify the sink before loading a specialist skill.

## Quick Triage

| Observation | Route |
|---|---|
| SQL query, sorting, filtering, report errors | `sqli-sql-injection` / `exploit-sqli` |
| HTML, JS, DOM, stored content | `xss-cross-site-scripting` / `exploit-xss` |
| Template expression | `ssti-server-side-template-injection` |
| XML, SVG, SOAP, OOXML | `xxe-xml-external-entity` |
| Server fetches URL/host | `ssrf-server-side-request-forgery` |
| Shell, transcoder, importer, command wrapper | `cmdi-command-injection` |
| JSON DSL or Mongo operators | `nosql-injection` |
| Header, Location, Set-Cookie controlled | `crlf-injection` / `http-host-header-attacks` |
| HTTP framing, CL/TE, H2/H1 mismatch | `request-smuggling` |
| SpEL, OGNL, EL, rule expression | `expression-language-injection` |
| Path, filename, download or preview parameter | `file-access-vuln` |

## Rules

Confirm the parsing boundary, change one input location at a time, classify deltas, then pivot to the narrow specialist.""",
    }

    descriptions = {
        "idor-broken-object-authorization": '"IDOR and object-level authorization playbook. Use when URLs, JSON bodies, headers, cookies, or GraphQL arguments contain object identifiers and you need to test cross-user or cross-tenant read/write access, nested object authorization, or direct object reference flaws."',
        "logic-race-harness": '"Template-driven race harness for business logic testing. Use when one-time actions, claims, balances, approvals, verification, inventory, or reward operations may be vulnerable to parallel replay or multi-endpoint TOCTOU windows."',
        "feature-priority-scorer": '"High-value feature scoring skill for black-box security testing. Use when a target has many pages or APIs and you need to rank features by likely business-logic payoff before spending time on deep testing."',
        "http-parameter-pollution": '"HTTP parameter pollution playbook. Use when duplicate keys, array syntax, mixed separators, encoded names, or parser differences between WAF, proxy, framework, and backend may change how parameters are interpreted."',
        "injection-checking": '"Entry router for injection testing. Use when user-controlled input may reach SQL, templates, shells, XML parsers, URL fetchers, interpreters, headers, request framing, or file/path resolvers and you need to pick the right specialist skill before deep testing."',
    }
    for skill, body in small.items():
        w(skill, f"---\nname: {skill}\ndescription: {descriptions[skill]}\n---\n\n{body}")

    # Very small compatibility and specialist routers.
    compact = {
        "dependency-confusion": ('"Dependency confusion and package namespace trust testing. Use when internal package names appear in npm, pip, Maven, NuGet, Gem, Composer, or CI/CD build flows and you need to assess whether private dependencies could be resolved from public registries."', "Check internal package names, registry precedence, namespace/scope pinning, and version override rules. Prefer safe proof that public resolution can participate over publishing or executing risky packages. Related: [insecure-source-code-management](../insecure-source-code-management/SKILL.md), [extract-frontend-sensitive-info](../extract-frontend-sensitive-info/SKILL.md)."),
        "subscription-trial-membership-abuse": ('"Subscription, membership, trial, quota-pack, renewal, downgrade, entitlement, and usage-cap logic abuse playbook. Use when plans, seats, trial eligibility, feature flags, or quotas may drift from payment and identity state."', "Test trial eligibility, seats, feature flags, downgrade/cancel retention, quota reset, and entitlement revocation. Mutate one dimension at a time: email alias, account state, seat, plan, org, or time window. Pair with [payment-promo-rewards-abuse](../payment-promo-rewards-abuse/SKILL.md)."),
        "tenant-admin-control-plane-abuse": ('"Multi-tenant and admin control-plane logic abuse playbook. Use when org, tenant, department, role, policy, invite, delegated admin, or hidden management routes may allow cross-tenant access, role escalation, or unsafe state changes."', "Test tenant/org/role boundaries, invites, delegated admin, hidden routes, downgrade retention, and cross-tenant copy/import/migration. Baseline same-tenant first, then change exactly one field. Pair with [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)."),
        "type-juggling": ('"PHP type juggling and loose comparison playbook. Use when PHP applications compare tokens, hashes, booleans, numbers, JSON values, arrays, or emptiness checks with weak equality or loose casting rules."', "Use for PHP or PHP-like loose comparisons in login, reset, coupons, verification, tokens, roles, or `empty()`/`in_array()`/`strpos()` behavior. Change exactly one type and observe auth, validation, or one-time constraint bypass."),
        "expression-language-injection": ('"Expression Language injection playbook for SpEL, OGNL, EL, MVEL, JEXL, and related evaluators. Use when user input may be evaluated inside templates, validation messages, rule engines, dynamic property access, or expression-backed workflows."', "Look for `${...}`, `#{...}`, OGNL, SpEL, EL, formulas, rule engines, or workflow expressions. Validate harmless literals first, then property reads, then method/bean/class/file/network capability only if safe."),
        "insecure-source-code-management": ('"Insecure source code management exposure playbook. Use when .git, .svn, .hg, backup refs, repository metadata, build artifacts, or leaked source bundles may disclose code, secrets, routes, or internal package names."', "Check `.git`, `.svn`, `.hg`, backups, source archives, CI artifacts, sourcemaps, and build manifests. Recover routes, configs, secret names, internal package names, and deployment clues, then feed API/auth/business/dependency skills."),
        "business-logic-vuln": (">-\n  Entry P1 category router for business logic testing. Use when workflow abuse,\n  race conditions, pricing flaws, or multi-step state attacks matter more than\n  parser-level input injection.", "Use when rules, states, order, quota, price, tenant, actor, or object invariants matter more than parser payloads. State the invariant, capture baseline, build single-variable mutations, and route to [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md), [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md), or [logic-race-harness](../logic-race-harness/SKILL.md)."),
        "recon-for-sec": (">-\n  Entry P1 category router for reconnaissance and methodology. Use when mapping\n  scope, discovering assets, fingerprinting technology, building endpoint\n  inventory, and choosing the first high-value security testing path.", "Use for new/unknown targets. Confirm scope, map pages/APIs/services/JS/docs/exposed files, then route by evidence to API, auth, injection, file, frontend reverse, or business logic skills."),
        "unauthorized-access-common-services": ('"Unauthorized access to common services playbook. Use when Redis, Elasticsearch, MongoDB, Jenkins, Docker API, Kibana, RabbitMQ, or similar management services may be exposed without proper authentication."', "Identify service type/version/exposure and whether anonymous read or write is possible. High-value impacts: config disclosure, job execution, plugin install, container control, message replay, or data dump."),
        "anti-debugging-techniques": ('"Anti-debugging techniques router. Use when browser, script, or native targets use traps, timing checks, self-defending code, console detection, or anti-instrumentation to block analysis."', "Route browser/frontend cases to [anti-debug-frontend-bypass](../anti-debug-frontend-bypass/SKILL.md). Pair obfuscation with [code-obfuscation-deobfuscation](../code-obfuscation-deobfuscation/SKILL.md). Bypass one trap at a time."),
        "binary-protection-bypass": ('"Binary hardening and protection bypass router. Use when reversing or exploiting native targets protected by ASLR, DEP, RELRO, PIE, stack canaries, CFG, packers, or sandbox boundaries and you need to route toward the right primitive-specific skill."', "Map format, mitigations, loader/libc/runtime, controllable bytes, leaks, target object, and crash offset. Route to stack, heap, format-string, arbitrary-write, browser, or sandbox skill by primitive."),
        "kernel-exploitation": ('"Kernel exploitation compatibility router. Use when the target involves ring-0 primitives, kernel memory corruption, driver abuse, or privilege-escalation paths that exceed normal web or app testing scope."', "Use only for kernel/driver primitives. Confirm OS/version, module, attack surface, userland entrypoint, primitive, and privilege goal. Route userland pwn back to [binary-protection-bypass](../binary-protection-bypass/SKILL.md)."),
        "symbolic-execution-tools": ('"Symbolic execution tools router. Use when path constraints, branch feasibility, or opaque predicates require symbolic reasoning to reduce reverse-engineering search space."', "Use when manual trace/static simplification stalls on path constraints. Extract the smallest slice first and pair with deobfuscation or VM/bytecode skills."),
        "stack-overflow-and-rop": ('"Stack overflow and ROP router. Use when stack corruption, saved return control, SEH overwrite, or gadget chaining is the main path to code execution."', "Determine architecture, mitigations, protocol framing, crash offset, controlled bytes, and leaks. Prove RIP/EIP/SEH control before gadget work."),
        "vm-and-bytecode-reverse": ('"VM and bytecode reverse router. Use when custom virtual machines, bytecode interpreters, packed scripts, or virtualized control flow hide the real program logic."', "Extract bytecode format, dispatch loop, handler table, registers/stack model, constants, and I/O boundary. If it is just frontend packaging, route to [complex-js-reverse](../complex-js-reverse/SKILL.md)."),
        "heap-exploitation": ('"Heap exploitation router. Use when a target exposes allocator corruption, use-after-free, double free, tcache abuse, or other heap primitives and you need to pivot into a concrete write or control primitive."', "Identify allocator, object lifecycle, allocation sizes, free order, controllable data, and leak source. Convert to overlap, arbitrary read/write, or control-flow primitive."),
        "format-string-exploitation": ('"Format string exploitation router. Use when printf-style sinks may leak memory, write arbitrary values, or provide the primitive needed to pivot into code execution."', "Separate leak, arbitrary write, and offset-control stages. Confirm stack index, architecture, pointer width, and output truncation constraints."),
        "sandbox-escape-techniques": ('"Sandbox escape router. Use when the current primitive lands inside a restricted browser, renderer, VM, container, or instrumented sandbox and the next question is how to break the confinement boundary."', "Use after a primitive is confirmed inside a confinement boundary. Identify sandbox type, broker boundary, exposed APIs, filesystem/network policy, and available tokens/capabilities."),
        "portal-workflow-task-abuse": ('"Portal, OA, eHall, workflow, task-center, approval, form, and bridge-token abuse playbook. Use when list-detail-write chains, task APIs, iframe jump links, or cross-system bridge tokens may expose sensitive workflow data or enable cross-user actions."', "Recover list -> detail -> process/data -> write/approve/export/bridge. Test object ID swaps, malformed-ID token leaks, browserless token replay, hidden approval/admin endpoints, and low-risk cross-user state writes."),
    }
    for skill, (desc, body) in compact.items():
        title = " ".join(x.capitalize() for x in skill.split("-"))
        w(skill, f"---\nname: {skill}\ndescription: {desc}\n---\n\n# {title}\n\n{body}\n")


def write_governance_additions() -> None:
    ref("skill-suite-governance", "entry-routing-canonical-20260501.md", """
# Canonical Entry Routing 2026-05-01

Use this to avoid skill-suite noise after optimization.

## Default P0

For Zhang's usual Web/SRC/CTF/security work, start with:

```text
zhang-web-src-default-runner
```

Only load a narrower skill directly when the user names it or the scene is already specific.

## Stable Main Entries

1. `zhang-web-src-default-runner` - personal Web/SRC/CTF default and high-impact bias.
2. `security-test-dispatcher` - generic authorized security start prompt.
3. `blackbox-pentest-runner` - Web/API orchestration and evidence loop.
4. `complex-js-reverse` - frontend signing/encryption/replay recovery.
5. `ctf-web` - challenge-style Web exploitation.
6. `skill-suite-governance` - suite validation, reports, and cleanup.

## Direct-Load Specialists

Load specialists only after concrete evidence exists: injection, auth/API, business logic, frontend reverse, file/upload, or native/reverse primitives.

## Maintenance Rule

After editing skills, run:

```powershell
python C:\\Users\\zhang\\.codex\\skills\\skill-suite-governance\\scripts\\scan_skill_suite.py --root C:\\Users\\zhang\\.codex\\skills --write-reports
python C:\\Users\\zhang\\.codex\\skills\\skill-suite-governance\\scripts\\content_quality_scan.py --root C:\\Users\\zhang\\.codex\\skills --write-report
python C:\\Users\\zhang\\.codex\\skills\\skill-suite-governance\\scripts\\mojibake_scan.py --root C:\\Users\\zhang\\.codex\\skills --write-report
```
""")

    script = root / "skill-suite-governance" / "scripts" / "mojibake_scan.py"
    script.write_text(textwrap.dedent(r'''
        #!/usr/bin/env python3
        """Advisory mojibake scan for local Codex skills.

        Flags suspicious UTF-8/GBK mojibake fragments in SKILL.md files.
        """
        import argparse, json
        from pathlib import Path

        DEFAULT_ROOT = Path(r"C:\Users\zhang\.codex\skills")
        PATTERNS = ["寮€", "榛", "娴", "渚", "鏉", "鐢", "绛", "鍒", "澶", "鎴", "銆", "锛", "鈥", "馃", "氿", "煙", "â€™", "Ã", "�"]

        def scan(root: Path, include_system: bool = False):
            rows = []
            for p in sorted(root.rglob("SKILL.md")):
                if not include_system and ".system" in p.parts:
                    continue
                text = p.read_text(encoding="utf-8", errors="replace")
                matches = {}
                score = 0
                for pat in PATTERNS:
                    count = text.count(pat)
                    if count:
                        matches[pat] = count
                        score += count if pat in {"鈥", "馃", "氿", "煙", "â€™", "Ã", "�"} else count * 2
                if score:
                    rows.append({"skill": p.parent.name, "path": str(p), "score": score, "chars": len(text), "matches": matches})
            return sorted(rows, key=lambda x: (x["score"], x["chars"]), reverse=True)

        def write_markdown(rows, out: Path):
            lines = ["# Mojibake Scan", "", f"Flagged skills: {len(rows)}", ""]
            for r in rows:
                lines += [f"## {r['skill']}", "", f"- path: `{r['path']}`", f"- score: {r['score']}", f"- chars: {r['chars']}", f"- matches: `{json.dumps(r['matches'], ensure_ascii=False)}`", ""]
            out.write_text("\n".join(lines), encoding="utf-8")

        def main():
            ap = argparse.ArgumentParser()
            ap.add_argument("--root", default=str(DEFAULT_ROOT))
            ap.add_argument("--include-system", action="store_true")
            ap.add_argument("--write-report", action="store_true")
            ap.add_argument("--out", default=str(Path(__file__).resolve().parents[1] / "references" / "mojibake.generated.md"))
            args = ap.parse_args()
            rows = scan(Path(args.root), include_system=args.include_system)
            if args.write_report:
                write_markdown(rows, Path(args.out))
            print(json.dumps({"flagged": len(rows), "items": rows[:50]}, ensure_ascii=False, indent=2))

        if __name__ == "__main__":
            main()
    ''').strip() + "\n", encoding="utf-8")


def main() -> None:
    preserve_and_split_long_entries()
    write_core_routers()
    write_mojibake_rewrites()
    write_small_cleanups()
    write_governance_additions()
    print("optimized skill suite files")


if __name__ == "__main__":
    main()
