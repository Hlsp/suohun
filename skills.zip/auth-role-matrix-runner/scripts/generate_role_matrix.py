#!/usr/bin/env python3
import argparse, json
from itertools import combinations, product
from pathlib import Path


def load_json(path, default):
    if not path or not Path(path).exists():
        return default
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def accounts(data):
    if isinstance(data, dict):
        return data.get('accounts', [])
    return data if isinstance(data, list) else []


def workflows(data):
    if isinstance(data, dict):
        return data.get('workflows', [])
    return data if isinstance(data, list) else []


def norm_list(v):
    if not v:
        return []
    if isinstance(v, list):
        return v
    return [v]


def pair_type(a, b):
    if a.get('tenant') and b.get('tenant') and a.get('tenant') != b.get('tenant'):
        return 'cross_tenant'
    if a.get('role') and b.get('role') and a.get('role') != b.get('role'):
        return 'cross_role'
    if a.get('state') and b.get('state') and a.get('state') != b.get('state'):
        return 'state_variant'
    return 'same_role_or_owner_swap'


def make_tests(accs, wfs):
    tests = []
    idx = 1
    for a, b in combinations(accs, 2):
        kind = pair_type(a, b)
        axes = []
        if a.get('role') != b.get('role'):
            axes.append('role')
        if a.get('tenant') != b.get('tenant'):
            axes.append('tenant')
        if a.get('state') != b.get('state'):
            axes.append('state')
        if not axes:
            axes.append('ownership')
        for direction in [(a, b), (b, a)]:
            owner, actor = direction
            owner_objs = norm_list(owner.get('owned_objects') or owner.get('objects'))
            if owner_objs:
                for obj in owner_objs[:10]:
                    tests.append({'id': f'MX-{idx:04d}', 'kind': kind, 'axes': axes, 'actor': actor.get('label'), 'owner': owner.get('label'), 'object_ref': obj, 'mutation': 'use owner object with actor session', 'status': 'new'})
                    idx += 1
            else:
                tests.append({'id': f'MX-{idx:04d}', 'kind': kind, 'axes': axes, 'actor': actor.get('label'), 'owner': owner.get('label'), 'object_ref': '<capture-from-workflow>', 'mutation': 'swap object/user/tenant variable between accounts', 'status': 'new'})
                idx += 1
    high_wfs = []
    for w in wfs:
        cats = {v.get('category') for v in w.get('variables', []) if isinstance(v, dict)}
        method = str(w.get('method', '')).upper()
        if method in {'POST', 'PUT', 'PATCH', 'DELETE'} or {'identity', 'object', 'state'} & cats:
            high_wfs.append({'workflow_id': w.get('id'), 'method': method, 'path': w.get('path_template') or w.get('url'), 'categories': sorted(cats)})
    return tests, high_wfs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--account-matrix', required=True)
    ap.add_argument('--workflow-map')
    ap.add_argument('--out', required=True)
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    accs = accounts(load_json(args.account_matrix, {}))
    wfs = workflows(load_json(args.workflow_map, {}))
    tests, high_wfs = make_tests(accs, wfs)
    data = {'accounts': accs, 'workflow_candidates': high_wfs, 'tests': tests}
    (out / 'role_test_matrix.json').write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = ['# Role Test Matrix', '', '| ID | Kind | Actor | Owner | Object | Mutation |', '|---|---|---|---|---|---|']
    for t in tests:
        lines.append(f"| {t['id']} | {t['kind']} | {t.get('actor','')} | {t.get('owner','')} | `{t.get('object_ref','')}` | {t.get('mutation','')} |")
    (out / 'role_test_matrix.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'accounts': len(accs), 'tests': len(tests), 'workflow_candidates': len(high_wfs), 'out': str(out)}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
