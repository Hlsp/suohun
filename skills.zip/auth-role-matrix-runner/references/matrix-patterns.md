# Auth Matrix Patterns

## Minimum pairs

- A and B: same role, same tenant, different owned objects.
- A and B: same role, different tenant.
- A low role and Admin/high role in same tenant.

## Useful object states

- draft vs submitted
- pending vs approved
- unpaid vs paid
- active vs expired
- public vs private
- deleted/recycled vs active

## Single-variable examples

- Replace `objectId` only.
- Replace `tenantId` only.
- Replace `userId` only.
- Replace `role` claim/token only if token mutation has a valid verification path.
- Replace workflow `status` or `step` only in one request.
