---
name: auth-role-matrix-runner
description: "Second-stage logged-in role, tenant, account, object, and state matrix runner. Use after the P0 runner selects authenticated testing, or when credentials/cookies/tokens/accounts/roles/tenants are explicitly available and Codex must plan A/B tests, cross-role or cross-tenant BOLA/IDOR checks, workflow state abuse, entitlement drift, object ownership swaps, or authenticated business logic verification."
role: runner
domain: auth-api
---

# Auth Role Matrix Runner

Use this as the second-stage entrypoint for logged-in black-box testing after the P0 runner selects authenticated coverage. It turns accounts, roles, tenants, owned objects, and workflow states into a controlled test matrix.

## Operating Loop

1. Fixture Inventory: collect account labels only; never store raw secrets in the matrix.
2. Axis Selection: choose role, tenant, ownership, state, entitlement, and token/session axes.
3. Traffic Baseline: capture one valid workflow for account A and, when possible, the analogous workflow for B.
4. Matrix Generation: generate candidate pairs and single-variable mutation tasks.
5. One Hypothesis: pick one account/object/tenant/state variable and replay only that change.
6. State Diff: compare status, data visibility, ownership, and side effects.
7. Evidence Pack: preserve baseline, mutated request, before/after state, and cleanup.

Write the selected matrix cell into the active run directory's `03_object_identity_map.md` and `04_hypothesis_queue.md` before replay. This prevents broad A/B probing without a recorded ownership model.

## Single-Account Object-Chain Mode

Use this when only one authenticated account is available. It does not prove cross-user BOLA by itself, but it prevents blind ID guessing and prepares clean fixtures.

1. Capture the account's real list/search response and decode/decrypt it if needed.
2. Extract owned object IDs, owner fields, tenant/org fields, state/status, and safe action endpoints.
3. Prove the owned baseline in order: list object appears -> detail reads same object -> safe action returns expected semantic response -> optional readback.
4. Record the object chain in `03_object_identity_map.md` with `owner=account-A`, route, state, and confidence.
5. Only after that, create mutation tasks for sibling IDs, tenant/org changes, stale IDs, action-state changes, or A/B account swaps.

Do not classify guessed-ID `500` responses as authorization impact. Treat them as endpoint stability or object-existence signals until an existing object and owner boundary are proven.

## Matrix Inputs

Use `account_matrix.json` from [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md) or [account-fixture-manager](../account-fixture-manager/SKILL.md). Recommended account fields:

- `label`
- `role`
- `tenant`
- `state`
- `credentials_ref`
- `owned_objects`
- `entitlements`

## Scripted Matrix

```bash
python scripts/generate_role_matrix.py --account-matrix runs/T/account_matrix.json --out runs/T/matrix
```

Optional workflow context:

```bash
python scripts/generate_role_matrix.py --account-matrix runs/T/account_matrix.json --workflow-map runs/T/workflows/workflow_map.json --out runs/T/matrix
```

Outputs:

- `role_test_matrix.json`
- `role_test_matrix.md`

## High-Value Tests

Prioritize:

- same role, different owner object access
- same role, different tenant access
- lower role invoking higher role action
- expired/disabled/unpaid/unapproved state using active endpoints
- feature entitlement, quota, plan, or seat drift
- token/session swap across account or tenant boundaries

## Routing

- Account fixture management: [account-fixture-manager](../account-fixture-manager/SKILL.md)
- BOLA/IDOR: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- Workflow diff: [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md)
- Single-variable replay: [single-variable-replay-harness](../single-variable-replay-harness/SKILL.md)
- Burp replay/evidence: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Race where relevant: [logic-race-harness](../logic-race-harness/SKILL.md)

## Output Format

Report:

1. matrix axes selected
2. account/object pair chosen
3. baseline owner and expected authorization
4. single variable mutated
5. observed access or state change
6. impact, confidence, and evidence paths
7. next matrix cell or stop reason

## Replay Handoff

For every selected cell, hand off to `single-variable-replay-harness` using:

- baseline account and request
- acting account
- target owner account
- exact object/tenant/role/state/token variable
- old value and new value
- expected authorization rule
- verification method and cleanup step
