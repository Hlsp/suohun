---
name: env-patch
description: "Run browser-oriented encryption or signing JavaScript inside Node.js by patching the environment. Use after a frontend crypto entrypoint is found and you need to extract webpack modules, simulate window/document/navigator/location, use env_core.js, or make a standalone sign/decrypt runner. Do not use for ordinary browser debugging, AST deobfuscation, or generic Node.js coding."
role: specialist
domain: browser-frontend-reverse
metadata:
  argument-hint: "[project-name] [optional scene description]"
---

# env-patch

Use this skill after the crypto/signing entrypoint is known. If the entrypoint is unknown, route first to [find-crypto-entry](../find-crypto-entry/SKILL.md) or [complex-js-reverse](../complex-js-reverse/SKILL.md).

## Core Model

- `scripts/env_core.js` is the stable engine: native-function camouflage, prototype helpers, proxies, monitors, and diagnostics.
- `run.js` is the strategy file: all browser stubs, loading order, hooks, and tests live there.
- Original downloaded JS is read-only. Work on copies under an `env/` directory.
- Verify output shape against one captured browser sample before trusting HTTP results.

## Project Layout

```text
<project>/
  source/       # original JS, read-only
  env/
    env_core.js
    main.js
    run.js
    sign.js
  docs/progress.md
```

## Execution Order

1. Copy `scripts/env_core.js` into `env/`; do not edit it unless fixing the shared engine itself.
2. Copy the target JS or extracted webpack module into `env/`.
3. Write the smallest `run.js`: require `env_core.js`, build minimal stubs, call `env.init(...)`, mirror globals, require target JS, and call the target function with a captured sample.
4. Run, inspect diagnostics, and add only the missing stubs shown by errors.
5. Compare signature/ciphertext length, prefix, deterministic fields, and decryptability against the browser sample.
6. Wrap the final function only after parity is proven.

## Reference Map

- `references/browser-stubs.md`: DOM/storage/crypto/browser stubs.
- `references/webpack.md`: webpack module extraction and runtime shims.
- `references/multi-file.md`: SDK plus bytecode or multi-script setups.
- `references/dynamic-loading.md`: lazy loaders and chunk fetches.
- `references/anti-debug.md`: anti-debug or self-defending JS.
- `references/node-detection.md`: hiding Node fingerprints.
- `references/storage-tracing.md`: storage/cookie lineage.
- `references/limitations.md`: when to switch back to browser runtime.

## Hard Rules

- Do not rewrite the original algorithm until environment parity is proven.
- Do not duplicate helpers already in `env_core.js`.
- Do not accept HTTP 200 as proof if generated format differs from the browser sample.
- Prefer one failing missing-stub error at a time.
