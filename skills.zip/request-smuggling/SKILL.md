---
name: request-smuggling
description: "HTTP request smuggling and desynchronization playbook. Use when front-end and back-end servers may parse request framing, HTTP/2 translation, headers, or connection reuse differently."
role: specialist
domain: injection-server
---

# Request Smuggling

Use this skill when an HTTP chain contains multiple parsers: CDN, load balancer, reverse proxy, WAF, gateway, origin server, or HTTP/2 to HTTP/1 translation layer.

## Core Model

Request smuggling is a parser desynchronization issue:

1. Front-end and back-end disagree about request boundaries or authority.
2. A crafted request leaves bytes queued for the next request or changes how the next request is routed.
3. Impact appears as response queue poisoning, auth bypass, cache poisoning, host confusion, or request prefixing.
4. Evidence requires controlled correlation; status-code weirdness alone is not enough.

Treat this as a precision test. Avoid broad scanning and keep tests isolated.

## Recon Questions

- Which layers are in the chain: CDN, proxy, gateway, WAF, origin, HTTP/2 translator?
- Are connections reused between users or requests?
- Which framing headers are accepted, normalized, duplicated, or rejected?
- Does HTTP/2 get downgraded to HTTP/1.1 before origin?
- Can you isolate tests with cache-busters, self-owned accounts, and unique paths?
- Is there a safe endpoint that reflects request metadata for correlation?

## Test Families

### CL/TE and TE/CL Framing

Check whether front and back ends disagree about `Content-Length`, `Transfer-Encoding`, duplicate headers, whitespace, or malformed framing.

### HTTP/2 Translation

HTTP/2 pseudo-headers, duplicate regular headers, path normalization, and downgrade behavior can create H2-specific desync. Use the local H2 reference for variants.

### Response Queue Desync

Look for swapped responses, delayed responses, or a controlled marker appearing in a later request from the same connection context.

### Routing and Host Confusion

If desync influences `Host`, path, or authority, pivot to host-header, cache, or auth boundary testing.

### Cache Poisoning Chain

Smuggled request prefixes can poison cacheable responses. Use cache-busters and self-scoped URLs only.

## Validation Ladder

1. Map the proxy/origin chain and choose an isolated endpoint.
2. Establish normal keep-alive behavior.
3. Send one desync variant at a time with unique markers.
4. Confirm effect through controlled follow-up requests.
5. Prove impact in a self-contained path: cache, auth, host, or response queue.
6. Stop on strong signal and document minimal reproduction.

## Evidence Standard

Capture:

- target chain clues and protocol version
- raw baseline and mutated request
- marker correlation across follow-up requests
- timing/response queue evidence
- minimal impact proof
- isolation method and cleanup

## Pivots

- H2 variants: [H2_SMUGGLING_VARIANTS.md](./H2_SMUGGLING_VARIANTS.md)
- Cache chain: [web-cache-deception](../web-cache-deception/SKILL.md)
- Host confusion: [http-host-header-attacks](../http-host-header-attacks/SKILL.md)
- WAF differential: [waf-bypass-techniques](../waf-bypass-techniques/SKILL.md)
