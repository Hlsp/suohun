# Blackbox Operating Loop

## Fast Loop

1. Pick one high-value feature, not the whole site.
2. Capture one clean baseline flow from UI action to backend state.
3. Extract object, identity, state, value, one-time, and bridge keys.
4. Score hypotheses and test the top one only.
5. Change one variable per replay.
6. Classify result as no-delta, read-delta, write-delta, race-delta, or replay-delta.
7. Stop once impact is strong enough; package evidence.

## Exit Criteria

A lead is worth escalating only if it reaches one of:

- unauthorized sensitive read
- unauthorized state change
- repeated reward or quota bypass
- token or bridge reuse outside the intended flow
- confirmed race-created invariant break
