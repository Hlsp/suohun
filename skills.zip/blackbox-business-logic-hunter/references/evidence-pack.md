# Evidence Pack

Use this compact evidence block for every confirmed or near-confirmed logic lead.

```yaml
feature:
entry_url:
accounts:
  actor:
  peer:
  tenant:
baseline:
  action:
  request:
  expected_state:
mutation:
  variable:
  original:
  mutated:
delta:
  response:
  visible_state:
impact:
  class: read | write | replay | race | bridge-token
  description:
replay:
  browserless: true | false
  command_or_request_file:
rollback:
  needed: true | false
  note:
```
