# Business Logic Hypothesis Matrix

| Signal | First Hypothesis | Next Skill |
|---|---|---|
| `id`, `userId`, `tenantId`, nested object | BOLA / IDOR | `api-authorization-and-bola` |
| `status`, `step`, `approved`, `paid` | workflow skip or state tamper | `blackbox-business-logic-hunter` |
| `amount`, `price`, `discount`, `points` | payment or reward abuse | `payment-promo-rewards-abuse` |
| `coupon`, `invite`, `claim`, `reset`, `token` | one-time replay or race | `logic-race-harness` |
| hidden/disabled/admin button | frontend gate only | `browser-pentest-orchestrator` |
| `iframe`, `jumpLink`, `thirdUrl`, `ticket` | bridge token reuse | `portal-workflow-task-abuse` |
| export/download/share/preview | object/file logic abuse | `export-preview-sharing-logic-abuse` |
| plan/trial/quota/seat | entitlement drift | `subscription-trial-membership-abuse` |
