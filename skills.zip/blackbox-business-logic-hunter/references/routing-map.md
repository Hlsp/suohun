# Routing Map

## Start Here

- Unknown target with many features: `feature-priority-scorer`
- One flow already captured: `workflow-state-diff-lab`
- One-time / balance-like action: `logic-race-harness`
- Payment, promo, reward: `payment-promo-rewards-abuse`
- Portal/OA/workflow/task-center: `portal-workflow-task-abuse`
- Multi-tenant admin console: `tenant-admin-control-plane-abuse`
- Invite/binding/delegation: `account-binding-invite-delegation-abuse`
- Export/preview/share: `export-preview-sharing-logic-abuse`
- Subscription/trial/quota: `subscription-trial-membership-abuse`
- Evidence package: `logic-evidence-pack`
- Retest after patch: `logic-fix-verification`

## Recovery Pivots

- If replay is blocked by signing/encryption: `request-chain-tracer` then `storage-and-key-lineage`.
- If frontend routing is unclear: `browser-pentest-orchestrator`.
- If object auth is the core issue: `idor-broken-object-authorization` or `api-authorization-and-bola`.
