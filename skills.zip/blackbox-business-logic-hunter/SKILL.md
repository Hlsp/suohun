---
name: blackbox-business-logic-hunter
description: "High-efficiency AI black-box business logic hunting skill. Use for authorized Web/API/portal/workflow targets when looking for workflow bypass, state-machine flaws, race, replay, quota abuse, pricing/reward abuse, cross-user or cross-tenant reads/writes, hidden actions, token bridge misuse, or high-value business impact."
role: hunter
domain: business-logic
---

# Blackbox Business Logic Hunter

Use this skill when scanners or payload lists are unlikely to find the real issue. The goal is to prove one narrow end-to-end business-control failure.

## Core Model

A business logic finding exists when the server allows an action that violates the intended invariant:

- wrong actor
- wrong object
- wrong tenant/org/role
- wrong state or step
- wrong lifecycle source (server should use server time/state, but trusts client-submitted time or status instead)
- wrong amount/quota/price/reward
- wrong token/session/device
- wrong request order or timing

## First 20 Minutes

1. Pick one high-value feature, not the whole site.
2. Capture a clean baseline request/response and visible state.
3. Extract variables: identity, object, tenant, role, status, amount, token, timestamp, nonce, order.
4. Write the expected invariant in one sentence: "who may do what, to which object, when, and with what limits".
5. Build a mutation queue where each candidate changes exactly one variable.
6. Verify by re-reading state/data, not just by a successful response.

If no baseline exists yet, stop planning and capture one. If no mutation queue exists after baseline, create one before discussing more bug classes.

## High-Value Surfaces

- payment, wallet, coupons, points, gift cards, rewards, membership, subscription, trial
- order, invoice, contract, refund, delivery, entitlement, quota
- approval, task center, workflow, OA/eHall/portal forms, supplier/customer systems
- export, preview, download, share, recycle-bin, favorite, recent-use, report jobs
- account recovery, invite, binding, delegation, act-as, SSO/OAuth/iframe/token bridge
- admin/control-plane, tenant/org/department/role boundaries
- import/upload/report async processing pipelines

## Hypothesis Matrix

| Dimension | Examples | What to prove |
|---|---|---|
| Object | `fileId`, `orderId`, `taskId`, `entry`, `nodeId` | A can read/write B's object |
| Tenant/org | `tenantId`, `orgId`, `deptId`, supplier/customer id | cross-tenant or cross-org access |
| Role/function | `role`, `permission`, hidden admin action | BFLA / function-level authorization failure |
| Property | `isAdmin`, `status`, `price`, `quota`, `ownerId` | BOPLA / mass assignment |
| State | draft/submitted/approved/paid/used/expired | skipped or reversed state transition |
| Lifecycle source | `time`, `start`, `end`, `status`, `active`, `expired` | backend trusts client-side lifecycle values |
| Amount/quota | amount, discount, points, balance, plan | financial or entitlement impact |
| Token/link | invite/reset/share/export/callback token | reuse, swap, stale, or scope failure |
| Order/timing | replay, race, callback before payment | order dependency or concurrency failure |

## Domain Playbooks

### Payment / promo / membership

Test quote -> order -> pay/callback -> fulfill -> cancel/refund -> reuse/race. Focus on amount trust, stacking, repeated redemption, refund drift, downgrade retaining quota, race windows, and storefront checkout fields exposed in URLs or inline JS.

### Promo / lottery / ended-activity

Test whether the backend really uses server truth for activity windows and state. Focus on:

- client-submitted `time`
- client-submitted `status`, `active`, `expired`
- `start` / `end` / `start_time` / `end_time`
- repeatable draws / stale promo actions after the page says the event ended

If the page says 活动已结束 but the button is still live, treat it as a mandatory first-class hypothesis.

### Register / login state split

If registration succeeds but login fails, do not assume the user is blocked. Test whether the registration session or returned user object already grants API access.

### Account recovery / invite / binding

Test token binding to user/tenant/device/action/session, token reuse, stale links after account changes, invite role escalation, binding someone else's email/phone/social account, and partial-login API access before MFA.

### Enterprise / OA / portal

Test org/department/role/workflow boundaries, attachments, exports, supplier/customer separation, task states, iframe/jumpLink/thirdUrl token bridges, favorites/recent/recycle-bin writes.

### Upload / import / report jobs

Map accept -> store -> process -> retrieve -> post-process. Look for parser effects, async job output, generated files, imported objects, race between validation and processing, and cross-user retrieval.

## Validation Ladder

1. Self baseline works.
2. Self mutation proves the parameter controls behavior.
3. Peer read proves cross-object exposure.
4. Peer write proves integrity impact.
5. Cross-tenant/admin boundary proves severity.
6. Replay/race proves lifecycle or concurrency failure.
7. Re-read state and clean up.

## Evidence Standard

Capture:

- target feature and expected invariant
- baseline request/response and baseline state
- exact single variable changed
- mutated request/response
- response-field diff after normalizing volatile values
- backend state/data/session/token/file proof
- account/object/tenant ownership context
- cleanup or rollback steps

## Required Handoff To Replay

Before handing to `single-variable-replay-harness`, provide:

```text
BASELINE_FILE:
BOUNDARY: <object | tenant | role | property | state | token | amount | order>
VARIABLE:
OLD_VALUE:
NEW_VALUE:
EXPECTED_IMPACT:
VERIFY_BY:
```

## Pivots

- Full-run orchestration: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- State diff: [workflow-state-diff-lab](../workflow-state-diff-lab/SKILL.md)
- Race harness: [logic-race-harness](../logic-race-harness/SKILL.md)
- Payments/rewards: [payment-promo-rewards-abuse](../payment-promo-rewards-abuse/SKILL.md)
- Portal/OA workflow: [portal-workflow-task-abuse](../portal-workflow-task-abuse/SKILL.md)
- Tenant/admin control plane: [tenant-admin-control-plane-abuse](../tenant-admin-control-plane-abuse/SKILL.md)
- Evidence pack: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
