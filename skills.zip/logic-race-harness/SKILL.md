---
name: logic-race-harness
description: "Template-driven race harness for business logic testing. Use when one-time actions, claims, balances, approvals, verification, inventory, or reward operations may be vulnerable to parallel replay or multi-endpoint TOCTOU windows."
role: harness
domain: business-logic
---

# Logic Race Harness

Use this for authorized race validation after a safe baseline proves the action should only succeed once.

## High-Value Targets

Coupons, points, sign-in, claims, balance transfer, withdrawal, refund, inventory, reservation, approval, verification, reset, and task claim flows.

## Race Models

- Same request replay.
- Check + use.
- Multi-endpoint burst such as `apply-coupon + checkout`.
- Async drift where frontend success precedes backend finalization.

## Execution Ladder

1. Serial replay.
2. Small parallel test: 2-5 requests.
3. Medium parallel test: 10-20 requests if safe.
4. Escalate to [race-condition](../race-condition/SKILL.md) for H2 single-packet or last-byte sync.

## Evidence

Save pre-state, request group, success count, post-state, and impact.
