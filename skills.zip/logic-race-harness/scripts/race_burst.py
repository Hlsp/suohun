#!/usr/bin/env python3
"""Small HTTP race/replay harness for authorized business-logic tests.

Request spec JSON:
{
  "method": "POST",
  "url": "https://example.test/api/claim",
  "headers": {"Authorization": "Bearer ...", "Content-Type": "application/json"},
  "body": "{\"code\":\"X\"}"
}
"""
import argparse, concurrent.futures, json, time, urllib.request, urllib.error
from pathlib import Path

def send(spec, idx):
    body = spec.get("body")
    data = body.encode() if isinstance(body, str) else None
    req = urllib.request.Request(spec["url"], data=data, method=spec.get("method", "GET").upper())
    for k,v in spec.get("headers", {}).items(): req.add_header(k, v)
    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=spec.get("timeout", 15)) as r:
            text = r.read(4096).decode("utf-8", errors="replace")
            return {"idx": idx, "status": r.status, "ms": int((time.time()-start)*1000), "body_prefix": text[:300]}
    except urllib.error.HTTPError as e:
        text = e.read(4096).decode("utf-8", errors="replace")
        return {"idx": idx, "status": e.code, "ms": int((time.time()-start)*1000), "body_prefix": text[:300]}
    except Exception as e:
        return {"idx": idx, "error": repr(e), "ms": int((time.time()-start)*1000)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("-n", "--count", type=int, default=5)
    ap.add_argument("-w", "--workers", type=int, default=5)
    ap.add_argument("--out")
    args = ap.parse_args()
    spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex:
        rows = list(ex.map(lambda i: send(spec, i), range(args.count)))
    print(json.dumps(rows, ensure_ascii=False, indent=2))
    if args.out:
        Path(args.out).write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
if __name__ == "__main__": main()
