---
name: jndi-injection
description: "JNDI injection playbook. Use when Java applications log, deserialize, template, or evaluate user-controlled strings that may trigger JNDI, LDAP, RMI, DNS, or naming lookups."
role: specialist
domain: java-jvm
---

# JNDI Injection

Use this skill when a Java stack may resolve attacker-controlled names through JNDI or related lookup mechanisms.

## Core Model

JNDI injection is a lookup-chain issue:

1. User input reaches a lookup-capable component: logging, expression evaluation, deserialization, template, config, or message processing.
2. The component interprets a lookup expression or naming reference.
3. The JVM performs DNS, LDAP, RMI, or another naming request from the server environment.
4. Impact depends on runtime version, library configuration, class loading rules, and network controls.

For black-box testing, first prove lookup execution with a harmless DNS/HTTP marker.

## Recon Questions

- Is the stack Java-based: headers, errors, cookies, frameworks, file extensions, or dependency clues?
- Which inputs are logged or processed asynchronously: headers, username, user-agent, error messages, chat, imports, queue messages?
- Does the application use Log4j, Spring, LDAP clients, JMS, JMX, RMI, or deserialization endpoints?
- Are callbacks DNS-only, LDAP/RMI, HTTP, or blocked entirely?
- Is input processed immediately, by a worker, or by an admin/log viewer later?
- Are mitigations present: disabled lookups, patched libraries, egress filtering, local classloading disabled?

## Test Families

### Callback Detection

Use unique lookup markers per input location. A DNS callback alone proves lookup evaluation but not code execution.

### Async and Log-Sink Discovery

Headers, usernames, search strings, filenames, error fields, and API metadata may be logged and processed later. Track timestamps and input path.

### Protocol and Egress Matrix

Compare DNS, LDAP, RMI, and HTTP callbacks only enough to classify egress and lookup behavior. Avoid destructive payloads.

### Runtime Impact Assessment

If lookup is confirmed, infer library/runtime posture from callback type, headers, blocked protocols, and observable errors. Escalation requires explicit scope.

## Validation Ladder

1. Identify Java or lookup-capable surfaces.
2. Send unique harmless markers to one input at a time.
3. Correlate callbacks with request IDs and timestamps.
4. Determine sync versus async processing.
5. Classify mitigation and egress behavior.
6. Package evidence as lookup execution plus scoped impact.
7. Remove stored markers where possible.

## Evidence Standard

Capture:

- input surface and exact marker ID
- callback log with timestamp and source metadata
- request/response correlation
- sync or async trigger path
- mitigation inference
- cleanup step

## Pivots

- Deserialization entrypoints: [deserialization-insecure](../deserialization-insecure/SKILL.md)
- Expression evaluation: [expression-language-injection](../expression-language-injection/SKILL.md)
- SSTI Java engines: [ssti-server-side-template-injection](../ssti-server-side-template-injection/SKILL.md)
- Blind callback evidence: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
