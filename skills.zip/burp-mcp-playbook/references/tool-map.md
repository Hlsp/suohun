# Burp MCP Tool Map

## Read-only evidence

- `get_proxy_http_history(count, offset)`: page through Proxy HTTP history.
- `get_proxy_http_history_regex(count, offset, regex)`: search history by request/response text.
- `get_proxy_websocket_history(count, offset)`: page through WebSocket messages.
- `get_proxy_websocket_history_regex(count, offset, regex)`: search WS messages.
- `get_scanner_issues(count, offset)`: review Burp Scanner issues.
- `output_project_options()`: inspect project, proxy, logger, scope, session, and resource pool settings.
- `get_active_editor_contents()`: read currently focused Burp message editor.

## Replay and handoff

- `send_http1_request(content, targetHostname, targetPort, usesHttps)`: direct HTTP/1.1 replay.
- `send_http2_request(pseudoHeaders, headers, requestBody, targetHostname, targetPort, usesHttps)`: direct HTTP/2 replay.
- `create_repeater_tab(content, targetHostname, targetPort, usesHttps, tabName)`: preserve a request for manual review.
- `send_to_intruder(content, targetHostname, targetPort, usesHttps, tabName)`: start Intruder from a selected request.

## OOB and task control

- `generate_collaborator_payload(customData)`: create a single OOB payload for a candidate sink.
- `get_collaborator_interactions(payloadId)`: poll OOB evidence.
- `set_task_execution_engine_state(running)`: pause/unpause Burp background tasks.
- `set_proxy_intercept_state(intercepting)`: toggle Proxy Intercept.

## Codec helpers

- `url_encode`, `url_decode`, `base64_encode`, `base64_decode`, `generate_random_string`.

Use codec helpers to preserve or verify serialization only. They do not prove cryptographic weakness by themselves.
