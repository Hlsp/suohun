---
name: burp-mcp-playbook
description: "Use when the task involves Burp Suite MCP tools for authorized Web/API testing, including Proxy HTTP history review, WebSocket history review, Repeater/Intruder handoff, controlled HTTP replay, Scanner issue review, Collaborator OOB checks, codec helpers, or Burp project/proxy configuration triage."
role: playbook
domain: recon-traffic-mcp
---

# Burp MCP Playbook

Use Burp as a live evidence and replay surface. Let skills decide strategy; let Burp provide captured facts, request replay, and reportable evidence.

## Default Tool Order

1. `output_project_options` to understand proxy listener, intercept, filters, scope, session handling, and scanner/resource settings.
2. `get_proxy_http_history` or `get_proxy_http_history_regex` to collect real traffic before guessing endpoints.
3. `get_proxy_websocket_history` or regex variant when the workflow uses WS/WSS.
4. `create_repeater_tab` for manual analyst review or preserving a promising request.
5. `send_http1_request` or `send_http2_request` only for a narrow, authorized replay.
6. `send_to_intruder` only after a concrete fuzz dimension is selected.
7. `get_scanner_issues` and `get_collaborator_interactions` when packaging findings.

## Decision Guide

- Need to see what happened: read Proxy history first.
- Need one exact replay: use `send_http1_request`/`send_http2_request`; keep method, Host, cookies, and body unchanged except the single variable under test.
- Need analyst-visible evidence: use `create_repeater_tab` with a descriptive tab name.
- Need payload expansion or brute-style variation: send to Intruder only after scope, rate, and target are explicit.
- Need OOB SSRF/XXE/deserialization callback: generate one Collaborator payload, inject it into one candidate sink, then poll interactions.
- Need encoding checks: use `url_encode`, `url_decode`, `base64_encode`, or `base64_decode` for validation, not as proof of encryption.

## Black-Box Business Logic Loop

1. Capture a clean user workflow through Burp.
2. Pull the relevant history and convert it with [burp-history-to-workflow](../burp-history-to-workflow/SKILL.md).
3. Dedupe and rank with [traffic-dedupe-prioritizer](../traffic-dedupe-prioritizer/SKILL.md).
4. Select one hypothesis in [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md).
5. Replay exactly one variable change with [single-variable-replay-harness](../single-variable-replay-harness/SKILL.md) or Burp replay tools.
6. Package proof with [logic-evidence-pack](../logic-evidence-pack/SKILL.md) and [burp-finding-bridge](../burp-finding-bridge/SKILL.md).

## Guardrails

- Prefer read-only history review before active replay.
- Do not use Scanner, Intruder, Collaborator, or broad replay without a bounded authorized target and test purpose.
- Keep Burp Intercept off during autonomous browsing unless the user wants manual interception.
- Do not treat Burp Scanner findings as confirmed until one minimal replay proves impact.
- Keep raw Burp evidence separate from derived workflow artifacts.

## Reference

Read `references/tool-map.md` only when exact tool roles or arguments are unclear.
