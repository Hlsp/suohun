---
name: authbypass-authentication-flaws
description: "Authentication bypass testing playbook. Use when assessing login, registration, password reset, account recovery, MFA, device trust, session issuance, token predictability, enumeration, and rate-limit boundary flaws."
role: specialist
domain: auth-api
---

# Authentication Bypass Flaws

Use this skill when the target question is: can a user become authenticated, recover an account, skip verification, or keep a session without satisfying the intended proof of identity?

## Core Model

Authentication has four linked phases:

1. Identity claim: username, email, phone, tenant, SSO identity, device, invite.
2. Proof: password, OTP, reset token, magic link, recovery code, OAuth/SAML assertion, device approval.
3. Session issuance: cookie, bearer token, refresh token, remember-me token, device binding.
4. Post-auth boundary: role, tenant, MFA state, verification state, account status.

Bugs usually appear when one phase is checked but another phase is trusted implicitly.

## Recon Questions

- Which identifiers are accepted and normalized: email case, phone format, username aliases, tenant IDs?
- Which flows issue sessions: login, signup, reset, invite accept, magic link, SSO callback, MFA recovery?
- Is MFA enforced before or after session issuance?
- Are reset or OTP tokens bound to user, tenant, action, device, and freshness?
- Does account status matter: unverified, disabled, locked, deleted, invited, migrated?
- Are rate limits bound to IP, account, device, session, or global counters?

## Test Families

### State Machine Bypass

Try entering later steps directly: verify, reset confirm, MFA check, recovery finalize, invite accept, or session refresh. The decisive evidence is a session or privileged state without the prior proof.

### Reset and Magic-Link Binding

Test token reuse, token swapping between accounts, stale token acceptance, host/header poisoning of generated links, email-change races, and reset completion after account state changes.

Apply the SRC token-lifecycle model:

- generation: which identity, tenant, action, device, and session created it?
- delivery: email/SMS/app/miniapp/third-party callback and whether destination is client-controlled
- verification: whether the token is checked against the claimed user and current account state
- consumption: single-use vs reusable, whether parallel consumption is possible
- invalidation: password/email/phone/role/account-state changes, logout, MFA changes, tenant removal
- cross-surface reuse: Web, H5, miniapp, APP, admin, API, and SSO callback endpoints

### MFA and Device Trust

Check whether a partial login session can access APIs, refresh tokens, enroll new devices, use backup codes, disable MFA, or mark a device trusted before the second factor is complete.

### Registration and Invite Abuse

Test duplicate identity normalization, pre-account takeover, invite reuse, role inheritance, tenant binding, and email/phone verification bypass.

For invite/binding/delegation flows, pivot to `account-binding-invite-delegation-abuse` and test whether target identity, target tenant, assigned role, and act-as scope are server-bound rather than client-selected.

### Enumeration and Throttling

Compare response body, timing, status code, headers, lockout behavior, OTP resend behavior, and rate-limit keys. Keep tests low volume and scoped.

### Credential Testing Boundaries

Only test default credentials, password spraying, or brute-force behavior when the authorization scope explicitly allows it. Prefer minimal lockout-safe probes and rate-limit verification over large wordlists.

## Validation Ladder

1. Build two self-controlled accounts plus one unverified or low-privileged state if possible.
2. Map every authentication and recovery endpoint with required preconditions.
3. Replay each step without the previous step's proof.
4. Swap tokens, identifiers, tenants, devices, and sessions one variable at a time.
5. Confirm the resulting session state and accessible APIs.
6. Revoke created sessions, devices, and test accounts.

## Evidence Standard

Capture:

- flow diagram with expected preconditions
- baseline successful flow
- bypass request with missing or swapped proof
- resulting cookie/token/session state
- account, role, tenant, and MFA state after bypass
- low-volume rate-limit evidence when relevant
- cleanup steps

## Pivots

- JWT/session token issues: [jwt-oauth-token-attacks](../jwt-oauth-token-attacks/SKILL.md)
- OAuth/OIDC flows: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- SAML assertions: [saml-sso-assertion-attacks](../saml-sso-assertion-attacks/SKILL.md)
- Authorization after login: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Business workflow abuse: [business-logic-vulnerabilities](../business-logic-vulnerabilities/SKILL.md)
