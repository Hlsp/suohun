---
name: auth-sec
description: >-
role: router
domain: auth-api
  Entry P1 category router for authentication and authorization. Use when
  testing login flows, sessions, object authorization, JWT, OAuth, CORS, CSRF,
  and enterprise SSO weaknesses before any deeper auth topic skill.
---

# Authentication and Authorization Router

Use this as the category entry for authentication, session, and authorization-boundary testing.

## When to Use

- Target includes login, registration, password reset, MFA, session cookies, JWT, OAuth, SSO, or enterprise identity.
- Traffic suggests object authorization, cross-tenant access, CORS trust, CSRF, or token scope issues.
- You need to decide whether to test authentication first or authorization first.

## Skill Map

- [Authentication Bypass](../authbypass-authentication-flaws/SKILL.md): login bypass, reset, MFA, enumeration, weak verification.
- [IDOR Broken Object Authorization](../idor-broken-object-authorization/SKILL.md): object ownership and nested authorization.
- [API Authorization and BOLA](../api-authorization-and-bola/SKILL.md): BOLA, BOPLA, BFLA across API endpoints.
- [JWT OAuth Token Attacks](../jwt-oauth-token-attacks/SKILL.md): JWT claims, algorithms, token scope and lifetime.
- [OAuth OIDC Misconfiguration](../oauth-oidc-misconfiguration/SKILL.md): redirect URI, state, nonce, PKCE, account linking.
- [CSRF Cross Site Request Forgery](../csrf-cross-site-request-forgery/SKILL.md): CSRF token, SameSite, JSON CSRF, login CSRF.
- [CORS Cross Origin Misconfiguration](../cors-cross-origin-misconfiguration/SKILL.md): reflected Origin, credentialed cross-origin reads, allowlist bypass.
- [SAML SSO Assertion Attacks](../saml-sso-assertion-attacks/SKILL.md): assertion wrapping, signature validation, audience and ACS boundaries.

## Recommended Flow

1. Identify the auth model and session boundary.
2. Extract object, tenant, role, token, and state identifiers from real traffic.
3. Test object/function/property authorization before deep token crypto unless token evidence is strong.
4. Move into OAuth/OIDC/SAML only when the protocol appears in real redirects, metadata, or tokens.

## Output

```text
AUTH_MODEL:
BOUNDARY_TO_TEST:
NEXT_SKILL:
BASELINE_NEEDED:
ONE_VARIABLE_MUTATION:
```
