---
name: performing-web-cache-poisoning-attack
description: "Tool-assisted web cache poisoning companion. Use when validating unkeyed headers, parameters, host metadata, normalization mismatch, or CDN cache behavior after identifying a cacheable target."
role: wrapper
domain: recon-traffic-mcp
license: Apache-2.0
metadata:
  domain: cybersecurity
  subdomain: web-application-security
  version: refined-local
---

# Performing Web Cache Poisoning Attack

This is the tool-assisted companion to [web-cache-deception](../web-cache-deception/SKILL.md). Use the canonical cache skill for methodology and this skill for repeatable cache-key and poisoning experiments.

## Workflow

1. Pick a self-scoped URL with an explicit cache-buster.
2. Establish baseline cache behavior with repeated requests.
3. Change one candidate unkeyed input at a time.
4. Confirm whether the origin uses the input and the cache ignores it.
5. Verify persistence from a clean request without the poisoning input.
6. Purge, expire, or isolate the test entry.

## Candidate Inputs

- host and forwarded host headers
- scheme and port headers
- language, encoding, device, and user-agent variants
- query parameters, duplicate keys, and path normalization
- redirect targets and absolute URLs
- response header injection or CRLF sinks

## Local Assets

- `scripts/agent.py` for bundled tool wrapper.
- `references/api-reference.md` for generated tool notes.

## Evidence Standard

Capture cache-buster, baseline cache headers, poisoning request, clean retrieval request, persisted response diff, cache key inference, and purge/cleanup.

## Pivots

- Canonical cache methodology: [web-cache-deception](../web-cache-deception/SKILL.md)
- Host header abuse: [http-host-header-attacks](../http-host-header-attacks/SKILL.md)
- CRLF/header injection: [crlf-injection](../crlf-injection/SKILL.md)
- Request smuggling chain: [request-smuggling](../request-smuggling/SKILL.md)
