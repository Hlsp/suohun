---
name: bug-bounty-hunter
description: "Simple bug-bounty report/tracking helper. Use only when the user explicitly asks for bug bounty report generation, reward tracking, or this named helper; not as a vulnerability-hunting entry router."
role: report
domain: reporting-governance
license: MIT
metadata:
  openclaw:
    emoji: 🐛
  version: 1.0.0
---

# Bug Bounty 猎人 Skill


> Entry deconfliction: this is a report/reward tracking helper, not a default vulnerability-hunting router. Generic Web/SRC target testing should start from `zhang-web-src-default-runner`.

自动扫描漏洞，帮你赚取 Bug Bounty 奖励。

## 核心功能

### 1. 漏洞扫描
- SQL 注入检测
- XSS 漏洞扫描
- CSRF 漏洞检测
- 敏感信息泄露

### 2. 报告生成
- 专业漏洞报告
- 复现步骤
- 修复建议

### 3. 奖励追踪
- 项目奖励范围
- 提交状态
- 收入统计

## 使用方法

### 扫描目标

```
扫描 example.com 的常见漏洞
```

### 生成报告

```
为发现的漏洞生成 Bug Bounty 报告
```

### 查找项目

```
推荐适合新手的 Bug Bounty 项目
```

---

创建：2026-03-11