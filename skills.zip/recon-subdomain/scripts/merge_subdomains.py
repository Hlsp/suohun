#!/usr/bin/env python3
"""Merge and deduplicate multiple subdomain lists."""
import argparse
import sys
from pathlib import Path
from typing import Set


def read_subdomains(file_path: str) -> Set[str]:
    subdomains: Set[str] = set()
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                sub = line.strip()
                if not sub or sub.startswith('#'):
                    continue
                sub = sub.replace('https://', '').replace('http://', '')
                sub = sub.split('/')[0].split(':')[0].strip().lower().rstrip('.')
                if sub:
                    subdomains.add(sub)
    except FileNotFoundError:
        print(f"Warning: File not found: {file_path}", file=sys.stderr)
    return subdomains


def is_wildcard(subdomain: str, wildcard_subs: Set[str]) -> bool:
    parts = subdomain.split('.')
    if len(parts) < 2:
        return False
    root = '.'.join(parts[-2:])
    return f'*.{root}' in wildcard_subs or f'*.{root}.*' in wildcard_subs


def main():
    parser = argparse.ArgumentParser(description="Merge and deduplicate subdomain lists")
    parser.add_argument('files', nargs='+', help='Subdomain list files to merge')
    parser.add_argument('-o', '--output', required=True, help='Output file')
    parser.add_argument('--sort', action='store_true', help='Sort output alphabetically')
    parser.add_argument('--filter-wildcards', action='store_true', help='Remove wildcard subdomain entries')
    parser.add_argument('--wildcard-file', help='File containing known wildcard patterns')
    args = parser.parse_args()

    all_subdomains: Set[str] = set()
    wildcards: Set[str] = read_subdomains(args.wildcard_file) if args.wildcard_file else set()

    for file_path in args.files:
        subs = read_subdomains(file_path)
        all_subdomains.update(subs)
        print(f"Read {len(subs)} unique subdomains from {file_path}", file=sys.stderr)

    if args.filter_wildcards and wildcards:
        before = len(all_subdomains)
        all_subdomains = {s for s in all_subdomains if not is_wildcard(s, wildcards)}
        print(f"Filtered {before - len(all_subdomains)} wildcard matches", file=sys.stderr)

    output = sorted(all_subdomains) if args.sort else list(all_subdomains)
    Path(args.output).write_text('\n'.join(output) + ('\n' if output else ''), encoding='utf-8')
    print(f"Wrote {len(output)} unique subdomains to {args.output}", file=sys.stderr)


if __name__ == '__main__':
    main()
