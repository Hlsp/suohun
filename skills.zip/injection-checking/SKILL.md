---
name: injection-checking
description: "Entry router for injection testing. Use when user-controlled input may reach SQL, templates, shells, XML parsers, URL fetchers, interpreters, headers, request framing, or file/path resolvers and you need to pick the right specialist skill before deep testing."
role: router
domain: injection-server
---

# Injection Checking

Use this router to classify the sink before loading a specialist skill.

## Quick Triage

| Observation | Route |
|---|---|
| SQL query, sorting, filtering, report errors | `sqli-sql-injection` / `exploit-sqli` |
| HTML, JS, DOM, stored content | `xss-cross-site-scripting` / `exploit-xss` |
| Template expression | `ssti-server-side-template-injection` |
| XML, SVG, SOAP, OOXML | `xxe-xml-external-entity` |
| Server fetches URL/host | `ssrf-server-side-request-forgery` |
| Shell, transcoder, importer, command wrapper | `cmdi-command-injection` |
| JSON DSL or Mongo operators | `nosql-injection` |
| Header, Location, Set-Cookie controlled | `crlf-injection` / `http-host-header-attacks` |
| HTTP framing, CL/TE, H2/H1 mismatch | `request-smuggling` |
| SpEL, OGNL, EL, rule expression | `expression-language-injection` |
| Path, filename, download or preview parameter | `file-access-vuln` |

## Rules

Confirm the parsing boundary, change one input location at a time, classify deltas, then pivot to the narrow specialist.
