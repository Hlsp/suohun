---
name: open-redirect
description: "Open redirect playbook. Use when URL parameters, return paths, OAuth redirects, login flows, SSO callbacks, form actions, or client-side navigation sinks control where the browser is sent."
role: specialist
domain: auth-api
---

# Open Redirect

Use this skill when an application reflects or consumes a destination URL and then navigates, redirects, opens a window, or sets a `Location` header.

## High-Value Locations

- login/logout `next`, `redirect`, `returnUrl`, `continue`, `callback`
- OAuth/OIDC/SAML `redirect_uri`, relay state, post-login continuation
- email verification, password reset, invitation, payment return URLs
- client-side routers, `window.location`, `window.open`, meta refresh
- proxy/jump endpoints and third-party bridge pages

## Validation Ladder

1. Establish a legitimate same-origin redirect baseline.
2. Replace only the destination with a benign external domain.
3. Test whether navigation happens server-side, client-side, or both.
4. Check whether path-only allowlists can be bypassed.
5. If OAuth/SSO is involved, verify whether redirect abuse can leak code/token/state.

## Bypass Families

```text
//example.com
https://example.com
https:example.com
/\\example.com
/%5cexample.com
https://trusted.example.com.evil.example
https://evil.example#trusted.example
https://trusted.example@evil.example
```

Common parser confusion:

- scheme-relative URLs
- backslash normalization
- URL-decoded second pass
- username/password portion before `@`
- open redirect chained through trusted domain
- double-encoded or nested `url=` parameters

## What Counts as Impact

Open redirect alone is often low severity. Escalate when it enables:

- OAuth/OIDC code or token theft
- password reset or invite link poisoning
- trusted-domain phishing with sensitive workflow
- CSP or CORS bypass chain
- SSRF or server-side fetch redirection
- payment or SSO return flow manipulation

## Evidence Standard

Capture:

- baseline redirect URL
- mutated destination
- response `Location` or client-side navigation sink
- browser-visible final URL
- whether cookies/tokens/codes are exposed during the redirect

## Pivots

- OAuth/OIDC redirect abuse: `oauth-oidc-misconfiguration`
- Host header generated links: `http-host-header-attacks`
- Server-side URL fetch follows redirect: `ssrf-server-side-request-forgery`
- Business return URL or payment callback: `payment-promo-rewards-abuse`
