# MCP Runbook

## Purpose

Use this reference when the main problem is execution discipline rather than algorithm identification. It provides a stable order for MCP tooling so the assessment stays evidence-driven.

## Recommended Order

1. Check session health.
   - Use browser health checks first if reverse-engineering tools are already attached.
   - Prefer an isolated browser context for targets with aggressive anti-automation logic.
2. Navigate and reproduce.
   - Open the target page.
   - Perform the smallest authorized action that triggers the protected request.
3. Capture traffic.
   - Record at least two request and response pairs when possible.
   - Save method, URL, headers, request body or query, response body, and timing.
4. Trace initiators.
   - Identify the target request in network logs.
   - Inspect the initiator or stack to find the wrapper function and source file.
5. Search source code.
   - Search for the wrapper name first.
   - Search nearby business keys or field names before generic crypto terms.
6. Hook runtime behavior.
   - Hook the wrapper first.
   - Hook generic primitives only when the wrapper is unclear or bypassed.
7. Inspect state.
   - Check cookies, localStorage, sessionStorage, and globals for key material, salts, or per-session values.
8. Rebuild and verify.
   - Reproduce the serialization and transformation chain in a standalone PoC.

## Practical Search Terms

Use these groups instead of broad unfocused search:

- Field-centric: `data`, `key`, `result`, `sign`, `payload`, `ciphertext`, `bizContent`
- Crypto-centric: `encrypt`, `decrypt`, `CryptoJS`, `AES`, `RSA`, `subtle`, `JSEncrypt`
- Context-centric: request path fragments, API host fragments, wrapper names, action names such as `sendCode`, `login`, `submit`

## Hook Strategy

Prefer this order:

1. Business wrapper or interceptor
2. Serialization helper
3. Crypto wrapper module
4. Generic primitive
5. Transport layer such as `fetch` or `XMLHttpRequest.prototype.send`

## Common Failure Modes

- Captured only one sample and missed a dynamic field
- Hooked a library primitive too early and collected noisy data
- Mistook Base64 or gzip for encryption
- Assumed request and response use the same algorithm
- Ignored browser storage where the nonce, public key, or salt actually lived

## Minimum Notes To Keep

For each important step, write down:

- What triggered the request
- Which file or function handled the transformation
- Which values were observed before and after the transformation
- Which values are static, session-bound, server-provided, or still unknown
