# Report Template Guidance

## Default Structure

Use this structure unless the user asks for a different format:

```markdown
# Web Application Frontend Security Audit Report

## 1. Scope And High-Level Conclusion
- Target:
- Authorized action:
- Overall assessment:

## 2. Interface Overview
- Endpoint:
- Method:
- Protected fields:
- Security objective:

## 3. Evidence Summary
- Sample count:
- Key request location:
- Key response location:
- Main script files:

## 4. Protection Mechanism Analysis
| Component | Type | Algorithm or pattern | Source and notes |
| :--- | :--- | :--- | :--- |
| Request protection | encoding/signature/encryption |  |  |
| Key exchange |  |  |  |
| Response handling |  |  |  |

## 5. Key Code Locations
- Target file:
- Request entry:
- Response entry:
- Key or seed source:

## 6. Protocol Reconstruction
- Request chain:
- Response chain:
- Unknowns:

## 7. Verification PoC
```python
# Reproduce the observed protocol here
```

## 8. Risks And Recommendations
- 

## 9. Limits And Open Questions
- 
```

## Writing Rules

- Separate observed facts from inference.
- If a field is unknown, write `unconfirmed`.
- Mention when the PoC is partial because of missing server-side secrets or dynamic session state.
- Keep field names and code identifiers exactly as observed.

## Localization

If the user prefers Chinese output, translate headings and prose in the final report, but keep code, identifiers, endpoint paths, and parameter names unchanged.
