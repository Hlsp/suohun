# Protocol Decision Guide

## Goal

Use this guide to classify the front-end protection scheme before promising decryption or a reusable PoC.

## Quick Classification

### Likely encoding only

Clues:

- Plain JSON becomes Base64, URL-encoded text, hex, or compressed blobs
- No key, IV, nonce, or digest logic appears nearby
- The browser can reverse the value with only local transforms

Actions:

- Reconstruct the exact serialization and encoding order
- Do not call it encryption

### Likely signature or MAC

Clues:

- Request keeps readable business fields plus a `sign`, `token`, or digest field
- Code sorts params, concatenates strings, or mixes timestamp and nonce before hashing
- There is no reversible decrypt path for the protected field

Actions:

- Reconstruct canonicalization order and digest inputs
- Look for HMAC, MD5, SHA-1, SHA-256, or custom string builders
- Do not promise response decryption unless a real decrypt path exists

### Likely symmetric encryption

Clues:

- One wrapper takes plaintext plus a key or IV and emits ciphertext
- Matching decrypt logic exists in the front-end
- Key material or IV can be found in code, storage, globals, or runtime state

Actions:

- Capture plaintext, key source, IV or nonce source, mode, padding, and output encoding
- Verify request and response flows independently

### Likely hybrid encryption

Clues:

- The request contains both business ciphertext and a separate protected key field
- RSA or public-key handling appears alongside AES or another symmetric primitive
- The site uses a public key to protect a generated session key or random seed

Actions:

- Trace how the symmetric key is generated
- Trace how the public key is loaded or refreshed
- Confirm the transport format for both ciphertext and protected key

## High-Value Observables

Prioritize these values:

- Plaintext before encryption
- Canonicalized string before signing
- Session key or random seed
- IV, nonce, salt, or padding mode
- Final encoded transport representation
- Response decode or decrypt chain

## Warning Signs

Be cautious when:

- Ciphertext length changes slightly between runs because of JSON shape, not key changes
- The page uses a wrapper named `encrypt` that only Base64-encodes data
- The same field name appears in both request and response but uses different logic
- The PoC works once only because a nonce or timestamp was hard-coded
