import requests


def build_protected_request(plaintext: dict) -> dict:
    # TODO: reproduce the exact serialization, signing, encryption, and encoding chain
    raise NotImplementedError


def decode_protected_response(payload: str):
    # TODO: reproduce the exact decode or decrypt chain
    raise NotImplementedError


if __name__ == "__main__":
    sample_plaintext = {}
    protected = build_protected_request(sample_plaintext)
    print(protected)
