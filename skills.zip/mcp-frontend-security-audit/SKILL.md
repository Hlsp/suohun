---
name: mcp-frontend-security-audit
description: Run authorized Web application frontend security assessments with MCP browser and reverse-engineering tools. Use when Codex needs to analyze a target URL under explicit authorization, capture encoded or encrypted request and response samples, trace `data`/`key`/`result`/`sign` flows back to JavaScript source, inspect browser-side key management, reconstruct the protocol, and produce an evidence-backed PoC plus Markdown audit report.
role: playbook
domain: browser-frontend-reverse
---

# MCP Frontend Security Audit

## Overview

Use this skill to drive a disciplined frontend security assessment for an authorized target site. Prefer MCP browser and reverse-engineering tools over static guesswork, and only make claims about algorithms, keys, IVs, or decryptability when there is direct evidence or a clearly marked inference chain.

## Quick Start

When the user asks to start an authorized assessment for a target URL, do this first:

1. Confirm the target URL, the allowed business action, and the desired output language.
2. Capture representative traffic before searching broadly through source code.
3. Trace the request initiator before hooking low-level crypto primitives.
4. Keep notes in three buckets: observed facts, strong inference, and unresolved items.
5. If the flow looks signature-only rather than reversible encryption, say so early and adjust the plan.

## Decision Guide

Choose the next step based on the blocker:

1. If the browser session is unstable, read `references/mcp-runbook.md`.
2. If the main question is "encryption or just encoding/signature", read `references/protocol-decision-guide.md`.
3. If the user wants a report or starter PoC quickly, run `scripts/scaffold_audit_artifacts.py`.
4. If the target is noisy or heavily obfuscated, combine this skill with `complex-js-reverse`.

## Inputs To Collect

Collect or infer these inputs before deep analysis:

- Target URL and any known API host or path patterns
- Authorized action to trigger, such as login, send-code, search, or submit
- Suspected protected fields such as `data`, `key`, `result`, `sign`, `ciphertext`, or `payload`
- Preferred PoC language: Python, Node.js, or browser JavaScript
- Safety constraints, such as avoiding repeated SMS triggers or state-changing actions

If some inputs are missing, make the smallest safe assumption and state it explicitly.

## Standard Workflow

1. Prepare a clean browser baseline.
   - Open the target in an isolated browser context when possible.
   - Clear target cookies, `localStorage`, and `sessionStorage` before sample capture.
   - Check browser health first if MCP tools show stale sessions or attachment issues.
2. Capture representative protected traffic.
   - Navigate to the target URL.
   - Trigger the smallest authorized business action that reproduces the protected flow.
   - Capture at least two full request and response pairs when possible.
   - Record method, URL, host, headers, protected fields, and timing.
3. Trace the request initiator before broad searching.
   - Use MCP network tooling to identify the target request.
   - Inspect the initiator or call stack to find the JavaScript wrapper that assembles or transforms the protected payload.
   - Prefer the business wrapper over generic library calls as the first anchor point.
4. Audit source code with focused search terms.
   - Inspect loaded bundles and search for `encrypt`, `decrypt`, `AES`, `RSA`, `CryptoJS`, `subtle`, `publicKey`, `cipher`, `sign`, `nonce`, `iv`, and business-specific wrapper names.
   - Search for object construction around `data`, `key`, `result`, `sign`, `payload`, or `bizContent`.
   - Distinguish minified library code from application wrappers before promising conclusions.
5. Inspect runtime behavior and key flow.
   - Hook or trace the narrowest useful function first.
   - Prefer wrappers such as `encryptRequest`, request interceptors, response interceptors, `decryptResult`, or serializer helpers.
   - Hook generic primitives such as `CryptoJS.AES.encrypt`, `CryptoJS.AES.decrypt`, `window.crypto.subtle.encrypt`, `window.crypto.subtle.decrypt`, `JSEncrypt.prototype.encrypt`, `fetch`, or `XMLHttpRequest.prototype.send` only when wrapper hooks are insufficient.
   - Extract plaintext, serialized input, key material, IV or nonce, transport encoding, and the final ciphertext if observable.
   - Inspect cookies, `localStorage`, `sessionStorage`, and global objects for public keys, salts, tenant IDs, device fingerprints, timestamps, and nonce sources.
6. Reconstruct request and response paths separately.
   - Verify request serialization, signing, encryption, encoding, and transport order.
   - Verify response decoding, integrity checks, decompression, and decryption order.
   - Do not assume request and response are symmetric.
7. Build a standalone PoC only after the evidence chain is coherent.
   - Reproduce the exact serialization and encoding order.
   - Keep placeholders for values that are session-bound, server-provided, or still unverified.
   - State clearly whether the PoC is complete, partial, or blocked by missing secrets or dynamic state.
8. Deliver an evidence-backed report.
   - Report what was observed directly.
   - Mark inference explicitly.
   - List unknowns and remaining blockers instead of guessing.

## Operating Rules

- Treat Base64, URL encoding, JSON stringify, protobuf, gzip, and compression as encoding layers, not encryption.
- Treat hybrid encryption as a hypothesis until the request path, response path, and key exchange path confirm it.
- Treat sorted params plus digest fields such as `timestamp`, `nonce`, `appId`, `token`, and `sign` as potential signature flows, not automatically decryptable ciphertext.
- Prefer runtime evidence over ciphertext-length heuristics.
- Prefer hooks over breakpoints unless local variables inside a specific stack frame are required.
- Avoid destructive or high-friction business actions unless the user explicitly asks for them and they are within scope.
- Do not repeat SMS, email, or payment-style actions unnecessarily. Reuse captured samples whenever possible.
- Keep scope limited to the explicitly authorized target and workflow.

## Evidence Checklist

Collect these artifacts whenever possible:

- Request URL, method, host, and protected fields
- Matching response body and protected fields
- Initiator stack or source location
- Exact wrapper or primitive responsible for transformation
- Plaintext before transformation
- Key source, IV, nonce, salt, or public-key source
- Serialization order and transport encoding
- Response decode or decrypt path
- Relevant browser storage or runtime globals
- Reproducible PoC or a precise explanation of why full reproduction is blocked

## Deliverables

Default deliverables are:

- A Markdown audit report using `references/report-template.md`
- A starter PoC generated by `scripts/scaffold_audit_artifacts.py`
- A short note that separates observed facts from inference and open questions

If the user works in Chinese, localize the final report headings and prose, but keep code, identifiers, and field names unchanged.

## Resource Map

Read these files only when needed:

- `references/mcp-runbook.md`: MCP tool ordering, capture sequence, and practical fallback moves
- `references/protocol-decision-guide.md`: distinguish encoding, signatures, symmetric encryption, and hybrid schemes
- `references/report-template.md`: compact report structure and wording guidance
- `scripts/scaffold_audit_artifacts.py`: generate a report shell and language-specific PoC starter
