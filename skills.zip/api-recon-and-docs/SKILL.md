---
name: api-recon-and-docs
description: "API reconnaissance and documentation review playbook. Use when mapping OpenAPI, Swagger, GraphQL schemas, frontend routes, mobile configs, versions, examples, and undocumented API behavior."
role: playbook
domain: recon-traffic-mcp
---

# API Recon and Docs

Use this skill before API fuzzing or authorization testing.

## Sources

- OpenAPI, Swagger UI, Postman collections, GraphQL schema, WSDL
- frontend bundles, source maps, mobile apps, config JSON, route manifests
- OPTIONS responses, CORS preflight, errors, enum validation, example payloads
- versioned paths, beta endpoints, admin panels, webhook docs, SDKs

## Workflow

1. Inventory base URLs, versions, auth modes, and content types.
2. Extract endpoint, method, parameter, schema, and response examples.
3. Mark sensitive object types: user, tenant, role, file, payment, order, token, export.
4. Mark protected-looking properties: role, owner, tenant, status, price, amount, quota, plan, audit state, token, permission.
5. Diff docs against live traffic, JS, and mobile/miniapp wrappers to find hidden, stale, beta, admin, or deprecated endpoints.
6. Build a prioritized test matrix for BOLA, BOPLA/mass assignment, BFLA, hidden parameters, and business logic.

## High-Value Recon Rules

- For every discovered endpoint like `/api/v1/users/123`, also check parent/base paths such as `/api/v1`, `/api`, and docs/schema locations.
- Error bodies are documentation: required parameters, enum names, internal object names, and hidden fields should become replay candidates.
- Response fields that are absent from create/update schemas are strong BOPLA candidates.
- Docs are leads, not findings. A finding requires live route reachability and backend data/state impact.

## Evidence Standard

Save source URL/file, discovered endpoint, auth requirement, sensitive parameters, and reason it is high priority.

## Pivots

- API fuzzing: [api-fuzzing-bug-bounty](../api-fuzzing-bug-bounty/SKILL.md)
- API auth: [api-auth-and-jwt-abuse](../api-auth-and-jwt-abuse/SKILL.md)
- BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- GraphQL: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
