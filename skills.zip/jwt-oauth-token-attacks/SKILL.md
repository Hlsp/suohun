---
name: jwt-oauth-token-attacks
description: "JWT and OAuth token attack playbook. Use when validating token signatures, claims, key selection, refresh tokens, OAuth/OIDC flows, account binding, authorization code exchange, or bearer-token boundaries."
role: specialist
domain: auth-api
---

# JWT and OAuth Token Attacks

Use this skill when authentication or authorization relies on bearer tokens, JWTs, OAuth/OIDC flows, refresh tokens, authorization codes, or token-derived claims.

## Core Model

Token security is a trust-chain problem:

1. Token issuance: who creates the token and under which client, user, tenant, scope, and assurance level?
2. Token integrity: which algorithm, key, `kid`, JWKS, issuer, and audience are trusted?
3. Token consumption: which service validates which claims and how strictly?
4. Session binding: how refresh, revocation, device trust, MFA, and account linking interact.

A valid-looking token is not enough. Prove which validator accepts which modified trust claim.

## Recon Questions

- Is the token JWT, opaque bearer, session cookie, refresh token, ID token, SAML bridge, or custom blob?
- Which services consume it: frontend API, gateway, microservice, admin API, export worker?
- Are `iss`, `aud`, `azp`, `sub`, `tenant`, `scope`, `role`, `exp`, `nbf`, `jti`, and MFA claims enforced?
- How are keys selected: static secret, JWKS, `kid`, `jku`, embedded cert, tenant key, rotating key?
- Can tokens from one client, tenant, environment, or flow be replayed elsewhere?
- Does logout/revocation affect access tokens, refresh tokens, and existing sessions consistently?

## Test Families

### JWT Integrity and Algorithm Checks

Test whether unsigned tokens, algorithm changes, key confusion, weak secrets, or `kid`/JWKS selection mistakes are accepted. Use self-owned accounts and minimal claim changes.

### Claim Trust and Authorization

Change role, scope, tenant, user ID, audience, issuer, expiry, and MFA-related claims one at a time. The decisive proof is server-side access change, not just successful decoding.

### OAuth/OIDC Flow Binding

Validate redirect URI matching, `state`, `nonce`, PKCE, client binding, code reuse, token substitution, and ID-token audience checks.

### Refresh and Revocation

Test token rotation, refresh reuse, logout, password reset, MFA reset, device revocation, and session invalidation boundaries.

### Cross-Service Replay

Try tokens across API versions, hosts, tenants, mobile/web clients, staging/prod-like environments, and backend services only within scope.

## Validation Ladder

1. Decode and classify token type without trusting decoded content.
2. Establish a baseline request with a self-owned account.
3. Mutate one header or claim at a time.
4. Confirm validator behavior through server-side response and state.
5. Test flow binding for OAuth/OIDC tokens separately from API bearer checks.
6. Revoke or rotate test tokens and sessions.

## Evidence Standard

Capture:

- token source and intended audience
- decoded header/claim subset relevant to the test
- mutation matrix and server results
- endpoint or service that accepted the token
- resulting privilege/data/state change
- revocation or cleanup step

## Pivots

- OAuth/OIDC flow details: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- JWT none check: [performing-jwt-none-algorithm-attack](../performing-jwt-none-algorithm-attack/SKILL.md)
- JWT algorithm confusion: [exploiting-jwt-algorithm-confusion-attack](../exploiting-jwt-algorithm-confusion-attack/SKILL.md)
- API authorization: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
- Authentication flows: [authbypass-authentication-flaws](../authbypass-authentication-flaws/SKILL.md)
