---
name: csp-bypass-advanced
description: "Advanced Content Security Policy bypass playbook. Use when an XSS or content injection path exists but CSP limits execution or exfiltration, and you need to analyze nonces, hashes, trusted sources, JSONP, redirects, uploads, or policy gaps."
role: specialist
domain: browser-frontend-reverse
---

# CSP Bypass Advanced

Use this skill after you have an injection path and need to understand what CSP actually blocks or still permits.

## Parse the Policy First

Record these directives:

- `script-src`, `default-src`, `object-src`, `base-uri`
- `frame-ancestors`, `form-action`, `connect-src`, `img-src`
- nonce/hash usage and whether `strict-dynamic` is present
- report-only vs enforced policy

## Common Weaknesses

- wildcard or broad trusted domains
- JSONP or callback endpoints on trusted domains
- uploadable same-origin script or HTML content
- nonce leakage into DOM or reusable server-side nonce
- missing `base-uri` enabling base tag abuse
- permissive `connect-src` or `img-src` for data exfiltration
- redirects on trusted hosts that lead to attacker-controlled script

## Validation Ladder

1. Confirm the original XSS path and CSP violation.
2. Determine which directives block the payload.
3. Test only allowed sources and sinks.
4. Prefer same-origin or trusted-domain abuses before exotic bypasses.
5. If execution is impossible, assess data exfiltration or UI redress impact.

## Evidence Standard

- full CSP header or meta policy
- blocked payload and browser console violation
- allowed source/sink used for bypass
- final execution or data movement proof
- why the policy failed

## Pivots

- Injection path itself: `xss-cross-site-scripting`
- Non-script data capture: `dangling-markup-injection`
- Open redirect on trusted source: `open-redirect`
- Upload same-origin content: `upload-insecure-files`
