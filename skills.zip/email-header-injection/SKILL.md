---
name: email-header-injection
description: "Email header injection playbook. Use when contact forms, notification APIs, invites, password reset, or email templates place user-controlled data into SMTP headers, envelope fields, or rendered email content."
role: specialist
domain: injection-server
---

# Email Header Injection

Use this skill when a feature sends email and user input may affect recipient, subject, sender, reply-to, template variables, links, attachments, or raw SMTP headers.

## Core Model

Email abuse is a construction-chain bug:

1. Web/API input is accepted and normalized.
2. Application builds SMTP envelope, message headers, MIME parts, and body.
3. Mail library or relay interprets separators, encoded words, display names, and recipients.
4. The delivered message creates impact: extra recipient, spoofed sender, poisoned reset link, data disclosure, or phishing amplification.

Prove which layer is affected before claiming impact.

## Recon Questions

- Which fields reach email output: name, email, subject, message, template variables, redirect URL, host, locale?
- Does the app build headers manually or through a framework mailer?
- Are CRLF characters rejected, normalized, double-decoded, or passed through?
- Can the tester observe the full delivered message source?
- Are sender domains aligned with SPF, DKIM, and DMARC?
- Does the email contain privileged links such as reset, invite, approval, export, or magic-login URLs?

## Test Families

### Header Separator Injection

Probe whether encoded or raw line separators can add or alter headers. Validate only with self-controlled mailboxes and harmless headers.

### Recipient Expansion

Check whether `To`, `Cc`, `Bcc`, reply-to, envelope recipient, or list headers can be influenced. The evidence must be delivery to a controlled mailbox that was not intended by the baseline flow.

### Display Name and Sender Confusion

Test display-name parsing, quoted strings, Unicode normalization, and reply-to handling. Distinguish UI spoofing from real sender-domain authentication bypass.

### Link Poisoning

Password reset, invite, and magic-link emails often depend on Host, forwarded headers, open redirects, or user-controlled return URLs. Pivot to host-header or open-redirect testing when link origin changes.

### MIME and Attachment Boundaries

For rich email templates, inspect whether user input breaks MIME boundaries, injects HTML, changes attachment metadata, or alters calendar/invite content.

## Validation Ladder

1. Send a baseline message to a controlled mailbox and save full raw source.
2. Mutate one field at a time with separator, quoting, and encoding probes.
3. Compare delivered source, not just the UI preview.
4. Confirm whether the effect is header-level, envelope-level, or body-level.
5. Test reset/invite link poisoning only with self-owned accounts.
6. Clean up test recipients, invites, and messages.

## Evidence Standard

Capture:

- submission request and target feature
- baseline delivered raw email source
- mutated request and delivered raw source
- exact changed header, envelope, link, or body part
- controlled mailbox proof
- business impact and cleanup step

## Pivots

- General CRLF sink: [crlf-injection](../crlf-injection/SKILL.md)
- Password reset link poisoning: [http-host-header-attacks](../http-host-header-attacks/SKILL.md)
- Redirect links in email: [open-redirect](../open-redirect/SKILL.md)
- Account recovery logic: [authbypass-authentication-flaws](../authbypass-authentication-flaws/SKILL.md)
