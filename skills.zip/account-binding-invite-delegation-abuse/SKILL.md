---
name: account-binding-invite-delegation-abuse
description: "Account binding, invite, delegation, impersonation, account recovery, reset-token, SSO linking, and identity-linking abuse playbook. Use when phone, email, social account, SSO, device, invite, delegation, or act-as-user flows may allow takeover or privilege expansion."
role: specialist
domain: auth-api
---

# Account Binding Invite Delegation Abuse

Use this skill when an identity, account, role, tenant, device, or delegation relationship is created or changed through a multi-step flow.

## Typical Surfaces

- email/phone/social-account binding or replacement
- SSO/OAuth/OIDC/SAML linking and unlinking
- invitation creation, invite acceptance, invite links, one-time invite tokens
- delegation, proxy submit, act-as-user, support impersonation, assistant/agent modes
- password reset, magic link, recovery code, MFA recovery, device trust
- tenant/org/team membership, role assignment, approval of account changes

## Token Lifecycle Questions

For every token/link/code, answer:

- Which user, tenant, email/phone, device, action, and session is it bound to?
- Is it single-use? Can it be reused after completion?
- Does it expire after password/email/phone/role/account-state changes?
- Can it be swapped across A/B accounts, tenants, devices, or flows?
- Does it issue a full session, partial session, or only action permission?
- Does MFA or account verification happen before or after session issuance?

## Hypotheses

- invite token is not bound to invited user or organization.
- inviter can assign a role higher than their own.
- reset/binding flow verifies only current session, not the target identity being changed.
- stale invite or reset link remains valid after role change, account deletion, or tenant removal.
- act-as/delegation token is not scoped to target user, object, action, or time window.
- SSO/linking flow trusts unverified email/phone claims.
- partial-login or pre-MFA session can access APIs, enroll devices, issue tokens, or change bindings.

## Minimal Test Flow

1. Baseline a legitimate invite, binding, reset, or delegation flow with self-owned accounts.
2. Identify token/link/code, target identity, tenant/org, role, device, and session variables.
3. Mutate exactly one variable: target email/phone/userId, role, tenant, token, callback, session, or device id.
4. Complete accept/confirm/finalize and re-read account/session/role/binding state.
5. Test stale/reuse only after a clean baseline.
6. Revoke created sessions, devices, roles, bindings, and invites.

## Strong Evidence

- A token generated for A works for B.
- A lower role invites or grants a higher role.
- email/phone/social binding changes for the wrong account.
- reset or magic-link flow issues a session for the wrong identity.
- delegated/act-as action applies outside intended user/object/action scope.
- partial-login state accesses APIs before MFA or verification completion.

## Related Skills

- `authbypass-authentication-flaws`
- `oauth-oidc-misconfiguration`
- `saml-sso-assertion-attacks`
- `tenant-admin-control-plane-abuse`
- `api-authorization-and-bola`
- `single-variable-replay-harness`
