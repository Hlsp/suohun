---
name: performing-graphql-security-assessment
description: "GraphQL security assessment playbook. Use when reviewing GraphQL endpoints for schema exposure, auth, resolver authorization, hidden fields, batching, complexity, persisted queries, and mutation abuse."
role: playbook
domain: auth-api
---

# Performing GraphQL Security Assessment

Use this skill as the GraphQL router and assessment checklist.

## Core Model

GraphQL security issues usually sit at resolver boundaries:

1. Schema exposes objects, relations, mutations, and arguments.
2. Client controls query shape and variables.
3. Resolvers enforce auth inconsistently across fields, nodes, nested relations, and mutations.
4. Impact appears as data exposure, unauthorized state change, excessive resource use, or hidden workflow abuse.

## Recon Questions

- Where is the endpoint and how is it authenticated?
- Is introspection enabled or can schema be inferred from errors and bundles?
- Are persisted queries used and are hashes bound to operations?
- Which resolvers expose IDs, tenants, roles, prices, statuses, or relations?
- Are depth, complexity, aliasing, batching, and rate limits enforced?
- Do mutations share authorization logic with REST endpoints?

## Test Families

### Schema and Operation Mapping

Use introspection when available. If disabled, mine frontend bundles, operation names, persisted hashes, and validation errors.

### Resolver Authorization

Test root fields, nested fields, node lookups, connections, mutations, and fragments across accounts and tenants.

### Hidden Variables and Mass Assignment

Add likely fields to input objects and variables. Confirm state changes, not only accepted responses.

### Batching and Complexity

Use low-volume, bounded probes to check aliasing, batching, depth, and recursion limits without stressing the service.

### Persisted Query and Transport Issues

Test operation/hash binding, GET versus POST, content type, WebSocket subscriptions, and cache behavior.

## Validation Ladder

1. Capture baseline operations from the UI.
2. Build schema or operation inventory.
3. Create account/tenant matrix.
4. Test resolver authorization with one changed ID or field at a time.
5. Check complexity controls with small bounded queries.
6. Package exact operation, variables, and server-side proof.
7. Revert test data.

## Local Assets

- `scripts/agent.py` for bundled tool wrapper.
- `references/api-reference.md` for generated tool notes.

## Evidence Standard

Capture operation, variables, auth context, mutation, response, data/state impact, and cleanup.

## Pivots

- Introspection: [performing-graphql-introspection-attack](../performing-graphql-introspection-attack/SKILL.md)
- Depth/complexity: [performing-graphql-depth-limit-attack](../performing-graphql-depth-limit-attack/SKILL.md)
- Hidden params: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
- BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
