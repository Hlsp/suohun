---
name: clickjacking
description: "Clickjacking playbook. Use when sensitive browser actions may be framed, overlaid, gesture-confused, or protected only by weak X-Frame-Options, CSP frame-ancestors, or UI checks."
role: specialist
domain: browser-frontend-reverse
---

# Clickjacking

Use this skill when a sensitive action is reachable in a browser and may be triggered while embedded in another page or UI context.

## Core Model

Clickjacking requires:

1. Sensitive page or action can be framed or embedded.
2. User interaction can be visually misdirected.
3. Action completes with ambient credentials or weak confirmation.
4. Impact is proven with a self-owned account and reversible state change.

## Recon Questions

- Which actions are high value: payment, transfer, role change, invite, API key, OAuth grant, deletion, settings, MFA?
- Are `X-Frame-Options` and `Content-Security-Policy: frame-ancestors` present and consistent?
- Are subdomains, partner origins, mobile webviews, or sandboxed frames allowed?
- Does the action require re-auth, CSRF token, confirmation, or pointer/keyboard gesture?
- Is UI state predictable enough for overlay alignment?

## Test Families

### Frame Policy Check

Validate headers in browser behavior, not only raw responses. Check redirects and final action pages separately.

### Sensitive Action Harness

Build a minimal local harness that frames the target and demonstrates a harmless reversible action with the tester account.

### Multi-Step and Drag Interaction

Some workflows can be abused through predictable multi-click sequences, drag/drop, or cursorjacking-like UI tricks.

### OAuth and Permission Grants

OAuth consent, account linking, admin grants, and app authorization are high-value frame targets when not protected.

## Validation Ladder

1. Identify a sensitive action and baseline state.
2. Check frame policy on every step and redirect.
3. Build a minimal proof harness.
4. Demonstrate a reversible state change with a self-owned account.
5. Test same-origin/subdomain allowlist edge cases if relevant.
6. Revert the action.

## Evidence Standard

Capture target action, headers, browser framing result, proof harness, before/after state, and cleanup.

## Pivots

- CSRF chain: [csrf-cross-site-request-forgery](../csrf-cross-site-request-forgery/SKILL.md)
- OAuth consent: [oauth-oidc-misconfiguration](../oauth-oidc-misconfiguration/SKILL.md)
- Business workflow impact: [business-logic-vulnerabilities](../business-logic-vulnerabilities/SKILL.md)
