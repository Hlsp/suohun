---
name: http-host-header-attacks
description: "HTTP Host header and forwarded-host abuse playbook. Use when applications, proxies, password reset flows, tenants, virtual hosts, caches, or URL generators trust Host or X-Forwarded-* headers."
role: specialist
domain: injection-server
---

# HTTP Host Header Attacks

Use this skill when request host metadata affects URL generation, routing, tenant selection, cache keys, security policy, redirects, emails, or backend fetches.

## Core Model

Host header abuse happens when different layers disagree about authority:

1. Front proxy receives one host.
2. Application reads `Host`, absolute URI, or forwarded headers.
3. Router, cache, URL generator, email template, or SSRF client trusts the wrong authority.
4. The tester controls generated links, cache variants, vhost routing, tenant boundary, or internal routing.

Always identify which layer consumed which host value.

## Recon Questions

- Does the app generate absolute URLs in reset links, invites, redirects, canonical links, CORS, CSP, or webhooks?
- Which headers are honored: `Host`, `X-Forwarded-Host`, `X-Host`, `Forwarded`, absolute-form URI?
- Are there multiple proxies or a CDN before the app?
- Is routing based on host, path, tenant slug, SNI, or a combination?
- Are cache keys and application routing using the same authority?
- Can generated emails or async jobs be observed in a controlled mailbox/account?

## Test Families

### Password Reset and Invite Poisoning

Change host metadata during link generation and inspect the delivered email or notification. The key evidence is a privileged link using tester-controlled authority.

### Virtual Host and Tenant Routing

Probe whether alternate host values expose internal vhosts, admin apps, staging routes, or the wrong tenant context.

### Forwarded Header Confusion

Compare `Host`, absolute URI, and `X-Forwarded-*` variants. Many issues arise when edge validation checks one header and the app trusts another.

### Cache Key Mismatch

If cache and app disagree about host, a response generated for one authority may be served under another. Use cache-busters and self-scoped paths.

### SSRF and Backend Routing

Some apps build backend URLs from host metadata. If host changes server-side fetch targets or webhooks, pivot to SSRF analysis.

## Validation Ladder

1. Capture a baseline request and generated absolute URLs.
2. Change one authority source at a time.
3. Observe response headers, body links, emails, redirects, and logs.
4. Identify the consuming layer: edge, app, worker, cache, or mailer.
5. Prove impact with self-owned accounts and reversible actions.
6. Restore any changed settings or generated links.

## Evidence Standard

Capture:

- baseline and mutated request authority fields
- response, email, redirect, or cache artifact showing changed authority
- affected workflow and privilege level
- layer inference from headers or timing
- cleanup step

## Pivots

- Reset/email delivery: [email-header-injection](../email-header-injection/SKILL.md)
- Open redirect chain: [open-redirect](../open-redirect/SKILL.md)
- Cache interaction: [web-cache-deception](../web-cache-deception/SKILL.md)
- SSRF routing: [ssrf-server-side-request-forgery](../ssrf-server-side-request-forgery/SKILL.md)
- Request desync authority confusion: [request-smuggling](../request-smuggling/SKILL.md)
