---
name: cmdi-command-injection
description: "Command injection playbook. Use when user input may reach shell commands, process execution, converters, import pipelines, diagnostic tools, archive handlers, image or document processors, CI tasks, or blind out-of-band command sinks."
role: specialist
domain: injection-server
---

# Command Injection

Use this skill when a feature appears to pass user-controlled data into a shell, command-line tool, script runner, converter, or diagnostic utility.

## Likely Entry Points

- ping, traceroute, nslookup, curl, git, ffmpeg, imagemagick, ghostscript
- archive extraction, document conversion, image resize, media metadata
- CI/CD hooks, backup jobs, import/export tasks, custom report builders
- parameters named `host`, `ip`, `url`, `cmd`, `path`, `file`, `repo`, `branch`, `args`

## Triage Questions

1. Is the sink a real shell or an argv-style process call?
2. Which OS and shell are likely: Linux `sh/bash`, Windows `cmd/PowerShell`, container shell?
3. Is output visible, timing-only, or out-of-band only?
4. Which characters are accepted, normalized, or filtered?
5. Does the input land in command name, argument, environment, file path, or config file?

## Validation Ladder

Start with harmless, low-noise probes:

```text
; id
&& id
| id
`id`
$(id)
; whoami
; sleep 5
```

Windows-oriented probes:

```text
& whoami
| whoami
&& timeout /T 5
; powershell -c whoami
```

Blind indicators:

- controlled timing difference
- DNS/HTTP callback in authorized test infrastructure
- created low-impact marker file in a writable temp path

## Filter Bypass Families

- separators: `;`, `&`, `&&`, `|`, `||`, newline, tab
- command substitution: backticks, `$()`
- whitespace: `${IFS}`, tabs, URL encoding
- quoting: single quote, double quote, backslash, caret on Windows
- pathless commands: absolute paths, shell builtins, environment variables

## Evidence Standard

A useful finding needs one of:

- visible command output
- stable timing delta tied to the command
- OOB interaction tied to a unique payload marker
- server-side artifact in an authorized sandbox

Record:

- original input and mutated input
- exact response/timing/OOB evidence
- likely sink and command context
- required auth and business action

## Pivots

- If the sink is a file processor: `upload-insecure-files`
- If user controls a URL fetch first: `ssrf-server-side-request-forgery`
- If input is template/expression code: `ssti-server-side-template-injection` or `expression-language-injection`
- If shell metacharacters fail but path control exists: `path-traversal-lfi`
