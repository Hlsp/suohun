---
name: performing-graphql-introspection-attack
description: "Focused GraphQL introspection and schema discovery skill. Use when checking whether GraphQL schema, types, fields, directives, mutations, and hidden operations are discoverable in an authorized assessment."
role: specialist
domain: auth-api
---

# Performing GraphQL Introspection Attack

Use this focused skill to discover GraphQL schema information. For full GraphQL assessment, load [performing-graphql-security-assessment](../performing-graphql-security-assessment/SKILL.md).

## Core Model

Schema discovery is valuable because it reveals objects, relations, arguments, directives, mutations, and hidden fields that the UI may not expose.

Introspection risk depends on:

1. whether schema is accessible to anonymous or low-privileged users
2. whether sensitive types or mutations are exposed
3. whether discovered fields lead to data exposure or unauthorized actions
4. whether production differs from staging or documentation

## Workflow

1. Identify endpoint, auth mode, and transport.
2. Test standard introspection with anonymous and authenticated roles.
3. If disabled, infer schema from validation errors, autocomplete, frontend bundles, persisted queries, and operation names.
4. Extract high-value types: users, tenants, roles, payments, files, exports, admin, tokens, audit logs.
5. Pivot from schema discovery to resolver authorization tests.
6. Store schema and evidence separately from exploit notes.

## Local Assets

- `scripts/agent.py` for bundled tool wrapper.
- `references/api-reference.md` for generated tool notes.

## Evidence Standard

Capture endpoint, role, introspection or inference method, discovered sensitive types/fields, and the follow-on test that proves impact.

## Pivots

- Full GraphQL assessment: [performing-graphql-security-assessment](../performing-graphql-security-assessment/SKILL.md)
- Hidden parameters: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
- BOLA: [api-authorization-and-bola](../api-authorization-and-bola/SKILL.md)
