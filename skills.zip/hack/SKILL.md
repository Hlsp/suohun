---
name: hack
description: "Legacy/general HackSkills category router. Prefer zhang-web-src-default-runner for Zhang's normal Web/SRC/CTF work; use this only when the user explicitly asks for HackSkills, non-Web mixed security category selection, or a fallback map before a narrow topic skill."
role: router
domain: general-security
---

# HackSkills Legacy Category Router

Use this as a legacy/general category map only when the user explicitly asks for HackSkills or a non-Zhang mixed security router. For Zhang's usual Web/SRC/CTF workflow, start with [zhang-web-src-default-runner](../zhang-web-src-default-runner/SKILL.md) and let it dispatch to narrower skills.

## Routing First

1. Identify the scene before loading deep skills:
   - no-login black-box
   - logged-in black-box
   - mini-program dynamic/static
   - API/auth/object authorization
   - business logic workflow
   - injection/file/upload/client-side class
2. Select the smallest skill chain that can produce evidence.
3. Establish baseline and capture quality before mutation.
4. Verify one variable at a time.
5. Package evidence and replay steps.

## Primary Entrypoints

- Zhang default Web/SRC/CTF workflow: [zhang-web-src-default-runner](../zhang-web-src-default-runner/SKILL.md)
- Start-test natural prompt: [security-test-dispatcher](../security-test-dispatcher/SKILL.md)
- End-to-end black-box Web/API: [blackbox-pentest-runner](../blackbox-pentest-runner/SKILL.md)
- No-login black-box: [preauth-blackbox-runner](../preauth-blackbox-runner/SKILL.md)
- Logged-in role/tenant matrix: [auth-role-matrix-runner](../auth-role-matrix-runner/SKILL.md)
- Mini-program dynamic/static: [miniapp-dynamic-static-runner](../miniapp-dynamic-static-runner/SKILL.md)
- Burp MCP workflow: [burp-mcp-playbook](../burp-mcp-playbook/SKILL.md)
- Business logic: [blackbox-business-logic-hunter](../blackbox-business-logic-hunter/SKILL.md)
- API security: [api-sec](../api-sec/SKILL.md)
- Recon: [recon-for-sec](../recon-for-sec/SKILL.md)
- Injection: [injection-checking](../injection-checking/SKILL.md)
- Auth/session: [auth-sec](../auth-sec/SKILL.md)
- File access: [file-access-vuln](../file-access-vuln/SKILL.md)

## Quick Category Map

| Evidence | Route |
|---|---|
| Only URL, no credentials | preauth-blackbox-runner |
| Login available, multiple accounts, roles, tenants | auth-role-matrix-runner |
| WeChat miniapp, remote debugging, wxapkg source | miniapp-dynamic-static-runner |
| Burp history / proxy / repeater | burp-mcp-playbook + traffic skills |
| Endpoint probing low-yield but JS is available | preauth-js-hidden-logic-hunter |
| Object IDs, tenant IDs, file keys | object-identity-extractor + ab-object-pair-builder |
| JWT/OAuth/session/token | api-auth-and-jwt-abuse / jwt-oauth-token-attacks |
| IDOR/BOLA/BFLA | api-authorization-and-bola / idor-broken-object-authorization |
| Payment/coupon/member/trial/reward/workflow | business logic domain skills |
| Reflected/stored input | xss-cross-site-scripting / ssti / injection skills |
| File upload/download/preview/export/share | upload/file/export skills |

## Startup Output

When this router is used, respond with inferred task scene, selected skill chain, first concrete step, and current blocker or pivot condition.
