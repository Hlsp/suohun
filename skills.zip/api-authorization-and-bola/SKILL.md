---
name: api-authorization-and-bola
description: "API authorization and BOLA testing playbook. Use when API objects, tenants, roles, files, exports, orders, users, GraphQL nodes, or workflow actions may be accessed across authorization boundaries."
role: specialist
domain: auth-api
---

# API Authorization and BOLA

Use this skill when an authenticated API request references an object, tenant, role, or action that must be authorized server-side.

## Core Model

BOLA exists when the server validates authentication but fails to validate object ownership, tenant membership, role, or workflow permission for the specific action.

## Workflow

1. Prepare at least two self-owned accounts and tenants when possible.
2. Capture baseline read and write requests for account A.
3. Classify the target as BOLA, BOPLA/mass assignment, BFLA, token-scope, or workflow-state before mutation.
4. Swap object IDs, tenant IDs, owner IDs, nested IDs, and relation IDs with account B values.
5. For property-level tests, add or change only one candidate field such as `role`, `isAdmin`, `ownerId`, `tenantId`, `status`, `price`, `quota`, or `plan`.
6. Test read, update, delete, export, share, approve, refund, bind, invite, and admin-like actions separately.
7. Confirm authoritative server-side data/state impact by re-reading with the victim/owner and attacker context.
8. Restore changed data and permissions.

## High-Value Article-Derived Rules

- Do not rely on parameter names alone. Use runtime feedback to infer action type, object relationship, role boundary, and state transition.
- Hidden fields from JS bundles, OpenAPI schemas, GraphQL schema, response bodies, and error messages are BOPLA candidates.
- If one route blocks object swapping, try sibling functions on the same object family: preview, export, share, favorite, recent, recycle-bin, approve, or callback.
- Compare business fields such as `code`, `msg`, `status`, `state`, `role`, `ownerId`, `tenantId`, `auditStatus`, `token`, and `permissions`, not just HTTP status.

## High-Value Targets

- files, exports, previews, shares, recycle-bin objects
- orders, invoices, refunds, payment methods, subscriptions
- teams, tenants, roles, invites, API keys, webhooks
- messages, tickets, approvals, tasks, audit logs
- GraphQL nodes and nested relations

## Evidence Standard

Capture account roles, object ownership proof, baseline request, swapped request, response, final state/data proof, and cleanup.

## Pivots

- IDOR details: [idor-broken-object-authorization](../idor-broken-object-authorization/SKILL.md)
- GraphQL nodes: [graphql-and-hidden-parameters](../graphql-and-hidden-parameters/SKILL.md)
- File/share logic: [export-preview-sharing-logic-abuse](../export-preview-sharing-logic-abuse/SKILL.md)
- Evidence pack: [logic-evidence-pack](../logic-evidence-pack/SKILL.md)
