---
name: logic-fix-verification
description: "Business logic fix verification skill. Use after a logic flaw is patched to confirm the control moved server-side, alternate endpoints and old API versions are covered, race windows are closed, and old tokens, links, or object paths no longer work."
role: specialist
domain: business-logic
---

# Logic Fix Verification

## Goal

不是“复测原 payload 一次就结束”，而是确认修复是否真的堵住了同类旁路。

## Verification Checklist

1. 原始复现链是否关闭
2. 同功能的兄弟接口是否同步关闭
3. 旧版本 API / 导出 / 预览 / 批量接口是否还活着
4. 旧 token / 邀请链接 / 分享链接 / 预览链接 是否失效
5. 降权后旧 session 是否仍可做原动作
6. 竞态窗口是否真正关闭，而不是仅限流或前端补丁

## Pass Criteria

- 服务端返回明确拒绝
- 状态未变化
- 兄弟接口无旁路
- 并发与重放都失效

## Fail Patterns

- 只补了前端
- 只补主接口，漏了导出/批量/旧版本
- 只校验对象存在，未校验对象归属
- token 旧的还可以继续用
