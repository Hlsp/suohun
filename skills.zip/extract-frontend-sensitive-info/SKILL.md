---
name: extract-frontend-sensitive-info
description: Inspect a web app's public frontend assets to extract exposed sensitive information such as hardcoded credentials, client secrets, cryptographic keys and IVs, public or private keys, reversible client-side encryption schemes, environment and internal endpoints, debug leftovers, token storage patterns, and other risky front-end configuration leaks. Use when reviewing a target URL, login page, JS bundles, or API wrapper code during an authorized security assessment.
role: specialist
domain: browser-frontend-reverse
---

# Extract Frontend Sensitive Info

Use this skill when the task is to inspect a target site's public frontend code and runtime state for exposed secrets or risky client-side security design.

## Scope

- Focus on publicly reachable frontend assets, loaded JS bundles, runtime config, anonymous storage, and directly observable requests.
- Do not treat framework constants, demo strings, or generic library code as findings without evidence they are used by the target app.
- Prefer evidence-backed extraction over speculation. Separate observed values from inferences.

## Workflow

1. Stabilize the browser session with `mcp__js_reverse_mcp__check_browser_health`, then open the target page.
2. Enumerate scripts and initial requests with `list_scripts` and `list_network_requests`.
3. Inspect anonymous runtime state with `evaluate_script` and `get_storage`.
4. Search loaded sources for high-value indicators first:
   - `Authorization`, `Basic `, `Bearer `
   - `clientSecret`, `appSecret`, `secret`, `privateKey`, `setPublicKey`
   - `encrypt`, `decrypt`, `CryptoJS`, `AES`, `MD5`, `JSEncrypt`, `subtle`
   - `token`, `access_token`, `refresh_token`
   - `baseUrl`, `api`, `dev`, `test`, `staging`, `localhost`, `192.168.`, `10.`, `172.`
5. Open only the matching code around hits. Confirm whether the value is:
   - hardcoded directly
   - derived from split strings or base64 fragments
   - exposed through runtime config such as `getApp().globalData.config`
   - only part of a third-party library and not app-specific
6. If crypto wrappers exist, determine whether they are actually used by the request layer or login flow.
7. For encrypted request bodies or params, reconstruct the algorithm only if the evidence chain is clear:
   - key source
   - IV source
   - mode and padding
   - encoding and serialization order
8. Check whether "remember me" or local persistence stores reversible secrets in cookies, `localStorage`, or `sessionStorage`.

## High-Value Findings

- Hardcoded OAuth client credentials or Basic auth material
- Private keys, static symmetric keys, static IVs, or reversible client-side password protection
- Runtime config objects exposing key material or environment routes
- Test or development base paths exposed in production-facing frontend code
- Frontend-accessible cookies or storage entries that can be decrypted using bundled code
- Debug logs that print credentials, hashes, tokens, or cryptographic intermediates

## Validation Rules

- Do not report a public key alone as a secret leak.
- Do report a public key when it materially explains a client-side login encryption flow.
- Do not report `localhost` or IP-like strings if they only appear inside generic validation regexes or third-party libraries.
- Do not claim a credential is valid server-side unless there is direct evidence.
- If a request wrapper encrypts all bodies globally, say that explicitly; if the login page sends plaintext fields into the wrapper, say that explicitly.

## Useful Tool Patterns

- `search_in_sources` for broad indicators
- `find_in_script` and `get_script_source` for precise context in minified bundles
- `evaluate_script` for runtime config extraction and decoding base64 fragments
- `get_network_request` for confirming whether specific endpoints are reachable anonymously
- `get_storage` for token and cookie inspection

## Reporting Format

For each finding, provide:
- What was observed
- Where it appears
- Why it matters
- Whether the conclusion is observed or inferred

When useful, include:
- decoded credential values
- derived AES key or IV
- decrypted sample fields
- note on whether the exposed data is used by the current login or request path
