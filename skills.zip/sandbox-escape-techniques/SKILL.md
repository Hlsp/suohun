---
name: sandbox-escape-techniques
description: "Sandbox escape router. Use when the current primitive lands inside a restricted browser, renderer, VM, container, or instrumented sandbox and the next question is how to break the confinement boundary."
role: router
domain: native-pwn-reverse
---

# Sandbox Escape Techniques

Use after a primitive is confirmed inside a confinement boundary. Identify sandbox type, broker boundary, exposed APIs, filesystem/network policy, and available tokens/capabilities.
