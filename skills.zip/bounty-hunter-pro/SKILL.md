---
name: bounty-hunter-pro
description: "Bug-bounty automation compatibility wrapper. Use only when the user explicitly requests scheduled or batch-style bounty automation for an authorized scope; otherwise prefer zhang-web-src-default-runner for normal Web/SRC work."
role: wrapper
domain: general-security
metadata:
  version: 2.0.0
  author: zhang-local-wrapper
  tags:
  - security
  - bug-bounty
  - automation
---

# Bounty Hunter Pro

Use this skill only as a **narrow compatibility wrapper** for explicit bug-bounty automation requests.

It is **not** a default entry router for Zhang's normal interactive Web/SRC workflow.

## When To Use

- The user explicitly asks for recurring, batch, or automation-style bounty reconnaissance.
- The user already provides an authorized scope list or clearly bounded target set.
- The goal is scheduled discovery, not hands-on black-box exploitation.

## When Not To Use

- Generic “帮我测一下”
- normal Web/SRC/CTF assessments
- live browser-driven exploit/debug sessions
- targets without an explicit authorized scope list

In those cases, route to:

- [zhang-web-src-default-runner](../zhang-web-src-default-runner/SKILL.md)
- [recon-and-methodology](../recon-and-methodology/SKILL.md)
- [recon-subdomain](../recon-subdomain/SKILL.md)
- [recon-dir-scan](../recon-dir-scan/SKILL.md)
- [security-bounty-hunter](../security-bounty-hunter/SKILL.md)

## Minimal Automation Contract

Before any batch action, record:

- authorized scope source
- exact domain or asset list
- allowed rate / safety constraints
- output directory
- whether the job is discovery-only or includes validation

## Minimal Output

```text
SCOPE_SOURCE:
AUTHORIZED_TARGETS:
AUTOMATION_MODE:
DISCOVERY_ONLY_OR_VALIDATE:
OUTPUT_PATH:
NEXT_MANUAL_REVIEW_STEP:
```
