---
name: payment-promo-rewards-abuse
description: "Payment, coupon, promo, wallet, points, refund, gift card, subscription, membership, trial, quota, and reward-system logic abuse playbook. Use when black-box testing monetary or incentive flows where settlement, one-time use, rounding, callbacks, state transitions, or stacking rules may fail."
role: specialist
domain: business-logic
---

# Payment Promo Rewards Abuse

Use this skill when the feature directly affects money, entitlement, quota, membership, coupon, reward, or settlement state. Treat it as a business state-machine problem, not a payload list.

## Chain Model

Map the full chain before mutation:

1. eligibility / KYC / account state
2. quote / price / discount / coupon calculation
3. order creation
4. payment, callback, or settlement confirmation
5. fulfillment: membership, quota, points, shipment, content access, reward
6. cancel / refund / revoke / downgrade
7. reuse / replay / race / stale token

## Priority Fields

Watch these fields in request, response, JS, schema, and error messages:

- `amount`, `price`, `total`, `qty`, `count`, `shippingFee`, `currency`
- `discount`, `coupon`, `promo`, `voucher`, `giftcard`, `points`, `balance`
- `paid`, `payStatus`, `refundStatus`, `used`, `claimed`, `redeemed`, `trialed`
- `plan`, `level`, `member`, `vip`, `quota`, `limit`, `entitlement`, `expireTime`
- `orderId`, `tradeNo`, `callback`, `notifyUrl`, `riskStatus`, `auditStatus`

## Hypothesis Matrix

### A. Client Trust

Backend trusts client-submitted price, discount, quantity, freight, currency, membership level, quota, or plan. Visible checkout URL fields, inline-JS variables, or localStorage values should be treated as first-class evidence, not just rendering details.

### B. Stacking

Mutually exclusive discounts, coupons, points, gift cards, trial packs, or first-order benefits can be applied together.

### C. Reuse / Replay

Coupon codes, reward claims, callback confirmations, refund tokens, invite rewards, or one-time order tokens can be reused.

### D. Cancellation / Refund Drift

After cancel, refund, downgrade, or chargeback, benefits are not revoked: points, quota, membership, coupon, file access, gift cards, shipment, or invoices remain valid.

### E. Race Window

Parallel claims, payments, refunds, conversions, or quota issuance bypass single-use or balance checks.

### F. Currency / Rounding / Boundary

Currency switch, decimal rounding, zero/negative/overflow values, huge quantity, or precision mismatch changes settlement or entitlement.

### G. Callback / Third-Party Trust

Notify/callback/status-sync endpoint trusts client-controlled order, amount, status, signature, or idempotency key.

### H. Promo / lottery expiry trust

Backend trusts client-supplied timestamps or state markers to decide whether a lottery, promo, coupon, or reward event is active, upcoming, or ended.

## Verification Ladder

1. Baseline one legitimate low-impact transaction or self-owned test flow.
2. Mutate exactly one variable: amount, discount, quantity, coupon, state, token, callback, or request order.
3. Re-read server-side order, balance, quota, membership, reward, or refund state.
4. Test reuse/replay only with self-owned low-value artifacts.
5. Use race only when a single sequential replay suggests a real window.
6. Record cleanup: cancel, revoke, refund, delete, or reset test benefits.

## Strong Evidence

- final payable amount differs from server-side expectation
- benefit/reward/quota issued without valid payment or eligibility
- coupon/reward redeemed more than once
- refund/cancel keeps entitlement
- user/tenant receives benefit meant for another account
- race produces duplicate order, reward, points, quota, or refund

## Pairings

- Race window: `logic-race-harness` / `race-condition`
- Main logic controller: `blackbox-business-logic-hunter`
- Membership/trial/quota: `subscription-trial-membership-abuse`
- Evidence: `logic-evidence-pack`
