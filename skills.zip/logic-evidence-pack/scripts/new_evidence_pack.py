#!/usr/bin/env python3
"""Create a Markdown evidence pack from simple CLI fields."""
import argparse
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature", default="")
    ap.add_argument("--out", default="business_logic_evidence.md")
    args = ap.parse_args()
    text = f"""# Business Logic Evidence Pack\n\n## Outcome\n\nFeature: {args.feature}\n\n## Accounts / Roles / Tenants\n\n## Preconditions\n\n## Baseline Flow\n\n## Single-Variable Mutation\n\n## Response Delta\n\n## Visible State Delta\n\n## Impact\n\n## Browserless Replay\n\n## Rollback / Cleanup\n"""
    Path(args.out).write_text(text, encoding="utf-8")
    print(args.out)
if __name__ == "__main__": main()
