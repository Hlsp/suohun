---
name: logic-evidence-pack
description: "Evidence and replay packaging skill for business logic findings. Use when you need to preserve baseline flows, account matrices, mutated variables, state transitions, rollback steps, and browserless replay artifacts in a compact format for reporting or retesting."
role: evidence-pack
domain: reporting-governance
---

# Logic Evidence Pack

## Required Blocks

每个业务逻辑发现至少沉淀以下 10 块：

1. surface / feature
2. accounts / roles / tenants
3. preconditions
4. baseline flow
5. mutated variable
6. response delta
7. visible state delta
8. impact statement
9. replay artifact
10. rollback note

## Classification

- `hypothesis`：只有异常信号，没有确定影响
- `confirmed-read`：已确认越权读取
- `confirmed-write`：已确认越权写入/状态变化
- `confirmed-race`：已确认并发窗口导致约束失效

## Compact Template

- Outcome
- Baseline
- Mutation
- Evidence
- Impact
- Replay
- Rollback

## Pairings

- 长期沉淀：`results-storage`
- 最终报告：`pentest-report`
- 黑盒主控：`blackbox-business-logic-hunter`

## Resources

- `assets/business_logic_evidence_template.md`: reusable Markdown evidence template.
- `scripts/new_evidence_pack.py`: generate a fresh evidence pack file.
