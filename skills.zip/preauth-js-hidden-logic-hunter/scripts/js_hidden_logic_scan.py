﻿#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, re
from collections import Counter, defaultdict
from pathlib import Path
from urllib.parse import urlparse

TEXT_SUFFIXES={'.js','.mjs','.cjs','.jsx','.ts','.tsx','.html','.htm','.json','.map','.vue','.txt','.wxml','.axml'}
SKIP_DIRS={'node_modules','.git','__pycache__','coverage'}
STATIC_EXTS={'.js','.css','.png','.jpg','.jpeg','.gif','.svg','.ico','.woff','.woff2','.ttf','.eot','.map','.mp4','.webp','.pdf','.zip'}
RISK={'admin':8,'internal':8,'debug':7,'test':5,'staging':5,'dev':4,'mock':4,'beta':4,'gray':4,'hidden':5,'feature':3,'export':8,'download':7,'preview':7,'share':7,'invite':8,'reset':8,'password':7,'sso':7,'oauth':7,'callback':6,'workflow':8,'approval':7,'task':5,'tenant':8,'org':6,'company':5,'corp':5,'file':6,'upload':6,'import':6,'token':7,'jwt':6,'role':6,'permission':6,'auth':5,'payment':8,'coupon':7,'promo':7,'wallet':7,'reward':7,'quota':6,'invoice':7,'refund':8,'report':5,'audit':6}
FULL_URL=re.compile(r"https?://[^\s'\"`<>{}\\]+",re.I)
PATH_LIT=re.compile(r"([\"'`])(?P<v>/(?!/)[A-Za-z0-9_~./?&=%:#,@;{}$\[\]\-]{1,300})\1")
ROUTE_PROP=re.compile(r"(?i)\b(?:path|route|redirect|url|api|endpoint)\s*[:=]\s*([\"'`])(?P<v>[^\"'`]{1,300})\1")
FEATURE=re.compile(r"(?i)\b[A-Za-z_$][\w$]*(?:flag|enable|enabled|disable|disabled|beta|gray|grey|white|whitelist|permission|role|admin|debug|mock|internal|hidden)[\w$]*\b|\b(?:featureFlags?|permissions?|roles?|needLogin|requiresAuth|isLogin|isAdmin|isDebug|isMock)\b")
STORAGE=re.compile(r"(?i)\b(?P<s>localStorage|sessionStorage)\s*(?:\.\s*(?:getItem|setItem|removeItem)\s*\(\s*([\"'`])(?P<k1>[^\"'`]{1,200})\2|\[\s*([\"'`])(?P<k2>[^\"'`]{1,200})\4\s*\])")
SRCMAP=re.compile(r"sourceMappingURL\s*=\s*(?P<v>[^\s*]+)")
AUTH_TERMS=['beforeEach','requiresAuth','requireAuth','needLogin','isLogin','isLoggedIn','checkLogin','loginRequired','permission','permissions','roles','isAdmin','authGuard','routeGuard','whiteList','whitelist','accessToken','Authorization']
REQ_TERMS=['axios.create','axios.interceptors','interceptors.request','interceptors.response','fetch(','XMLHttpRequest','wx.request','uni.request','my.request','request({','.request(','httpClient','baseURL','baseUrl','withCredentials']
CRYPTO_TERMS=['CryptoJS','JSEncrypt','AES','RSA','encrypt','decrypt','sign(','signature','nonce','timestamp','HmacSHA','SHA256','MD5','subtle.crypto','window.crypto']
ENDPOINT_HINT=re.compile(r"(?i)/(api|openapi|gateway|gw|open|rest|graphql|auth|oauth|sso|admin|internal|workflow|file|download|preview|export|share|invite|reset|user|member|tenant|org|order|pay|payment|coupon|wallet|report|task)\b")

def read_text(p,max_bytes):
    try:
        if p.is_file() and p.stat().st_size>max_bytes: return None
        return p.read_text(encoding='utf-8-sig',errors='ignore')
    except OSError:
        return None

def iter_inputs(inp,max_bytes):
    p=Path(inp)
    if p.exists() and p.is_dir():
        for d,dirs,files in os.walk(p):
            dirs[:]=[x for x in dirs if x not in SKIP_DIRS]
            for f in files:
                fp=Path(d)/f
                if fp.suffix.lower() in TEXT_SUFFIXES: yield fp,read_text(fp,max_bytes)
    elif p.exists() and p.is_file():
        yield p,read_text(p,max_bytes)
    else:
        yield Path('<input-string>'),inp

def line_no(text,i): return text.count('\n',0,i)+1

def ctx(text,i,r=120): return re.sub(r'\s+',' ',text[max(0,i-r):min(len(text),i+r)]).strip()

def norm_path(v):
    v=v.strip().strip("'\"`),;]")
    if v.startswith(('http://','https://')):
        p=urlparse(v); return p.path.rstrip('/') or '/'
    return v.split('?',1)[0].rstrip('/') or '/'

def static_like(v): return Path(norm_path(v).lower()).suffix in STATIC_EXTS

def endpoint_like(v,c):
    l=(v+' '+c).lower()
    return v.startswith(('http://','https://')) or ENDPOINT_HINT.search(v) or any(x in l for x in ['axios','fetch','request','baseurl','endpoint','api'])

def score(v,c,unseen):
    l=(v+' '+c).lower(); s=0
    for k,w in RISK.items():
        if k in l: s+=w
    if endpoint_like(v,c): s+=6
    if '?' in v and re.search(r'(?i)(id|key|token|code|tenant|uid|user)',v): s+=4
    if unseen is True: s+=5
    if static_like(v) and not any(k in l for k in RISK): s-=8
    return s

def seen_paths_from(traffic,max_bytes):
    if not traffic: return set()
    p=Path(traffic); files=[]
    if p.exists() and p.is_dir(): files=[x for x in p.rglob('*') if x.is_file() and x.suffix.lower() in {'.json','.txt','.har'}]
    elif p.exists(): files=[p]
    seen=set()
    for fp in files:
        t=read_text(fp,max_bytes) or ''
        for m in FULL_URL.finditer(t): seen.add(norm_path(m.group(0)))
        for m in PATH_LIT.finditer(t): seen.add(norm_path(m.group('v')))
    return seen

def hit(bucket,seen,kind,source,text,m,value=None):
    v=(value if value is not None else m.group(0)).strip()
    if not v or len(v)>500: return
    ln=line_no(text,m.start()); key=(kind,str(source),v,ln)
    if key in seen: return
    seen.add(key)
    bucket.append({'kind':kind,'value':v,'source':str(source),'line':ln,'context':ctx(text,m.start())})

def scan_file(source,text,seen_paths,traffic_compared,limit=200):
    out=defaultdict(list); seen=set(); candidates=[]
    for rx,kind in [(FULL_URL,'full_url'),(PATH_LIT,'path_literal'),(ROUTE_PROP,'route_or_endpoint_prop')]:
        n=0
        for m in rx.finditer(text):
            if n>=limit: break
            v=m.groupdict().get('v') or m.group(0); c=ctx(text,m.start())
            if kind=='full_url' or v.startswith('/'):
                hit(out['routes_and_paths'],seen,kind,source,text,m,v)
                if endpoint_like(v,c):
                    unseen=None if not traffic_compared else norm_path(v) not in seen_paths
                    candidates.append({'value':v,'source':str(source),'line':line_no(text,m.start()),'context':c,'unseen_in_traffic':unseen,'score':score(v,c,unseen)})
                    n+=1
    for rx,bucket,kind in [(FEATURE,'feature_flags','feature_or_permission_identifier'),(STORAGE,'storage_keys','browser_storage_key'),(SRCMAP,'source_maps','source_map_reference')]:
        n=0
        for m in rx.finditer(text):
            if n>=limit: break
            gd=m.groupdict(); v=gd.get('k1') or gd.get('k2') or gd.get('v') or m.group(0)
            hit(out[bucket],seen,kind,source,text,m,v); n+=1
    for terms,bucket,kind in [(AUTH_TERMS,'auth_guards','auth_or_route_guard'),(REQ_TERMS,'request_wrappers','request_wrapper'),(CRYPTO_TERMS,'crypto_indicators','crypto_or_signature_indicator')]:
        n=0
        for i,line in enumerate(text.splitlines(),1):
            if n>=limit: break
            low=line.lower()
            if any(t.lower() in low for t in terms):
                v=next((t for t in terms if t.lower() in low),terms[0]); key=(kind,str(source),i,v)
                if key not in seen:
                    seen.add(key); out[bucket].append({'kind':kind,'value':v,'source':str(source),'line':i,'context':re.sub(r'\s+',' ',line).strip()[:260]}); n+=1
    out['endpoint_candidates']=candidates
    return out

def write_json(p,data): p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(description='Scan frontend assets for hidden preauth JS logic.')
    ap.add_argument('--input',required=True); ap.add_argument('--traffic'); ap.add_argument('--out',required=True); ap.add_argument('--max-file-mb',type=float,default=8.0)
    a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True); max_bytes=int(a.max_file_mb*1024*1024)
    seen_paths=seen_paths_from(a.traffic,max_bytes) if a.traffic else set(); compared=bool(a.traffic)
    inv={'input':a.input,'traffic_compared':compared,'seen_path_count':len(seen_paths),'files':[], 'routes_and_paths':[], 'feature_flags':[], 'auth_guards':[], 'request_wrappers':[], 'crypto_indicators':[], 'storage_keys':[], 'source_maps':[]}
    candidates=[]
    for source,text in iter_inputs(a.input,max_bytes):
        if text is None:
            inv['files'].append({'source':str(source),'skipped':'size_or_read_error'}); continue
        res=scan_file(source,text,seen_paths,compared)
        inv['files'].append({'source':str(source),'bytes':len(text.encode('utf-8',errors='ignore'))})
        for k in ['routes_and_paths','feature_flags','auth_guards','request_wrappers','crypto_indicators','storage_keys','source_maps']:
            inv[k].extend(res.get(k,[]))
        candidates.extend(res.get('endpoint_candidates',[]))
    dedup={}
    for c in candidates:
        key=(c['value'],c['source'],c['line'])
        if key not in dedup or c['score']>dedup[key]['score']: dedup[key]=c
    candidates=sorted(dedup.values(),key=lambda x:(x['score'],bool(x.get('unseen_in_traffic'))),reverse=True)
    summary={'file_count':len(inv['files']),'route_or_path_count':len(inv['routes_and_paths']),'endpoint_candidate_count':len(candidates),'unseen_endpoint_candidate_count':sum(1 for c in candidates if c.get('unseen_in_traffic') is True),'feature_flag_count':len(inv['feature_flags']),'auth_guard_count':len(inv['auth_guards']),'request_wrapper_count':len(inv['request_wrappers']),'crypto_indicator_count':len(inv['crypto_indicators']),'storage_key_count':len(inv['storage_keys']),'source_map_count':len(inv['source_maps'])}
    inv['summary']=summary
    write_json(out/'hidden_logic_inventory.json',inv); write_json(out/'hidden_endpoint_candidates.json',{'summary':summary,'candidates':candidates[:1000]})
    kws=Counter()
    for c in candidates[:200]:
        l=(c['value']+' '+c.get('context','')).lower()
        for k in RISK:
            if k in l: kws[k]+=1
    md=['# JS Hidden Logic Scan','',f"- input: `{a.input}`",f"- files: {summary['file_count']}",f"- endpoint candidates: {summary['endpoint_candidate_count']} ({summary['unseen_endpoint_candidate_count']} unseen vs traffic)",f"- routes/paths: {summary['route_or_path_count']}",f"- feature/permission indicators: {summary['feature_flag_count']}",f"- auth guard lines: {summary['auth_guard_count']}",f"- request wrapper lines: {summary['request_wrapper_count']}",f"- crypto/signature lines: {summary['crypto_indicator_count']}",'','## Top endpoint candidates']
    for c in candidates[:30]:
        u=c.get('unseen_in_traffic'); lab='unseen' if u is True else 'seen' if u is False else 'not-compared'
        md.append(f"- score {c['score']:>3} [{lab}] `{c['value']}` ({c['source']}:{c['line']})")
    md+=['','## Top risk keywords']+[f'- {k}: {v}' for k,v in kws.most_common(20)]+['','## Next step','Pick one high-score unseen candidate, trace its route guard/request wrapper, then replay a single controlled preauth request.']
    (out/'js_hidden_logic.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'out':str(out),'summary':summary},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
