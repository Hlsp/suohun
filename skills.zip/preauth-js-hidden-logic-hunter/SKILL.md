---
name: preauth-js-hidden-logic-hunter
description: "No-login black-box frontend JavaScript hidden logic hunter. Use when unauthenticated endpoint probing has low yield and the next move is to mine public JS bundles, route tables, chunks, feature flags, API wrappers, auth guards, source maps, and disabled UI logic for hidden anonymous endpoints or business flows."
role: hunter
domain: browser-frontend-reverse
---

# Preauth JS Hidden Logic Hunter

Use this as the fallback branch after public endpoint probing does not produce useful leads. The goal is to turn frontend code into a small set of reproducible pre-auth hypotheses, not to read every bundle.

## Decision Gate

Start here when at least one is true:

- Burp/browser history shows mostly login, static assets, or dead public APIs.
- The visible UI has few functions, but loaded chunks suggest more modules or routes.
- API requests need a wrapper, signature, tenant header, or route state that is only visible in JS.
- The target is a SPA, Umi/webpack app, miniapp webview, portal, or low-documentation API.

## Workflow

1. Capture the runtime baseline: loaded scripts, initial network requests, cookies/storage, route URL, and whether source maps or build manifests exist.
2. Build a JS inventory from public assets using the bundled scanner:

   ```bash
   python scripts/js_hidden_logic_scan.py --input runs/T/assets --traffic runs/T/burp/burp_filtered.json --out runs/T/js-hidden
   ```

3. Rank the scanner output by business value and preauth plausibility:
   - endpoint or route not seen in traffic
   - route guard looks frontend-only or feature-flag based
   - request wrapper reveals required headers, tenant keys, timestamp, nonce, or signature fields
   - disabled UI action still references a live API wrapper
   - internal/test/debug/admin strings occur in app-specific modules, not third-party libraries
4. Trace one candidate end-to-end before expanding:
   - route or UI action -> business method -> request wrapper -> final request
   - record the first point where auth, tenant, object id, or feature flag is checked
5. Replay only one controlled variable at a time. If login is required, keep the candidate as a credentialed follow-up rather than forcing noisy probing.
6. Feed viable endpoint and object candidates back into `preauth-blackbox-runner` or `object-identity-extractor`.

## What To Extract

- Hidden route paths, lazy chunks, page models, and menu metadata.
- Endpoint strings not observed in Burp history.
- Feature flags, gray/beta switches, permission arrays, role checks, and route guards.
- API base URLs, environment selectors, proxy prefixes, and tenant headers.
- Request wrappers, interceptors, serializer methods, and response unwrap logic.
- Storage keys and anonymous tokens that influence routing or request assembly.
- Source map references and build manifests that shorten code review.

## SRC High-Value Mining Bias

When the visible app is only a login page or low-function landing page, prioritize these code clues:

- reset, register, invite, magic link, SSO callback, account binding, device trust, MFA recovery
- Swagger/OpenAPI/GraphQL/schema links, API version prefixes, docs routes, mock/test/debug routes
- disabled actions and hidden menu items that still call live wrappers
- business terms: order, invoice, contract, refund, coupon, points, wallet, member, approval, task, workflow, export, share, preview, upload
- protected property names: `role`, `isAdmin`, `ownerId`, `tenantId`, `status`, `auditStatus`, `price`, `quota`, `plan`
- request wrappers that reveal headers, tenant keys, appid/openid/unionid, timestamp, nonce, sign, or encrypted payload fields

Feed every viable discovery into a concrete branch:

1. endpoint existence and auth boundary
2. BOLA object swap
3. BOPLA/mass-assignment field replay
4. workflow state mutation
5. export/share/file token replay
6. request signing/encryption helper generation

## Triage Rules

- Prefer runtime-confirmed chunks over full-bundle grep.
- Treat third-party library hits as noise until an app-specific caller uses them.
- Do not call a route bypassable because the frontend hides it; prove a backend response or a decisive login wall.
- Separate three outcomes: anonymous live logic, credential-required follow-up, and false lead/static residue.
- Preserve the exact code slice, request sample, and replay command for every lead.

## Routing

- Browser/runtime JS: [browser-pentest-orchestrator](../browser-pentest-orchestrator/SKILL.md)
- Frontend secrets/config: [extract-frontend-sensitive-info](../extract-frontend-sensitive-info/SKILL.md)
- Webpack/chunk recovery: [webpack-runtime-extractor](../webpack-runtime-extractor/SKILL.md)
- Request assembly: [request-chain-tracer](../request-chain-tracer/SKILL.md)
- Crypto/signature entry: [find-crypto-entry](../find-crypto-entry/SKILL.md)
- Storage/key lineage: [storage-and-key-lineage](../storage-and-key-lineage/SKILL.md)
- Burp history input: [burp-scope-traffic-dumper](../burp-scope-traffic-dumper/SKILL.md)
- Object and token candidates: [object-identity-extractor](../object-identity-extractor/SKILL.md)

## Outputs

Return:

1. hidden route and endpoint inventory
2. top unseen endpoint candidates
3. route guard or feature flag evidence
4. wrapper or header requirements
5. one selected preauth hypothesis
6. exact verification step and evidence path
