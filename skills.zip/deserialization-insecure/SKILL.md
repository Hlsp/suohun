---
name: deserialization-insecure
description: "Insecure deserialization playbook. Use when serialized objects, signed tokens, session blobs, remember-me cookies, queues, RPC, cache entries, or import files may be trusted after reconstruction."
role: specialist
domain: injection-server
---

# Insecure Deserialization

Use this skill when untrusted data may be reconstructed into objects, classes, claims, or commands by a backend runtime.

## Core Model

Deserialization risk depends on four gates:

1. Format gate: Java, PHP, .NET, Python pickle, Ruby Marshal, Node, YAML, XML, JSON type metadata, protobuf, or custom binary.
2. Trust gate: signature, encryption, MAC, compression, session store, or object allowlist.
3. Gadget gate: available classes and methods with side effects during reconstruction.
4. Impact gate: file read, SSRF, auth bypass, state change, command execution, or denial of service.

For black-box work, first identify format and trust boundary. Do not assume a visible blob is exploitable.

## Recon Questions

- Where are serialized blobs stored: cookies, hidden fields, headers, mobile state, queues, uploads, caches, exports, RPC?
- Is the data signed, encrypted, compressed, base64-encoded, or versioned?
- What runtime or framework hints exist: Java, PHP, ASP.NET, Rails, Django, Laravel, Spring, Shiro, ViewState?
- Does mutation produce parse errors, signature errors, class errors, or silent resets?
- Can a harmless callback or canary prove object reconstruction?
- Is the vulnerable object processed immediately or by an async worker?

## Test Families

### Format Fingerprinting

Decode layers carefully and preserve originals. Identify magic bytes, headers, delimiters, class names, field names, compression, and MAC structure.

### Trust Boundary Checks

Modify one byte, one field, and one length value separately. Classify whether integrity checks occur before or after parsing.

### Read-Only Canary

Use harmless markers, benign class-not-found errors, or callback-only probes to prove deserialization without destructive side effects.

### Gadget Feasibility

After format and parsing are proven, map likely libraries and gadget families. For Java-specific notes, use the local gadget-chain reference.

### Signed or Encrypted Tokens

If integrity is strong, pivot to key disclosure, algorithm confusion, weak secrets, or server-side session misuse rather than forcing gadget execution.

## Validation Ladder

1. Capture the original blob and decoding chain.
2. Fingerprint format and runtime.
3. Perform minimal mutation to classify trust checks.
4. Prove server-side reconstruction with an error, callback, or controlled state change.
5. Assess gadget feasibility only within scope.
6. Document fix: avoid native object deserialization, enforce allowlists, validate before parse, rotate keys.
7. Restore sessions and remove test artifacts.

## Evidence Standard

Capture:

- original blob and location
- decoding/transformation steps
- mutation matrix and server responses
- runtime/framework inference
- canary, callback, or safe reconstruction proof
- scoped impact and cleanup

## Pivots

- Java gadget notes: [JAVA_GADGET_CHAINS.md](./JAVA_GADGET_CHAINS.md)
- JWT/token issues: [jwt-oauth-token-attacks](../jwt-oauth-token-attacks/SKILL.md)
- File upload/import path: [upload-insecure-files](../upload-insecure-files/SKILL.md)
- JNDI lookup chain: [jndi-injection](../jndi-injection/SKILL.md)
- Expression language: [expression-language-injection](../expression-language-injection/SKILL.md)
