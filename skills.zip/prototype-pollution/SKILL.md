---
name: prototype-pollution
description: "Prototype pollution testing for JavaScript stacks. Use when JSON, query strings, merge utilities, configuration objects, deep setters, or client-side state may modify Object prototype behavior."
role: specialist
domain: injection-server
---

# Prototype Pollution

Use this skill when user-controlled object structure may be merged, cloned, parsed, or assigned into JavaScript objects.

## Core Model

Prototype pollution needs both a source and a sink:

1. Source accepts nested keys or objects from query, JSON, form data, storage, postMessage, or config import.
2. Merge/deep-set logic writes attacker-controlled keys into an object graph.
3. A prototype or shared object property becomes visible elsewhere.
4. A gadget reads the polluted property and changes behavior.

Pollution without a gadget is usually only a primitive. Prove both when possible.

## Recon Questions

- Does input support nested structures: `a[b]`, JSON objects, arrays, dotted paths, YAML, querystring parsers?
- Are libraries present: lodash, jQuery extend, qs, minimist, yargs, merge, hoek, deepmerge?
- Is the target client-side, Node.js server-side, build tooling, or admin import?
- Which properties influence behavior: template options, security flags, URLs, methods, HTML, command options?
- Does pollution persist across requests, users, tenants, or only within one render?

## Test Families

### Safe Canary Pollution

Use harmless canary property names and check whether unrelated objects observe the property. Avoid breaking common properties.

### Parser and Merge Sink Discovery

Test nested key syntaxes and content types one at a time. Determine whether the app blocks `__proto__`, `constructor`, and `prototype` variants consistently.

### Client-Side Gadget Search

Look for polluted properties flowing into DOM sinks, template rendering, router behavior, analytics config, or security checks.

### Server-Side Gadget Search

After pollution is proven, check whether server-side libraries read polluted options in templates, child processes, HTTP clients, or serializers.

## Validation Ladder

1. Identify a nested-object input and baseline behavior.
2. Send a harmless canary property.
3. Check whether the property is observable in a separate object/context.
4. Locate a gadget that consumes the property.
5. Prove impact with the smallest behavior change.
6. Reset app state or session if pollution persists.

## Evidence Standard

Capture source input, merge/parser behavior, canary observation, gadget path, impact proof, and cleanup/reset step.

## Pivots

- Advanced gadgets: [prototype-pollution-advanced](../prototype-pollution-advanced/SKILL.md)
- XSS gadgets: [xss-cross-site-scripting](../xss-cross-site-scripting/SKILL.md)
- SSTI/template gadgets: [ssti-server-side-template-injection](../ssti-server-side-template-injection/SKILL.md)
- NoSQL/object injection: [nosql-injection](../nosql-injection/SKILL.md)
