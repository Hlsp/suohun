#!/usr/bin/env python3
import argparse, json, re, subprocess, sys
from pathlib import Path
from urllib.parse import urlparse

DEFAULT_MAPPER = Path(r'C:\Users\zhang\.codex\skills\traffic-to-workflow-mapper\scripts\map_traffic.py')
METHOD_RE = re.compile(r'^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(\S+)\s+HTTP/\d(?:\.\d)?\s*$', re.I | re.M)


def collect_text(obj):
    texts = []
    if isinstance(obj, str):
        texts.append(obj)
    elif isinstance(obj, list):
        for x in obj:
            texts.extend(collect_text(x))
    elif isinstance(obj, dict):
        for key in ('text', 'request', 'response', 'content', 'message'):
            if key in obj:
                texts.extend(collect_text(obj[key]))
        if not any(k in obj for k in ('text', 'request', 'response', 'content', 'message')):
            for v in obj.values():
                texts.extend(collect_text(v))
    return texts


def headers_to_dict(h):
    if isinstance(h, dict):
        return {str(k): str(v) for k, v in h.items()}
    if isinstance(h, list):
        out = {}
        for item in h:
            if isinstance(item, dict):
                name = item.get('name') or item.get('key')
                val = item.get('value')
                if name is not None:
                    out[str(name)] = '' if val is None else str(val)
            elif isinstance(item, str) and ':' in item:
                k, v = item.split(':', 1)
                out[k.strip()] = v.strip()
        return out
    return {}


def request_from_obj(o):
    if not isinstance(o, dict):
        return None
    q = o.get('request', o)
    if isinstance(q, str):
        parsed = parse_raw(q)
        return parsed[0] if parsed else None
    if not isinstance(q, dict):
        return None
    method = (q.get('method') or o.get('method') or '').upper()
    url = q.get('url') or o.get('url') or q.get('fullUrl') or o.get('fullUrl')
    path = q.get('path') or o.get('path') or q.get('target')
    headers = headers_to_dict(q.get('headers') or o.get('headers') or [])
    body = q.get('body') or q.get('bodyText') or q.get('postData') or o.get('body') or ''
    if isinstance(body, dict):
        body = body.get('text') or json.dumps(body, ensure_ascii=False)
    if not url and path:
        host = headers.get('Host') or headers.get('host') or o.get('host') or ''
        scheme = 'https' if o.get('https') or o.get('usesHttps') else 'http'
        url = f'{scheme}://{host}{path}' if host else path
    if method and url:
        return {'method': method, 'url': url, 'headers': headers, 'body': str(body or ''), 'source': 'burp'}
    return None


def parse_raw(text):
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    starts = [m.start() for m in METHOD_RE.finditer(text)]
    reqs = []
    for idx, start in enumerate(starts):
        end = starts[idx + 1] if idx + 1 < len(starts) else len(text)
        block = text[start:end].strip('\n')
        lines = block.split('\n')
        m = re.match(r'^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s+(\S+)\s+HTTP/', lines[0], re.I)
        if not m:
            continue
        method, target = m.group(1).upper(), m.group(2)
        headers = {}
        i = 1
        while i < len(lines) and lines[i].strip():
            if ':' in lines[i]:
                k, v = lines[i].split(':', 1)
                headers[k.strip()] = v.strip()
            i += 1
        body = '\n'.join(lines[i + 1:]).strip() if i < len(lines) else ''
        host = headers.get('Host') or headers.get('host') or ''
        if target.startswith('http://') or target.startswith('https://'):
            url = target
        elif host:
            scheme = 'https' if headers.get('X-Forwarded-Proto', '').lower() == 'https' else 'http'
            url = f'{scheme}://{host}{target}'
        else:
            url = target
        reqs.append({'method': method, 'url': url, 'headers': headers, 'body': body, 'source': 'raw-burp'})
    return reqs


def normalize(path):
    text = Path(path).read_text(encoding='utf-8-sig', errors='replace')
    reqs = []
    try:
        data = json.loads(text)
        if isinstance(data, list):
            for item in data:
                r = request_from_obj(item)
                if r:
                    reqs.append(r)
        elif isinstance(data, dict):
            for key in ('items', 'history', 'requests', 'flows', 'data'):
                val = data.get(key)
                if isinstance(val, list):
                    for item in val:
                        r = request_from_obj(item)
                        if r:
                            reqs.append(r)
            if not reqs:
                r = request_from_obj(data)
                if r:
                    reqs.append(r)
        if not reqs:
            reqs.extend(parse_raw('\n'.join(collect_text(data))))
    except Exception:
        reqs.extend(parse_raw(text))
    # Deduplicate exact method+url+body while preserving order.
    seen, out = set(), []
    for r in reqs:
        key = (r.get('method'), r.get('url'), r.get('body', '')[:200])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--mapper', default=str(DEFAULT_MAPPER))
    ap.add_argument('--no-map', action='store_true')
    args = ap.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    reqs = normalize(args.input)
    norm = out / 'normalized_traffic.json'
    norm.write_text(json.dumps(reqs, ensure_ascii=False, indent=2), encoding='utf-8')
    result = {'input': args.input, 'normalized': str(norm), 'requests': len(reqs), 'mapped': False}
    if reqs and not args.no_map:
        mapper = Path(args.mapper)
        if not mapper.exists():
            raise SystemExit(f'mapper not found: {mapper}')
        cp = subprocess.run([sys.executable, str(mapper), '--input', str(norm), '--out', str(out)], text=True, capture_output=True)
        result['mapped'] = cp.returncode == 0
        result['mapper_stdout'] = cp.stdout.strip()
        if cp.returncode != 0:
            result['mapper_stderr'] = cp.stderr.strip()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            raise SystemExit(cp.returncode)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
