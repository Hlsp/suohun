# Burp History Input Shapes

The converter accepts any of these practical forms:

1. Raw HTTP request packets concatenated in a text file.
2. JSON array of request objects with `method`, `url`, `headers`, and `body`.
3. MCP tool output saved as JSON content blocks such as `[ {"type":"text", "text":"..."} ]`.
4. Burp-like objects with nested `request` and optional `response` fields.

If parsing yields zero requests, copy the request from Burp Repeater or HTTP history as raw HTTP and retry.
