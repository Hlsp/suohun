---
name: business-logic-vulnerabilities
description: "Business logic vulnerability playbook. Use when reasoning about workflows, race conditions, price manipulation, coupon abuse, reward systems, state machines, multi-step authorization gaps, quota bypass, replay, or cross-user state changes."
role: specialist
domain: business-logic
---

# Business Logic Vulnerabilities

Business logic bugs are constraint failures, not parser bugs. Start by modeling the intended state machine and then prove one broken invariant with the smallest possible replay.

## Core Workflow

1. Capture one clean baseline flow from user action to backend state.
2. Identify the business invariant: one-time use, ownership, price, approval, quota, role, sequence, or tenant boundary.
3. Extract object, identity, state, value, one-time, and bridge keys.
4. Change one variable at a time.
5. Verify impact through backend state or visible business outcome.
6. Stop once read/write/replay/race impact is proven; package evidence.

## High-Value Surfaces

- payment, refund, wallet, points, coupons, gift cards
- trial, subscription, seat count, quota, entitlement
- approval, task center, workflow forms, delegated actions
- invite, account binding, password reset, SSO link
- export, preview, share, recycle bin, favorites, recent use
- multi-tenant org, role, department, project, workspace

## Hypothesis Matrix

| Signal | Hypothesis | Pivot |
|---|---|---|
| `amount`, `price`, `discount`, `points` | server trusts client value | `payment-promo-rewards-abuse` |
| `status`, `step`, `approved`, `paid` | workflow skip or state tamper | stay here |
| `coupon`, `claim`, `invite`, `reset` | replay or one-time failure | `logic-race-harness` |
| object ids in URL/body/header | BOLA or nested auth gap | `api-authorization-and-bola` |
| role/org/tenant fields | control-plane boundary issue | `tenant-admin-control-plane-abuse` |
| hidden button or disabled field | frontend-only gate | `browser-pentest-orchestrator` |
| iframe/jumpLink/token/ticket | bridge token reuse | `portal-workflow-task-abuse` |

## Common Test Families

### Step Skip

- call final confirmation without completing earlier steps
- submit approval action from non-approver state
- access post-MFA or post-verification endpoint directly

### Replay

- reuse coupon, invite, reset token, payment callback, confirmation link
- repeat cancel/refund/claim after success

### Value Manipulation

- zero, negative, tiny decimal, huge integer
- currency confusion and rounding edges
- direct total/discount/shipping modification

### Cross-Object / Cross-Tenant

- replace one id at a time
- test list -> detail -> export/write chain
- compare A/B account behavior

### Race

- same request burst for one-time actions
- check endpoint + write endpoint in the same timing window
- apply coupon + checkout, verify + privileged action

## Evidence Standard

Record:

- baseline state and request
- the single mutated variable
- response delta
- visible or server-side state delta
- account/role/tenant used
- whether the result is read, write, replay, or race
- rollback step if state changed

## Related Skills

- `blackbox-business-logic-hunter`: AI black-box operating model
- `workflow-state-diff-lab`: baseline vs mutation diff
- `feature-priority-scorer`: choose high-yield features
- `logic-evidence-pack`: package confirmed findings
- `logic-fix-verification`: retest patches
